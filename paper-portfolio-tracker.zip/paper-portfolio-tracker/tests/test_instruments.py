"""Instrument master ingestion, keying and search."""

from __future__ import annotations

import pytest

from app.services import instruments


def test_seed_loads_the_shipped_hierarchy(seeded):
    all_rows = instruments.search(seeded, "", limit=500)
    assert len(all_rows) > 100, "the shipped seed should contain the full futures universe"


def test_full_ticker_including_yellow_key_is_the_key(seeded):
    """
    `NO1 Index` is the Nikkei 225 mini and `NO1 Curncy` is the Norwegian krone.
    Both are in the shipped seed. Keying on the root code alone would silently
    merge two unrelated instruments, so the key must include the yellow key.
    """
    nikkei = instruments.get_by_ticker(seeded, "NO1 Index")
    nok = instruments.get_by_ticker(seeded, "NO1 Curncy")

    assert nikkei is not None and nok is not None
    assert nikkei.id != nok.id
    assert nikkei.level_1 == "Equity"
    assert nok.level_1 == "FX"


def test_bare_root_is_rejected_when_ambiguous(seeded):
    inst, messages = instruments.resolve_ticker(seeded, "NO1")
    assert inst is None
    assert "ambiguous" in messages[0].lower()
    assert "NO1 Index" in messages[0] and "NO1 Curncy" in messages[0]


def test_bare_root_resolves_when_unambiguous(seeded):
    inst, messages = instruments.resolve_ticker(seeded, "ES1")
    assert inst is not None
    assert inst.bbg_ticker == "ES1 Index"
    assert any("yellow key inferred" in m for m in messages)


def test_tickers_with_internal_spaces_survive(seeded):
    """`Z 1 Index` (FTSE 100) and `G 1 Comdty` (Long Gilt) contain a space."""
    ftse = instruments.get_by_ticker(seeded, "Z 1 Index")
    gilt = instruments.get_by_ticker(seeded, "G 1 Comdty")
    assert ftse is not None and "FTSE 100" in ftse.instrument_name
    assert gilt is not None and "Gilt" in gilt.instrument_name


@pytest.mark.parametrize(
    "headers,expected",
    [
        (["Level 1", "Bloomberg Code"], {"level_1", "bbg_code"}),
        (["level_1", "bloomberg_formula"], {"level_1", "bbg_code"}),
        (["LEVEL-1", "Bloomberg Formula"], {"level_1", "bbg_code"}),
    ],
)
def test_column_aliasing_is_punctuation_insensitive(headers, expected):
    """A revised master file may spell headers differently; it must still load."""
    mapping = instruments.map_columns(headers)
    assert expected.issubset(set(mapping))


def test_reload_deactivates_rather_than_deletes(seeded):
    csv = (
        "Level 1,Level 2,Level 3,Level 4,Exposure / Instrument Name,"
        "Bloomberg Code,Bloomberg Yellow Key,Primary Exchange,Notes\n"
        "Equity,US Equities,US Broad Equity,Large Cap,S&P 500 E-mini,ES1 Index,Index,CME,\n"
    )
    result = instruments.ingest_instrument_master(
        seeded, content=csv.encode(), filename="tiny.csv", actor="pytest"
    )
    assert result.deactivated > 100

    # The dropped instruments are still resolvable, because trades reference them.
    bund = instruments.get_by_ticker(seeded, "RX1 Comdty")
    assert bund is not None
    assert bund.is_active is False

    seeded.rollback()


def test_search_ranks_exact_ticker_first(seeded):
    hits = instruments.search(seeded, "ES1 Index", limit=5)
    assert hits[0].bbg_ticker == "ES1 Index"


def test_search_matches_hierarchy_terms(seeded):
    hits = instruments.search(seeded, "Government Bonds", limit=50)
    assert hits and all(h.level_1 == "Fixed Income" for h in hits)


def test_synthetic_funding_instrument_is_outside_the_market_hierarchy(seeded):
    offset = instruments.get_by_ticker(seeded, "USD_CASH_OFFSET")
    assert offset is not None
    assert offset.is_synthetic is True
    assert offset.level_1 == "Cash & Funding"
    # It must never show up in a normal instrument search.
    assert all(h.bbg_ticker != "USD_CASH_OFFSET" for h in instruments.search(seeded, "USD", limit=50))


# ---------------------------------------------------------------------------
# Ad-hoc instruments (the "not in the master" escape hatch)
# ---------------------------------------------------------------------------
def test_adhoc_requires_a_yellow_key(seeded):
    with pytest.raises(ValueError) as exc:
        instruments.create_adhoc(
            seeded, bbg_ticker="TSLA", level_1="Equity", level_2="US Equities", level_3="Single Stocks", level_4="Technology", actor="pytest"
        )
    assert "yellow key" in str(exc.value).lower()


def test_adhoc_adds_a_usable_instrument(seeded):
    inst, messages = instruments.create_adhoc(
        seeded,
        bbg_ticker="TSLA US Equity",
        level_1="Equity",
        level_2="US Equities",
        level_3="Single Stocks",
        level_4="Technology",
        actor="pytest",
    )
    assert inst.bbg_ticker == "TSLA US Equity"
    assert inst.yellow_key == "Equity"
    assert inst.source_file == instruments.ADHOC_SOURCE

    # Offline: nothing can be validated, so it must say so rather than imply it did.
    assert inst.validation_status == "unvalidated"
    assert any("could not be validated" in m for m in messages)

    # It is now a first-class instrument: resolvable, searchable, classified.
    resolved, _ = instruments.resolve_ticker(seeded, "TSLA US Equity")
    assert resolved is not None and resolved.id == inst.id
    assert any(h.bbg_ticker == "TSLA US Equity" for h in instruments.search(seeded, "TSLA"))
    assert inst in instruments.adhoc_instruments(seeded)
    seeded.rollback()


def test_adhoc_is_idempotent(seeded):
    first, _ = instruments.create_adhoc(seeded, bbg_ticker="AAPL US Equity", level_1="Equity", level_2="US Equities", level_3="Single Stocks", level_4="Technology", actor="pytest")
    again, messages = instruments.create_adhoc(seeded, bbg_ticker="AAPL US Equity", level_1="Equity", level_2="US Equities", level_3="Single Stocks", level_4="Technology", actor="pytest")
    assert first.id == again.id
    seeded.rollback()


def test_adhoc_reactivates_a_deactivated_instrument(seeded):
    """
    A ticker dropped by a master reload is deactivated, not deleted. Re-adding
    it by hand should bring it back rather than fail on the unique constraint.
    """
    bund = instruments.get_by_ticker(seeded, "RX1 Comdty")
    bund.is_active = False
    seeded.flush()

    same, messages = instruments.create_adhoc(seeded, bbg_ticker="RX1 Comdty", level_1="Fixed Income", level_2="Europe Rates", level_3="Germany", level_4="10Y", actor="pytest")
    assert same.id == bund.id
    assert same.is_active is True
    assert any("reactivated" in m for m in messages)
    seeded.rollback()


def test_adhoc_instrument_is_tradeable(seeded, book=None):
    """The whole point: you can book a trade in it immediately."""
    from datetime import date

    from app.models import ExecutionType
    from app.services import portfolios, trades

    instruments.create_adhoc(
        seeded,
        bbg_ticker="MSFT US Equity",
        level_1="Equity",
        level_2="US Equities",
        level_3="Single Stocks",
        level_4="Technology",
        actor="pytest",
    )
    p = portfolios.create(
        seeded, portfolio_id="ADHOC-TEST", name="Ad-hoc", actor="pytest"
    )
    seeded.flush()

    trade = trades.save_trade(
        seeded,
        trades.TradeRequest(
            portfolio_id="ADHOC-TEST",
            bbg_ticker="MSFT US Equity",
            trade_date=date(2026, 6, 10),
            weight_pct=2.0,
            execution_type=ExecutionType.CUSTOM,
            custom_level=410.25,
            actor="pytest",
        ),
    )
    assert trade.bbg_ticker == "MSFT US Equity"
    assert trade.execution_level == 410.25
    seeded.rollback()


def test_adhoc_refuses_an_unclassified_instrument(seeded):
    """
    The rule that keeps the taxonomy honest: no hierarchy, no instrument.

    An unclassified row is invisible to build_rollup, contributes no duration
    and gets no attribution colour - it consumes weight while disappearing from
    every aggregate. That is worse than refusing it.
    """
    for bad in ({"level_4": "Unclassified"}, {"level_2": ""}, {"level_3": "  "}, {"level_1": "n/a"}):
        kwargs = {
            "level_1": "Equity",
            "level_2": "US Equities",
            "level_3": "Single Stocks",
            "level_4": "Technology",
        }
        kwargs.update(bad)
        with pytest.raises(ValueError) as exc:
            instruments.create_adhoc(
                seeded, bbg_ticker="NFLX US Equity", **kwargs, actor="pytest"
            )
        assert "classif" in str(exc.value).lower()
    seeded.rollback()


def test_manual_instruments_survive_a_master_reload(seeded):
    """
    A classification captured by one user must persist for everyone, including
    across a master-file revision. Ad-hoc rows are not in the seed file by
    definition, so a naive "deactivate anything missing" would erase them.
    """
    inst, _ = instruments.create_adhoc(
        seeded,
        bbg_ticker="NVDA US Equity",
        level_1="Equity",
        level_2="US Equities",
        level_3="Single Stocks",
        level_4="Semiconductors",
        actor="pytest",
    )
    seeded.flush()

    csv = (
        "Level 1,Level 2,Level 3,Level 4,Exposure / Instrument Name,"
        "Bloomberg Code,Bloomberg Yellow Key,Primary Exchange,Notes\n"
        "Equity,US Equities,US Broad Equity,Large Cap,S&P 500 E-mini,ES1 Index,Index,CME,\n"
    )
    instruments.ingest_instrument_master(
        seeded, content=csv.encode(), filename="tiny.csv", actor="pytest"
    )

    survivor = instruments.get_by_ticker(seeded, "NVDA US Equity")
    assert survivor is not None
    assert survivor.is_active is True, "a manual instrument must not be dropped by a reload"
    assert survivor.level_4 == "Semiconductors", "its classification must be preserved verbatim"
    seeded.rollback()


def test_suggestion_comes_from_the_house_taxonomy_not_bloomberg(seeded):
    """
    Bloomberg has no field for 'Developed Non-US Equities'. The suggestion is
    therefore derived from the closest row already in the master, and says so.
    """
    s = instruments.suggest_classification(seeded, "SPX Index", "S&P 500 INDEX")
    assert s is not None
    assert s["level_1"] == "Equity"
    assert "ES1 Index" in s["basis"]

    # Nothing comparable in a futures-only master -> no invented answer.
    assert instruments.suggest_classification(seeded, "CCZ6 Comdty", "Cocoa") is None
