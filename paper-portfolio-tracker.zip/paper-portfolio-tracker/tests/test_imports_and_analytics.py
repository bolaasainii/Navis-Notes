"""Import validation rules, snapshot semantics, duration and volatility."""

from __future__ import annotations

from datetime import date

import pytest

from app.models import ImportMode, ImportStatus, RowStatus
from app.services import duration, exposure, imports, portfolios, volatility

HEADER = "portfolio_id,bbg_ticker,notional_weight_pct,trade_date,execution_time,level,notes\n"


def _stage(db, book, rows, mode=ImportMode.TRADE_HISTORY):
    csv = HEADER + "\n".join(rows) + "\n"
    return imports.stage_upload(
        db, content=csv.encode(), filename="t.csv", mode=mode, portfolio=book, actor="pytest"
    )


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------
def test_valid_row_passes(seeded, book):
    _, parsed = _stage(seeded, book, [f"{book.portfolio_id},ES1 Index,4,2026-06-10,Mkt Close,,ok"])
    assert parsed[0].status == RowStatus.VALID
    assert parsed[0].level is not None, "Bloomberg should have populated the level"


def test_missing_portfolio_id_is_an_error(seeded, book):
    _, parsed = _stage(seeded, book, [",ES1 Index,4,2026-06-10,Mkt Close,,"])
    assert parsed[0].status == RowStatus.ERROR
    assert any("portfolio_id is required" in m for m in parsed[0].messages)


def test_mismatched_portfolio_id_is_an_error(seeded, book):
    _, parsed = _stage(seeded, book, ["SOMEONE-ELSE,ES1 Index,4,2026-06-10,Mkt Close,,"])
    assert parsed[0].status == RowStatus.ERROR


def test_unknown_ticker_is_an_error(seeded, book):
    _, parsed = _stage(seeded, book, [f"{book.portfolio_id},ZZZ9 Index,4,2026-06-10,Mkt Close,,"])
    assert parsed[0].status == RowStatus.ERROR
    assert any("not found" in m for m in parsed[0].messages)


def test_bad_date_format_is_an_error(seeded, book):
    _, parsed = _stage(seeded, book, [f"{book.portfolio_id},ES1 Index,4,10 June 2026,Mkt Close,,"])
    assert parsed[0].status == RowStatus.ERROR
    assert any("ISO" in m for m in parsed[0].messages)


def test_future_date_is_an_error(seeded, book):
    _, parsed = _stage(seeded, book, [f"{book.portfolio_id},ES1 Index,4,2099-01-01,Mkt Close,,"])
    assert parsed[0].status == RowStatus.ERROR


def test_invalid_execution_time_is_an_error(seeded, book):
    _, parsed = _stage(seeded, book, [f"{book.portfolio_id},ES1 Index,4,2026-06-10,VWAP,,"])
    assert parsed[0].status == RowStatus.ERROR
    assert any("Mkt Close" in m for m in parsed[0].messages)


def test_custom_without_level_is_an_error(seeded, book):
    _, parsed = _stage(seeded, book, [f"{book.portfolio_id},ES1 Index,4,2026-06-10,Custom,,"])
    assert parsed[0].status == RowStatus.ERROR
    assert any("level is required when execution_time is Custom" in m for m in parsed[0].messages)


def test_custom_with_level_is_valid_and_used_verbatim(seeded, book):
    _, parsed = _stage(seeded, book, [f"{book.portfolio_id},ES1 Index,4,2026-06-10,Custom,4321.5,"])
    assert parsed[0].status == RowStatus.VALID
    assert parsed[0].level == pytest.approx(4321.5)


def test_blank_level_is_fine_for_market_executions(seeded, book):
    _, parsed = _stage(seeded, book, [f"{book.portfolio_id},ES1 Index,4,2026-06-10,Mkt Open,,"])
    assert parsed[0].status == RowStatus.VALID
    assert parsed[0].level is not None


def test_level_supplied_for_a_market_execution_warns_but_passes(seeded, book):
    _, parsed = _stage(seeded, book, [f"{book.portfolio_id},ES1 Index,4,2026-06-10,Mkt Close,999,"])
    assert parsed[0].status == RowStatus.WARNING
    assert parsed[0].level != 999, "Bloomberg's official level must win"


def test_missing_required_column_fails_the_whole_file(seeded, book):
    csv = "portfolio_id,bbg_ticker,notional_weight_pct\nX,ES1 Index,4\n"
    record, parsed = imports.stage_upload(
        seeded, content=csv.encode(), filename="bad.csv",
        mode=ImportMode.TRADE_HISTORY, portfolio=book, actor="pytest",
    )
    assert record.status == ImportStatus.FAILED_VALIDATION
    assert "trade_date" in record.message and "execution_time" in record.message


# ---------------------------------------------------------------------------
# Mode semantics
# ---------------------------------------------------------------------------
def test_repeat_instrument_is_normal_in_trade_history(seeded, book):
    _, parsed = _stage(seeded, book, [
        f"{book.portfolio_id},ES1 Index,4,2026-06-10,Mkt Close,,",
        f"{book.portfolio_id},ES1 Index,2,2026-06-10,Mkt Close,,",
    ])
    assert all(r.status != RowStatus.ERROR for r in parsed)


def test_repeat_instrument_is_an_error_in_a_target_snapshot(seeded, book):
    _, parsed = _stage(seeded, book, [
        f"{book.portfolio_id},ES1 Index,4,2026-06-10,Mkt Close,,",
        f"{book.portfolio_id},ES1 Index,2,2026-06-10,Mkt Close,,",
    ], mode=ImportMode.TARGET_SNAPSHOT)
    assert any(r.status == RowStatus.ERROR for r in parsed)
    assert any("more than once" in m for r in parsed for m in r.messages)


def test_trade_history_import_appends_and_balances(seeded, book):
    record, _ = _stage(seeded, book, [
        f"{book.portfolio_id},ES1 Index,4,2026-06-01,Mkt Close,,",
        f"{book.portfolio_id},RX1 Comdty,-3,2026-06-01,Mkt Close,,",
    ])
    result = imports.commit(seeded, record, actor="pytest")
    seeded.commit()
    assert result["committed"] == 2

    from app.services import positions
    weights = positions.net_weights_as_of(seeded, book, date(2026, 6, 30))
    assert sum(weights.values()) == pytest.approx(0.0, abs=1e-9)
    assert weights["USD_CASH_OFFSET"] == pytest.approx(-1.0)


def test_snapshot_supersedes_rather_than_deletes(seeded, book):
    rows = [f"{book.portfolio_id},ES1 Index,4,2026-06-01,Mkt Close,,"]
    r1, _ = _stage(seeded, book, rows, mode=ImportMode.TARGET_SNAPSHOT)
    out1 = imports.commit(seeded, r1, snapshot_label="v1", actor="pytest")
    seeded.commit()

    r2, _ = _stage(seeded, book, rows, mode=ImportMode.TARGET_SNAPSHOT)
    out2 = imports.commit(seeded, r2, snapshot_label="v1", actor="pytest")
    seeded.commit()

    from app.models import PortfolioSnapshot
    old = seeded.get(PortfolioSnapshot, out1["snapshots_created"][0])
    assert old is not None, "the superseded snapshot must survive"
    assert old.superseded_by_id == out2["snapshots_created"][0]
    assert old.is_current is False


def test_snapshot_carries_its_own_balancing_sleeve(seeded, book):
    r, _ = _stage(seeded, book, [
        f"{book.portfolio_id},ES1 Index,5,2026-06-01,Mkt Close,,",
        f"{book.portfolio_id},RX1 Comdty,-2,2026-06-01,Mkt Close,,",
    ], mode=ImportMode.TARGET_SNAPSHOT)
    out = imports.commit(seeded, r, snapshot_label="sleeve-test", actor="pytest")
    seeded.commit()

    from app.models import PortfolioSnapshot
    snap = seeded.get(PortfolioSnapshot, out["snapshots_created"][0])
    total = sum(row.target_weight_pct for row in snap.rows)
    assert total == pytest.approx(0.0, abs=1e-9)


def test_committing_twice_is_refused(seeded, book):
    record, _ = _stage(seeded, book, [f"{book.portfolio_id},ES1 Index,4,2026-06-01,Mkt Close,,"])
    imports.commit(seeded, record, actor="pytest")
    seeded.commit()
    with pytest.raises(ValueError):
        imports.commit(seeded, record, actor="pytest")


def test_templates_round_trip(seeded, book):
    """The shipped sample file must itself validate against the shipped rules."""
    csv = imports.template_csv(ImportMode.TRADE_HISTORY, with_sample=True)
    csv = csv.replace("Navi-S1", book.portfolio_id)
    record, parsed = imports.stage_upload(
        seeded, content=csv.encode(), filename="sample.csv",
        mode=ImportMode.TRADE_HISTORY, portfolio=book, actor="pytest",
    )
    errors = [r for r in parsed if r.status == RowStatus.ERROR]
    assert not errors, [r.messages for r in errors]


# ---------------------------------------------------------------------------
# Duration
# ---------------------------------------------------------------------------
def test_us_treasury_duration_comes_from_bloomberg(seeded):
    from app.services import instruments
    inst = instruments.get_by_ticker(seeded, "TY1 Comdty")
    duration.prefetch(seeded, [inst], date(2026, 6, 30))
    result = duration.resolve(seeded, inst, date(2026, 6, 30))
    assert result.source.value == "direct"
    assert 5.0 < result.years < 8.0


def test_international_bond_future_falls_back_to_the_proxy_table(seeded):
    from app.services import instruments
    inst = instruments.get_by_ticker(seeded, "RX1 Comdty")
    duration.prefetch(seeded, [inst], date(2026, 6, 30))
    result = duration.resolve(seeded, inst, date(2026, 6, 30))
    assert result.source.value == "proxy"
    assert result.years == pytest.approx(8.10)
    assert "proxy" in (result.note or "").lower()


def test_equity_has_no_duration_and_that_is_not_a_gap(seeded):
    from app.services import instruments
    inst = instruments.get_by_ticker(seeded, "ES1 Index")
    result = duration.resolve(seeded, inst, date(2026, 6, 30))
    assert result.source.value == "n/a"
    assert result.years is None


def test_yield_quoted_contracts_are_excluded(seeded):
    from app.services import instruments
    inst = instruments.get_by_ticker(seeded, "YQT1 Comdty")
    result = duration.resolve(seeded, inst, date(2026, 6, 30))
    assert result.source.value == "n/a"
    assert "yield" in (result.note or "").lower()


def test_short_rate_futures_use_the_accrual_period(seeded):
    from app.services import instruments
    inst = instruments.get_by_ticker(seeded, "SFR1 Comdty")
    result = duration.resolve(seeded, inst, date(2026, 6, 30))
    assert result.years == pytest.approx(0.25)


def test_override_wins_and_is_tagged(seeded):
    from app.services import instruments
    inst = instruments.get_by_ticker(seeded, "TY1 Comdty")
    as_of = date(2026, 6, 30)
    duration.set_override(seeded, ticker="TY1 Comdty", years=7.77, as_of=as_of, actor="pytest")
    result = duration.resolve(seeded, inst, as_of)
    assert result.source.value == "override"
    assert result.years == pytest.approx(7.77)
    seeded.rollback()


def test_duration_contribution_is_weight_times_duration(seeded):
    from app.services import instruments
    inst = instruments.get_by_ticker(seeded, "RX1 Comdty")
    result = duration.resolve(seeded, inst, date(2026, 6, 30))
    assert duration.contribution(-3.0, result) == pytest.approx(-0.03 * result.years)


# ---------------------------------------------------------------------------
# Volatility
# ---------------------------------------------------------------------------
def test_equity_index_vol_is_plausible(seeded):
    result = volatility.compute(
        seeded, "ES1 Index", window_start=date(2026, 3, 1), window_end=date(2026, 6, 30)
    )
    assert result.instrument_vol_pct is not None
    assert 5.0 < result.instrument_vol_pct < 40.0, "annualised equity vol should be sane"
    assert result.observations > 20


def test_bond_future_vol_is_lower_than_equity_vol(seeded):
    eq = volatility.compute(seeded, "ES1 Index", window_start=date(2026, 3, 1), window_end=date(2026, 6, 30))
    fi = volatility.compute(seeded, "TY1 Comdty", window_start=date(2026, 3, 1), window_end=date(2026, 6, 30))
    assert fi.instrument_vol_pct < eq.instrument_vol_pct


def test_short_window_is_extended_and_flagged(seeded):
    result = volatility.compute(
        seeded, "ES1 Index", window_start=date(2026, 6, 25), window_end=date(2026, 6, 30)
    )
    assert result.extended is True
    assert result.observations >= 20
    assert "extended" in (result.note or "").lower()


def test_standalone_scales_with_weight(seeded):
    result = volatility.compute(
        seeded, "ES1 Index", window_start=date(2026, 3, 1), window_end=date(2026, 6, 30)
    )
    assert result.standalone(10.0) == pytest.approx(2 * result.standalone(5.0))
    assert result.standalone(-5.0) == pytest.approx(result.standalone(5.0)), "shorts carry risk too"


def test_funding_sleeve_has_no_volatility(seeded):
    result = volatility.compute(
        seeded, "USD_CASH_OFFSET", window_start=date(2026, 3, 1), window_end=date(2026, 6, 30)
    )
    assert result.instrument_vol_pct is None
