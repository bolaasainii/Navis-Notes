"""
Test fixtures.

The environment is configured BEFORE any application module is imported, so the
test suite runs against a throw-away database and the deterministic synthetic
market-data provider. No Bloomberg Terminal is required to run these tests -
that is the whole point of the provider abstraction.
"""

from __future__ import annotations

import os
import tempfile
from datetime import date
from pathlib import Path

import pytest

_TMP = Path(tempfile.mkdtemp(prefix="ppt-tests-"))
os.environ["PPT_PATHS__DATABASE_PATH"] = str(_TMP / "test.sqlite")
os.environ["PPT_PATHS__IMPORT_ARCHIVE_DIR"] = str(_TMP / "imports")
os.environ["PPT_PATHS__TEMPLATES_DIR"] = str(_TMP / "templates")
os.environ["PPT_PATHS__SAMPLES_DIR"] = str(_TMP / "samples")
# "auto" rather than "fake": live is SUPPORTED but not AVAILABLE here (no
# blpapi package, no Terminal), which is exactly the situation the Live/Offline
# toggle has to handle gracefully. "fake" would hard-disable it and skip that
# code path entirely.
os.environ["PPT_BLOOMBERG__PROVIDER"] = "auto"

from app.db import SessionLocal, engine, init_db  # noqa: E402
from app.models import Base  # noqa: E402
from app.services import funding, instruments, portfolios  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def _database():
    Base.metadata.drop_all(bind=engine)
    init_db()
    yield


@pytest.fixture()
def db():
    session = SessionLocal()
    try:
        yield session
        session.rollback()
    finally:
        session.close()


@pytest.fixture()
def seeded(db):
    """Instrument master + funding curve loaded once per test."""
    instruments.seed_from_disk(db)
    funding.seed_curve(db)
    db.commit()
    return db


@pytest.fixture()
def book(seeded):
    """A fresh, uniquely named portfolio per test."""
    import uuid

    pid = f"TEST-{uuid.uuid4().hex[:8]}"
    p = portfolios.create(
        seeded,
        portfolio_id=pid,
        name="Test book",
        inception_date=date(2026, 5, 1),
        actor="pytest",
    )
    seeded.commit()
    return p
