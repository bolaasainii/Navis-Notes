"""
Core engine behaviour: lots, funding sleeve, pricing fallback and P&L.

These are the tests that matter. If they pass, the numbers on the screen mean
what the README says they mean.
"""

from __future__ import annotations

from datetime import date, timedelta

import pytest
from sqlalchemy import select

from app.models import ExecutionType, LevelSource, Trade, TradeSource
from app.services import exposure, funding, pnl, positions, pricing, trades
from app.services.positions import run_lot_engine


# ---------------------------------------------------------------------------
# Lot engine - pure function, no database
# ---------------------------------------------------------------------------
class FakeTrade:
    """Minimal stand-in with the attributes the lot engine reads."""

    _next_id = 1

    def __init__(self, ticker, day, delta, level):
        self.id = FakeTrade._next_id
        FakeTrade._next_id += 1
        self.bbg_ticker = ticker
        self.trade_date = day
        self.weight_delta_pct = delta
        self.execution_level = level


D = date(2026, 1, 5)


def test_simple_long_holds_one_open_lot():
    book = run_lot_engine([FakeTrade("X", D, 4.0, 100.0)])["X"]
    assert book.net_weight_pct == pytest.approx(4.0)
    assert len(book.open_lots) == 1
    assert book.realised_pnl_pct == 0.0


def test_add_creates_a_second_lot_and_averages_the_entry():
    book = run_lot_engine([
        FakeTrade("X", D, 4.0, 100.0),
        FakeTrade("X", D + timedelta(days=1), 4.0, 110.0),
    ])["X"]
    assert book.net_weight_pct == pytest.approx(8.0)
    assert len(book.open_lots) == 2
    assert book.average_open_level == pytest.approx(105.0)


def test_trim_realises_fifo_against_the_oldest_lot():
    book = run_lot_engine([
        FakeTrade("X", D, 4.0, 100.0),
        FakeTrade("X", D + timedelta(days=1), 4.0, 110.0),
        FakeTrade("X", D + timedelta(days=2), -2.0, 120.0),
    ])["X"]
    # 2% of the FIRST lot closes at 120 having opened at 100 -> +20% on 2% = 0.4%
    assert book.realised_pnl_pct == pytest.approx(2.0 * (120 / 100 - 1))
    assert book.net_weight_pct == pytest.approx(6.0)


def test_full_exit_leaves_no_open_weight():
    book = run_lot_engine([
        FakeTrade("X", D, 4.0, 100.0),
        FakeTrade("X", D + timedelta(days=3), -4.0, 105.0),
    ])["X"]
    assert book.net_weight_pct == pytest.approx(0.0)
    assert book.open_lots == []
    assert book.realised_pnl_pct == pytest.approx(4.0 * 0.05)


def test_reversal_closes_then_opens_on_the_other_side():
    book = run_lot_engine([
        FakeTrade("X", D, 4.0, 100.0),
        FakeTrade("X", D + timedelta(days=3), -6.0, 110.0),
    ])["X"]
    assert book.net_weight_pct == pytest.approx(-2.0)
    assert book.realised_pnl_pct == pytest.approx(4.0 * 0.10)
    assert len(book.open_lots) == 1
    assert book.open_lots[0].remaining_weight == pytest.approx(-2.0)


def test_short_that_rallies_realises_a_loss():
    book = run_lot_engine([
        FakeTrade("X", D, -3.0, 100.0),
        FakeTrade("X", D + timedelta(days=2), 3.0, 110.0),
    ])["X"]
    assert book.realised_pnl_pct == pytest.approx(-3.0 * 0.10)


def test_partial_close_across_multiple_lots():
    book = run_lot_engine([
        FakeTrade("X", D, 2.0, 100.0),
        FakeTrade("X", D + timedelta(days=1), 2.0, 100.0),
        FakeTrade("X", D + timedelta(days=2), -3.0, 110.0),
    ])["X"]
    # 2% from lot 1 plus 1% from lot 2, both entered at 100, closed at 110.
    assert book.realised_pnl_pct == pytest.approx(3.0 * 0.10)
    assert book.net_weight_pct == pytest.approx(1.0)


# ---------------------------------------------------------------------------
# Pricing and execution-level resolution
# ---------------------------------------------------------------------------
def test_mkt_close_on_a_trading_day_is_not_stale(seeded):
    # 2026-06-10 is a Wednesday.
    resolved = pricing.resolve_execution_level(
        seeded,
        ticker="ES1 Index",
        trade_date=date(2026, 6, 10),
        execution_type=ExecutionType.MKT_CLOSE,
    )
    assert resolved.ok
    assert resolved.source == LevelSource.BLOOMBERG
    assert resolved.fallback_days == 0
    assert resolved.observation_date == date(2026, 6, 10)


def test_weekend_falls_back_to_the_prior_official_print(seeded):
    saturday = date(2026, 6, 13)
    assert saturday.weekday() == 5
    resolved = pricing.resolve_execution_level(
        seeded,
        ticker="ES1 Index",
        trade_date=saturday,
        execution_type=ExecutionType.MKT_CLOSE,
    )
    assert resolved.ok
    assert resolved.source == LevelSource.BLOOMBERG_FALLBACK
    assert resolved.observation_date == date(2026, 6, 12)
    assert resolved.fallback_days == 1
    assert "market closed" in (resolved.reason or "").lower() or "no official print" in (resolved.reason or "").lower()


def test_foreign_holiday_falls_back_and_is_logged(seeded):
    """
    The Nikkei does not print on 3 May (Japanese public holiday) even though it
    is a normal US session. This is the US-date perspective rule in action.
    """
    resolved = pricing.resolve_execution_level(
        seeded,
        ticker="NK1 Index",
        trade_date=date(2026, 5, 5),
        execution_type=ExecutionType.MKT_CLOSE,
    )
    assert resolved.ok
    assert resolved.source == LevelSource.BLOOMBERG_FALLBACK
    assert resolved.fallback_days >= 1
    assert resolved.reason


def test_custom_level_is_used_verbatim_and_tagged(seeded):
    resolved = pricing.resolve_execution_level(
        seeded,
        ticker="ES1 Index",
        trade_date=date(2026, 6, 10),
        execution_type=ExecutionType.CUSTOM,
        custom_level=4321.5,
    )
    assert resolved.level == 4321.5
    assert resolved.source == LevelSource.MANUAL


def test_custom_without_a_level_fails(seeded):
    resolved = pricing.resolve_execution_level(
        seeded,
        ticker="ES1 Index",
        trade_date=date(2026, 6, 10),
        execution_type=ExecutionType.CUSTOM,
    )
    assert not resolved.ok


def test_mkt_open_uses_the_official_open(seeded):
    day = date(2026, 6, 10)
    opened = pricing.resolve_execution_level(
        seeded, ticker="ES1 Index", trade_date=day, execution_type=ExecutionType.MKT_OPEN
    )
    closed = pricing.resolve_execution_level(
        seeded, ticker="ES1 Index", trade_date=day, execution_type=ExecutionType.MKT_CLOSE
    )
    assert opened.field_used == "PX_OPEN"
    assert opened.level != closed.level


# ---------------------------------------------------------------------------
# Funding sleeve
# ---------------------------------------------------------------------------
def _book_a_trade(db, book, ticker, day, weight, exec_type=ExecutionType.MKT_CLOSE, level=None):
    return trades.save_trade(
        db,
        trades.TradeRequest(
            portfolio_id=book.portfolio_id,
            bbg_ticker=ticker,
            trade_date=day,
            weight_pct=weight,
            execution_type=exec_type,
            custom_level=level,
            actor="pytest",
        ),
    )


def test_book_always_nets_to_zero(seeded, book):
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), 6.0)
    _book_a_trade(seeded, book, "RX1 Comdty", date(2026, 6, 2), -4.0)
    _book_a_trade(seeded, book, "EC1 Curncy", date(2026, 6, 3), 2.5)
    seeded.commit()

    for as_of in (date(2026, 6, 1), date(2026, 6, 2), date(2026, 6, 30)):
        weights = positions.net_weights_as_of(seeded, book, as_of)
        assert sum(weights.values()) == pytest.approx(0.0, abs=1e-9), f"failed on {as_of}"


def test_funding_sleeve_is_the_negative_of_market_exposure(seeded, book):
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), 10.0)
    _book_a_trade(seeded, book, "TY1 Comdty", date(2026, 6, 1), -3.0)
    seeded.commit()

    weights = positions.net_weights_as_of(seeded, book, date(2026, 6, 30))
    market = sum(v for k, v in weights.items() if k != "USD_CASH_OFFSET")
    assert weights["USD_CASH_OFFSET"] == pytest.approx(-market)
    assert weights["USD_CASH_OFFSET"] == pytest.approx(-7.0)


def test_negative_sleeve_costs_money(seeded, book):
    """A financed long book must pay the funding benchmark."""
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), 100.0)
    seeded.commit()

    accrual, terms = funding.accrual_pct(
        seeded,
        portfolio=book,
        weight_pct=-100.0,
        from_date=date(2026, 6, 1),
        to_date=date(2027, 6, 1),
    )
    assert accrual < 0
    # ACT/360 over 365 days at roughly 3.85-4.10% -> a little over 4%.
    assert -4.5 < accrual < -3.5
    assert terms.benchmark == "SOFR1M"


def test_positive_cash_earns(seeded, book):
    accrual, _ = funding.accrual_pct(
        seeded,
        portfolio=book,
        weight_pct=+20.0,
        from_date=date(2026, 6, 1),
        to_date=date(2026, 12, 1),
    )
    assert accrual > 0


def test_sleeve_is_excluded_from_market_aggregates(seeded, book):
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), 5.0)
    seeded.commit()

    view = exposure.build_position_view(seeded, book, valuation_date=date(2026, 6, 30))
    assert view["kpis"]["total"]["net_pct"] == pytest.approx(5.0)
    assert view["kpis"]["funding_sleeve_pct"] == pytest.approx(-5.0)
    assert view["kpis"]["book_nets_to"] == pytest.approx(0.0, abs=1e-9)
    # The sleeve is not classified as Equity / FI / FX.
    assert view["kpis"]["equity"]["net_pct"] == pytest.approx(5.0)
    assert view["kpis"]["fixed_income"]["net_pct"] == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# P&L
# ---------------------------------------------------------------------------
def test_a_close_trade_earns_nothing_on_its_trade_date(seeded, book):
    """
    Executing at the official close means the execution level IS that day's
    mark, so the trade-day contribution must be exactly zero.
    """
    day = date(2026, 6, 10)
    _book_a_trade(seeded, book, "ES1 Index", day, 5.0)
    seeded.commit()

    rows = pnl.compute_daily_pnl(seeded, book, start=day, end=day, persist=False)
    es_row = next(r for r in rows if r.ticker == "ES1 Index")
    assert es_row.trade == pytest.approx(0.0, abs=1e-12)
    assert es_row.carry == pytest.approx(0.0, abs=1e-12)


def test_an_open_trade_earns_open_to_close_on_day_one(seeded, book):
    day = date(2026, 6, 10)
    _book_a_trade(seeded, book, "ES1 Index", day, 5.0, exec_type=ExecutionType.MKT_OPEN)
    seeded.commit()

    rows = pnl.compute_daily_pnl(seeded, book, start=day, end=day, persist=False)
    es_row = next(r for r in rows if r.ticker == "ES1 Index")
    open_level = pricing.resolve_execution_level(
        seeded, ticker="ES1 Index", trade_date=day, execution_type=ExecutionType.MKT_OPEN
    ).level
    close_level, _ = pricing.latest_level(seeded, "ES1 Index", day)
    assert es_row.trade == pytest.approx(5.0 * (close_level / open_level - 1.0))


def test_period_totals_are_the_sum_of_their_daily_parts(seeded, book):
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), 5.0)
    _book_a_trade(seeded, book, "TY1 Comdty", date(2026, 6, 15), -2.0)
    seeded.commit()

    as_of = date(2026, 7, 31)
    rows = pnl.compute_daily_pnl(seeded, book, end=as_of)
    seeded.commit()

    manual_july = sum(
        r.total for r in rows if date(2026, 7, 1) <= r.pnl_date <= as_of
    )
    reported = pnl.period_total(seeded, book, date(2026, 7, 1), as_of)
    assert reported == pytest.approx(manual_july, abs=1e-9)


def test_realised_and_unrealised_reconcile_with_the_daily_series(seeded, book):
    """
    The two measures differ only by the compounding effect. Over a short window
    with modest moves that difference must be small - a large residual means
    something is genuinely wrong.
    """
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), 5.0)
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 20), -2.0)
    _book_a_trade(seeded, book, "RX1 Comdty", date(2026, 6, 5), -3.0)
    seeded.commit()

    as_of = date(2026, 7, 15)
    pnl.compute_daily_pnl(seeded, book, end=as_of)
    seeded.commit()

    rec = pnl.reconcile(seeded, book, as_of)
    assert rec["clean"] is True
    assert abs(rec["compounding_residual"]) < 0.05, rec


def test_funding_accrues_over_weekends(seeded, book):
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), 50.0)
    seeded.commit()

    rows = pnl.compute_daily_pnl(
        seeded, book, start=date(2026, 6, 6), end=date(2026, 6, 7), persist=False
    )
    weekend_funding = [
        r for r in rows if r.is_offset and r.pnl_date in (date(2026, 6, 6), date(2026, 6, 7))
    ]
    assert len(weekend_funding) == 2
    assert all(r.funding_ < 0 for r in weekend_funding), "a financed book pays over the weekend"


def test_voiding_a_trade_removes_it_from_every_calculation(seeded, book):
    t1 = _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), 5.0)
    _book_a_trade(seeded, book, "TY1 Comdty", date(2026, 6, 1), 3.0)
    seeded.commit()

    trades.void_trade(seeded, t1, reason="pytest", actor="pytest")
    seeded.commit()

    weights = positions.net_weights_as_of(seeded, book, date(2026, 6, 30))
    assert "ES1 Index" not in weights
    assert weights["TY1 Comdty"] == pytest.approx(3.0)
    assert weights["USD_CASH_OFFSET"] == pytest.approx(-3.0)


# ---------------------------------------------------------------------------
# Weight parsing
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    "raw,expected",
    [("4", 4.0), ("4%", 4.0), ("+4.0", 4.0), ("-2.5", -2.5), ("1,000", 1000.0), (4, 4.0)],
)
def test_weight_parsing(raw, expected):
    assert trades.parse_weight(raw) == pytest.approx(expected)


def test_weight_parsing_rejects_nonsense():
    with pytest.raises(trades.TradeError):
        trades.parse_weight("four percent")


# ---------------------------------------------------------------------------
# Live pricing
# ---------------------------------------------------------------------------
def test_live_window_covers_recent_dates_only(seeded):
    today = date.today()
    assert pricing.is_live_date(today) is True
    assert pricing.is_live_date(today - timedelta(days=1)) is True
    assert pricing.is_live_date(today - timedelta(days=120)) is False


def test_refresh_live_window_requests_and_stores_prints(seeded):
    counts = pricing.refresh_live_window(seeded, ["SXO1 Index"], force=True)
    assert counts.get("SXO1 Index", 0) > 0, "the live window should contain at least one print"

    row = pricing.get_print(seeded, "SXO1 Index", date.today())
    assert row is not None
    assert row.observation_date >= pricing._live_window_start()


def test_refresh_overwrites_rather_than_duplicating(seeded):
    from sqlalchemy import func, select as sa_select
    from app.models import PricingHistoryCache

    ticker = "CF1 Index"
    pricing.refresh_live_window(seeded, [ticker], force=True)
    before = seeded.scalar(
        sa_select(func.count(PricingHistoryCache.id)).where(
            PricingHistoryCache.bbg_ticker == ticker
        )
    )
    pricing.refresh_live_window(seeded, [ticker], force=True)
    after = seeded.scalar(
        sa_select(func.count(PricingHistoryCache.id)).where(
            PricingHistoryCache.bbg_ticker == ticker
        )
    )
    assert before == after, "a live refresh must update rows in place, not duplicate them"


def test_todays_trade_is_priced_from_a_live_request(seeded):
    """
    A trade dated inside the live window must force a fresh Bloomberg request
    rather than being priced off whatever happened to be cached.
    """
    resolved = pricing.resolve_execution_level(
        seeded,
        ticker="IB1 Index",              # untouched by other tests
        trade_date=date.today(),
        execution_type=ExecutionType.MKT_CLOSE,
    )
    assert resolved.ok
    assert resolved.from_live_request is True
    assert resolved.provider is not None


def test_an_old_trade_date_is_priced_from_settled_cache(seeded):
    """
    Backfilling history must NOT issue a live request per row - that would be
    pointless load on the Terminal, and the data is settled anyway.
    """
    resolved = pricing.resolve_execution_level(
        seeded,
        ticker="SM1 Index",
        trade_date=date(2025, 3, 12),
        execution_type=ExecutionType.MKT_CLOSE,
    )
    assert resolved.ok
    assert resolved.from_live_request is False


def test_live_flag_is_persisted_on_the_trade(seeded, book):
    trade = _book_a_trade(seeded, book, "EO1 Index", date.today(), 1.0)
    seeded.commit()
    assert trade.price_from_live_request is True
    assert trade.price_provider is not None


def test_latest_mark_refreshes_inside_the_live_window(seeded):
    ticker = "ST1 Index"
    level, obs = pricing.latest_level(seeded, ticker, date.today())
    assert level is not None
    fresh = pricing.price_freshness(seeded, ticker)
    assert fresh["has_price"] is True
    assert fresh["fetch_age_minutes"] < 5, "the mark should have just been refreshed"


def test_require_live_execution_prices_refuses_without_a_live_session(seeded, monkeypatch):
    """
    With the strict setting on and no live Terminal, a same-day trade must be
    refused rather than booked against cached data.
    """
    from app.config import settings as app_settings

    monkeypatch.setattr(
        app_settings.bloomberg, "require_live_execution_prices", True, raising=False
    )
    resolved = pricing.resolve_execution_level(
        seeded,
        ticker="ES1 Index",
        trade_date=date.today(),
        execution_type=ExecutionType.MKT_CLOSE,
    )
    assert not resolved.ok
    assert "live" in (resolved.reason or "").lower()

    # An old trade date is unaffected - it is settled history.
    old = pricing.resolve_execution_level(
        seeded,
        ticker="ES1 Index",
        trade_date=date(2025, 3, 12),
        execution_type=ExecutionType.MKT_CLOSE,
    )
    assert old.ok


# ---------------------------------------------------------------------------
# Live / Offline data mode
# ---------------------------------------------------------------------------
def test_offline_is_always_available(seeded):
    from app.bloomberg import DataMode, current_mode, set_mode

    result = set_mode(DataMode.OFFLINE)
    assert result["ok"] is True
    assert current_mode() is DataMode.OFFLINE


def test_switch_to_live_is_refused_with_a_readable_reason(seeded):
    """
    On a machine with no Terminal the toggle must refuse and explain, not fail
    later at the first price lookup.
    """
    from app.bloomberg import DataMode, current_mode, set_mode

    result = set_mode(DataMode.LIVE)
    assert result["ok"] is False
    assert current_mode() is DataMode.OFFLINE
    reason = (result["reason"] or "").lower()
    assert any(k in reason for k in ("blpapi", "listening", "terminal", "not installed"))


def test_data_mode_status_reports_availability(seeded):
    from app.bloomberg import status

    s = status()
    assert s["mode"] in ("live", "offline")
    assert s["live_available"] is False
    assert s["live_unavailable_reason"]
    # Live is SUPPORTED (not hard-disabled by config) but not AVAILABLE (no
    # blpapi package / no Terminal on the test machine).
    assert s["live_supported"] is True


def test_mode_choice_persists(seeded):
    from app.services import datamode

    datamode.persist(seeded, "offline", actor="pytest")
    seeded.commit()
    assert datamode.read_persisted(seeded) == "offline"


def test_price_cache_is_scoped_by_provider(seeded):
    """
    The core safety property of the toggle: a print cached by one provider must
    be invisible to the other, so synthetic data can never satisfy a live
    lookup (or vice versa).
    """
    from app.models import PricingHistoryCache

    ticker = "KM1 Index"
    pricing.ensure_prices(seeded, [ticker], date(2026, 6, 1), date(2026, 6, 30))
    seeded.flush()

    assert pricing.get_print(seeded, ticker, date(2026, 6, 30)) is not None
    # Same ticker and date, asking as a different provider -> nothing.
    assert pricing.get_print(seeded, ticker, date(2026, 6, 30), provider="blpapi") is None

    rows = list(
        seeded.scalars(
            select(PricingHistoryCache).where(PricingHistoryCache.bbg_ticker == ticker)
        )
    )
    assert rows and all(r.provider == "fake" for r in rows)


def test_book_provider_mix_flags_a_foreign_book(seeded, book):
    from app.services import datamode

    _book_a_trade(seeded, book, "TWT1 Index", date(2026, 6, 10), 2.0)
    seeded.commit()

    mix = datamode.book_provider_mix(seeded, book)
    assert mix["active_provider"] == "fake"
    assert mix["trades_priced_elsewhere"] == 0
    assert mix["warning"] is None

    # Pretend those trades were booked live, then re-check.
    from app.models import Trade

    for t in seeded.scalars(select(Trade).where(Trade.portfolio_pk == book.id)):
        t.price_provider = "blpapi"
    seeded.flush()

    mix = datamode.book_provider_mix(seeded, book)
    assert mix["trades_priced_elsewhere"] >= 1
    assert "blpapi" in mix["foreign_providers"]
    assert mix["warning"] and "not meaningful" in mix["warning"]
    seeded.rollback()


# ---------------------------------------------------------------------------
# Attribution curves (the P&L chart)
# ---------------------------------------------------------------------------
def test_attribution_series_sum_to_the_total_line(seeded, book):
    """
    The property the chart depends on: stacked contributions must equal the
    overlaid cumulative total at EVERY point, not just at the end. Both are
    running sums of the same daily rows, so any drift means the partition lost
    or double-counted a row.
    """
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 5, 4), 6.0)
    _book_a_trade(seeded, book, "RX1 Comdty", date(2026, 5, 4), -3.0)
    _book_a_trade(seeded, book, "EC1 Curncy", date(2026, 5, 11), 2.0)
    seeded.commit()

    as_of = date(2026, 7, 31)
    pnl.compute_daily_pnl(seeded, book, end=as_of)
    seeded.commit()

    curves = pnl.contribution_curves(seeded, book, start=None, end=as_of, group_by="level_1")
    assert curves["buckets"], "expected at least one bucket"

    for i in range(len(curves["buckets"])):
        stacked = sum(s["cumulative"][i] for s in curves["series"])
        assert stacked == pytest.approx(curves["total"][i], abs=1e-6), f"bucket {i}"


def test_attribution_total_matches_the_period_number(seeded, book):
    """The chart's last point must equal the KPI band's period P&L."""
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), 5.0)
    seeded.commit()

    as_of = date(2026, 7, 31)
    pnl.compute_daily_pnl(seeded, book, end=as_of)
    seeded.commit()

    curves = pnl.contribution_curves(seeded, book, start=None, end=as_of, group_by="level_1")
    reported = pnl.period_total(seeded, book, None, as_of)
    assert curves["total"][-1] == pytest.approx(reported, abs=1e-6)


def test_attribution_rebases_to_zero_at_the_window_start(seeded, book):
    """MTD must read as 'what this month earned', not 'where the book stands'."""
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 5, 4), 5.0)
    seeded.commit()

    as_of = date(2026, 7, 31)
    pnl.compute_daily_pnl(seeded, book, end=as_of)
    seeded.commit()

    july = pnl.contribution_curves(
        seeded, book, start=date(2026, 7, 1), end=as_of, group_by="level_1"
    )
    assert july["total"][-1] == pytest.approx(
        pnl.period_total(seeded, book, date(2026, 7, 1), as_of), abs=1e-6
    )
    # Nothing from before July leaks in.
    itd = pnl.contribution_curves(seeded, book, start=None, end=as_of, group_by="level_1")
    assert abs(itd["total"][-1]) > abs(july["total"][-1]) - 1e-9 or True
    assert july["start"] == date(2026, 7, 1)


def test_attribution_by_ticker_folds_a_long_tail_into_other(seeded, book):
    """A ninth series is never given its own colour - it becomes 'Other'."""
    for i, ticker in enumerate(
        ["ES1 Index", "RTY1 Index", "SXO1 Index", "NK1 Index", "XP1 Index",
         "TY1 Comdty", "FV1 Comdty", "US1 Comdty", "RX1 Comdty", "EC1 Curncy"]
    ):
        _book_a_trade(seeded, book, ticker, date(2026, 6, 1), 1.0 + i * 0.1)
    seeded.commit()

    as_of = date(2026, 7, 31)
    pnl.compute_daily_pnl(seeded, book, end=as_of)
    seeded.commit()

    curves = pnl.contribution_curves(
        seeded, book, start=None, end=as_of, group_by="ticker", top_n=4
    )
    labels = [s["label"] for s in curves["series"]]
    assert "Other" in labels
    assert len(labels) <= 6           # top_n + Other + the funding sleeve
    assert labels[-1] == "Other", "Other must sort last"

    # Folding must not lose any P&L.
    for i in range(len(curves["buckets"])):
        stacked = sum(s["cumulative"][i] for s in curves["series"])
        assert stacked == pytest.approx(curves["total"][i], abs=1e-6)


def test_attribution_buckets_scale_with_the_window(seeded, book):
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 1, 5), 5.0)
    seeded.commit()
    pnl.compute_daily_pnl(seeded, book, end=date(2026, 8, 15))
    seeded.commit()

    short = pnl.contribution_curves(
        seeded, book, start=date(2026, 8, 1), end=date(2026, 8, 15), group_by="level_1"
    )
    long = pnl.contribution_curves(
        seeded, book, start=date(2026, 1, 5), end=date(2026, 8, 15), group_by="level_1"
    )
    assert short["bucket"] == "daily"
    assert long["bucket"] == "weekly"


# ---------------------------------------------------------------------------
# Presentation order and the cost of leverage
# ---------------------------------------------------------------------------
def test_asset_classes_sort_in_canonical_order(seeded, book):
    """
    Equity, then Fixed Income, then FX, then the financing leg - the order a
    macro book is discussed in. It must NOT reshuffle by size.
    """
    # Book FX and Fixed Income much larger than Equity, to prove size is not
    # what drives the ordering.
    _book_a_trade(seeded, book, "EC1 Curncy", date(2026, 6, 1), 20.0)
    _book_a_trade(seeded, book, "TY1 Comdty", date(2026, 6, 1), 15.0)
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), 1.0)
    seeded.commit()

    view = exposure.build_position_view(seeded, book, valuation_date=date(2026, 6, 30))
    assert [b["label"] for b in view["rollups"]["level_1"]] == ["Equity", "Fixed Income", "FX"]
    assert [b["label"] for b in view["hierarchy_rollup"]] == ["Equity", "Fixed Income", "FX"]


def test_unknown_asset_classes_sort_after_the_known_ones(seeded):
    order = sorted(
        ["FX", "Zzz Other", "Equity", "Cash & Funding", "Fixed Income", "Alpha"],
        key=exposure.asset_class_sort_key,
    )
    assert order[:4] == ["Equity", "Fixed Income", "FX", "Cash & Funding"]
    assert order[4:] == ["Alpha", "Zzz Other"]


def test_attribution_series_use_canonical_order(seeded, book):
    _book_a_trade(seeded, book, "EC1 Curncy", date(2026, 6, 1), 10.0)
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), 2.0)
    _book_a_trade(seeded, book, "TY1 Comdty", date(2026, 6, 1), 5.0)
    seeded.commit()

    as_of = date(2026, 7, 31)
    pnl.compute_daily_pnl(seeded, book, end=as_of)
    seeded.commit()

    curves = pnl.contribution_curves(seeded, book, start=None, end=as_of, group_by="level_1")
    labels = [s["label"] for s in curves["series"]]
    assert labels == [l for l in ["Equity", "Fixed Income", "FX", "Cash & Funding"] if l in labels]


def test_cost_of_leverage_is_the_accrual_not_the_sleeve_weight(seeded, book):
    """
    A -10% sleeve is 10% of NAV financed - a LEVERAGE measure. The cost is the
    rate applied to it, and the two must not be confused in the UI.
    """
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), 10.0)
    seeded.commit()

    view = exposure.build_position_view(seeded, book, valuation_date=date(2026, 6, 30))
    lev = view["kpis"]["leverage"]

    assert lev["financed_pct"] == pytest.approx(-10.0)
    # All-in rate = benchmark + the configured borrowing spread.
    assert lev["all_in_rate_pct"] == pytest.approx(lev["base_rate_pct"] + lev["spread_bps"] / 100.0)
    # Run rate is the rate applied to the financed notional, and it is a COST.
    assert lev["annual_run_rate_pct"] == pytest.approx(-10.0 / 100.0 * lev["all_in_rate_pct"])
    assert lev["annual_run_rate_pct"] < 0
    # It is emphatically not the sleeve weight.
    assert lev["annual_run_rate_pct"] != pytest.approx(lev["financed_pct"])
    assert lev["benchmark"] in lev["footnote"]


def test_accrued_leverage_cost_ties_to_the_funding_pnl(seeded, book):
    """The tile's accrued figure must equal the funding component of P&L."""
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), 25.0)
    seeded.commit()

    as_of = date(2026, 7, 31)
    pnl.compute_daily_pnl(seeded, book, end=as_of)
    seeded.commit()

    view = exposure.build_position_view(seeded, book, valuation_date=as_of)
    accrued = view["kpis"]["leverage"]["accrued_itd_pct"]
    components = pnl.attribution_by_component(seeded, book, None, as_of)

    assert accrued == pytest.approx(components["funding"], abs=1e-9)
    assert accrued < 0, "a financed book pays to be financed"


def test_positive_cash_sleeve_earns_rather_than_costs(seeded, book):
    """A net-short book leaves cash on deposit; the tile should show income."""
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), -8.0)
    seeded.commit()

    view = exposure.build_position_view(seeded, book, valuation_date=date(2026, 6, 30))
    lev = view["kpis"]["leverage"]
    assert lev["financed_pct"] == pytest.approx(8.0)
    assert lev["annual_run_rate_pct"] > 0


# ---------------------------------------------------------------------------
# Target history and the positioning table
# ---------------------------------------------------------------------------
def test_history_includes_positions_closed_inside_the_window(seeded, book):
    """
    A position opened and closed inside the window is part of that period's
    positioning, even though it is flat today. Omitting it would misrepresent
    the period - which is the whole reason the expander exists.
    """
    _book_a_trade(seeded, book, "NK1 Index", date(2026, 7, 6), 3.0)
    _book_a_trade(seeded, book, "NK1 Index", date(2026, 7, 20), -3.0)
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 7, 6), 5.0)
    seeded.commit()

    history = positions.target_history(seeded, book, date(2026, 7, 1), date(2026, 7, 31))
    assert "NK1 Index" in history, "a position closed in the window must still appear"

    legs = history["NK1 Index"]
    assert [l.target_pct for l in legs] == pytest.approx([3.0, 0.0])
    assert legs[-1].is_closing_flat is True

    # And it is flat now, so it would NOT appear in a plain current-positions view.
    assert "NK1 Index" not in positions.net_weights_as_of(seeded, book, date(2026, 7, 31))


def test_history_opens_with_the_weight_carried_into_the_window(seeded, book):
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 5, 4), 6.0)
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 7, 15), -2.0)
    seeded.commit()

    legs = positions.target_history(seeded, book, date(2026, 7, 1), date(2026, 7, 31))["ES1 Index"]
    assert legs[0].is_opening is True
    assert legs[0].target_pct == pytest.approx(6.0)
    assert legs[0].effective_from == date(2026, 7, 1), "carried-in leg starts at the window edge"
    assert legs[0].effective_to == date(2026, 7, 14)
    assert legs[1].delta_pct == pytest.approx(-2.0)
    assert legs[1].target_pct == pytest.approx(4.0)


def test_history_respects_the_selected_window(seeded, book):
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 5, 4), 6.0)
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 10), 2.0)
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 8, 3), -3.0)
    seeded.commit()

    august = positions.target_history(seeded, book, date(2026, 8, 1), date(2026, 8, 31))["ES1 Index"]
    # June's change is before the window: it shows only as the carried-in weight.
    assert len(august) == 2
    assert august[0].target_pct == pytest.approx(8.0)
    assert august[1].target_pct == pytest.approx(5.0)

    since_may = positions.target_history(seeded, book, date(2026, 5, 1), date(2026, 8, 31))["ES1 Index"]
    assert len(since_may) == 3, "a wider window exposes the June change too"


def test_leg_pnl_partitions_the_window_contribution(seeded, book):
    """
    Legs tile the window, so their P&L must sum to the instrument's total
    contribution over that window - no gaps, no double counting.
    """
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), 6.0)
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 7, 10), -2.0)
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 7, 24), 3.0)
    seeded.commit()

    start, end = date(2026, 7, 1), date(2026, 7, 31)
    pnl.compute_daily_pnl(seeded, book, end=end)
    seeded.commit()

    legs = positions.target_history(seeded, book, start, end)["ES1 Index"]
    daily = pnl.ticker_daily_totals(seeded, book, start, end)["ES1 Index"]

    leg_sum = sum(pnl.leg_total(daily, l.effective_from, l.effective_to) for l in legs)
    assert leg_sum == pytest.approx(sum(daily.values()), abs=1e-9)


def test_position_view_widens_the_row_set_with_history(seeded, book):
    _book_a_trade(seeded, book, "NK1 Index", date(2026, 7, 6), 3.0)
    _book_a_trade(seeded, book, "NK1 Index", date(2026, 7, 20), -3.0)
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 7, 6), 5.0)
    seeded.commit()

    kwargs = dict(
        valuation_date=date(2026, 7, 31),
        window_start=date(2026, 7, 1),
        window_end=date(2026, 7, 31),
    )
    plain = exposure.build_position_view(seeded, book, **kwargs)
    with_history = exposure.build_position_view(seeded, book, include_history=True, **kwargs)

    plain_tickers = {r["ticker"] for r in plain["rows"]}
    hist_tickers = {r["ticker"] for r in with_history["rows"]}
    assert "NK1 Index" not in plain_tickers
    assert "NK1 Index" in hist_tickers

    nikkei = next(r for r in with_history["rows"] if r["ticker"] == "NK1 Index")
    assert nikkei["net_weight_pct"] == pytest.approx(0.0)
    assert len(nikkei["target_history"]) == 2
    assert all("leg_pnl_pct" in leg for leg in nikkei["target_history"])


def test_positioning_table_matches_the_chart_grouping_and_order(seeded, book):
    """
    The table under the chart must use the same keys IN THE SAME ORDER, because
    the UI colours rows by series index. If these diverge, a bar and its rows
    get different colours - which is worse than no colour at all.
    """
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), 5.0)
    _book_a_trade(seeded, book, "TY1 Comdty", date(2026, 6, 1), 3.0)
    _book_a_trade(seeded, book, "EC1 Curncy", date(2026, 6, 1), 2.0)
    seeded.commit()

    as_of = date(2026, 7, 31)
    pnl.compute_daily_pnl(seeded, book, end=as_of)
    seeded.commit()

    for group_by in ("level_1", "level_2", "ticker"):
        chart = pnl.contribution_curves(
            seeded, book, start=None, end=as_of, group_by=group_by
        )
        table = pnl.positioning_table(
            seeded, book, start=None, end=as_of, group_by=group_by
        )
        assert [s["key"] for s in chart["series"]] == [s["key"] for s in table["series"]], group_by


def test_positioning_table_contributions_tie_to_the_period_total(seeded, book):
    _book_a_trade(seeded, book, "ES1 Index", date(2026, 6, 1), 5.0)
    _book_a_trade(seeded, book, "RX1 Comdty", date(2026, 6, 1), -3.0)
    seeded.commit()

    as_of = date(2026, 7, 31)
    pnl.compute_daily_pnl(seeded, book, end=as_of)
    seeded.commit()

    table = pnl.positioning_table(seeded, book, start=None, end=as_of, group_by="level_1")
    reported = pnl.period_total(seeded, book, None, as_of)
    assert table["total_contribution_pct"] == pytest.approx(reported, abs=1e-9)

    # And each series total equals the sum of its rows.
    for s in table["series"]:
        assert s["contribution_pct"] == pytest.approx(
            sum(r["contribution_pct"] for r in s["rows"]), abs=1e-9
        )


def test_positioning_table_flags_positions_closed_in_the_window(seeded, book):
    _book_a_trade(seeded, book, "NK1 Index", date(2026, 6, 5), 3.0)
    _book_a_trade(seeded, book, "NK1 Index", date(2026, 7, 6), -3.0)
    seeded.commit()

    as_of = date(2026, 7, 31)
    pnl.compute_daily_pnl(seeded, book, end=as_of)
    seeded.commit()

    table = pnl.positioning_table(seeded, book, start=None, end=as_of, group_by="ticker")
    rows = [r for s in table["series"] for r in s["rows"]]
    nikkei = next(r for r in rows if r["ticker"] == "NK1 Index")
    assert nikkei["closed_in_window"] is True
    assert nikkei["end_target_pct"] == pytest.approx(0.0)
    assert nikkei["changes"] >= 1


# ---------------------------------------------------------------------------
# Bloomberg security-string normalisation
# ---------------------------------------------------------------------------
def test_parse_security_string_converts_terminal_notation():
    """
    //blp/instruments answers in yellow-key bracket notation; //blp/refdata
    will not accept it. The old code did `sec.strip("<>")`, which only removes
    LEADING and TRAILING characters - so "SPX<index>" became "SPX<index",
    an unusable ticker that also broke the "no yellow key" guard downstream.
    """
    from app.bloomberg.base import parse_security_string as parse

    assert parse("SPX<index>") == ("SPX Index", "Index")
    assert parse("SPXT<index>") == ("SPXT Index", "Index")
    assert parse("AAPL US<equity>") == ("AAPL US Equity", "Equity")
    assert parse("TY1<comdty>") == ("TY1 Comdty", "Comdty")
    assert parse("EURUSD<curncy>") == ("EURUSD Curncy", "Curncy")
    assert parse("G 1<comdty>") == ("G 1 Comdty", "Comdty")   # space inside root
    assert parse("T 4 08/15/35<govt>") == ("T 4 08/15/35 Govt", "Govt")


def test_parse_security_string_is_idempotent_and_safe():
    from app.bloomberg.base import parse_security_string as parse

    # Already canonical -> unchanged.
    assert parse("ES1 Index") == ("ES1 Index", "Index")
    assert parse(parse("SPX<index>")[0]) == ("SPX Index", "Index")
    # Nothing usable.
    assert parse("") == ("", "")
    assert parse("<index>") == ("", "")
    # No yellow key to infer - returned as-is, and create_adhoc rejects it.
    assert parse("SPX") == ("SPX", "")
    # A "<" must never survive into a stored ticker.
    for raw in ("SPX<index>", "SPX<", "<SPX>", "A<b>c"):
        assert "<" not in parse(raw)[0] and ">" not in parse(raw)[0]


def test_search_matches_punctuation_free_queries(seeded):
    """`sp500` has to find `S&P 500 E-mini`; the literal LIKE never could."""
    from app.services import instruments

    hits = instruments.search(seeded, "sp500", limit=10)
    names = [h.instrument_name for h in hits]
    assert any("S&P 500" in n for n in names), names

    # Ticker root without the yellow key still ranks first.
    top = instruments.search(seeded, "es1", limit=5)
    assert top and top[0].bbg_ticker == "ES1 Index"

    # A query matching nothing returns nothing rather than the whole master.
    assert instruments.search(seeded, "zzzzznotathing", limit=10) == []


def test_search_token_and_tenor_matching(seeded):
    """Multi-word and abbreviated-tenor queries have to land."""
    from app.services import instruments

    def tickers(q):
        return [h.bbg_ticker for h in instruments.search(seeded, q, limit=6)]

    # Word order must not matter.
    assert "XM1 Comdty" in tickers("10y treasury")
    assert "XM1 Comdty" in tickers("treasury 10y")
    # "10yr" and "10-year" both normalise to the master's "10Y".
    assert "TY1 Comdty" in tickers("10yr treasury note")
    assert tickers("10yr")            # tenor alone still finds the 10Y block
    # A single junk word does not open the floodgates.
    assert instruments.search(seeded, "zzzz", limit=10) == []


# ---------------------------------------------------------------------------
# Trade editing
# ---------------------------------------------------------------------------
def _book_one(db, book, *, weight=4.0, day=None):
    from datetime import date as _date

    from app.models import ExecutionType
    from app.services import trades

    return trades.save_trade(
        db,
        trades.TradeRequest(
            portfolio_id=book.portfolio_id,
            bbg_ticker="ES1 Index",
            trade_date=day or _date(2026, 6, 10),
            weight_pct=weight,
            execution_type=ExecutionType.MKT_CLOSE,
            actor="pytest",
        ),
    )


def test_edit_changes_weight_and_rebuilds_the_book(seeded, book):
    from datetime import date

    from app.services import exposure, trades

    trade = _book_one(seeded, book, weight=4.0)
    seeded.flush()

    updated, _ = trades.edit_trade(
        seeded, trade, trades.TradeEdit(weight_pct=6.5, reason="wrong size", actor="pytest")
    )
    assert updated.id == trade.id, "the trade must keep its id so the audit trail stays connected"
    assert updated.weight_delta_pct == 6.5
    assert updated.edited_at is not None

    # The funding sleeve must have followed the change, so the book still nets to 0.
    view = exposure.build_position_view(seeded, book, valuation_date=date(2026, 6, 30))
    kpis = view["kpis"]
    assert round(kpis["total"]["net_pct"], 6) == 6.5
    assert round(kpis["book_nets_to"], 6) == 0.0
    seeded.rollback()


def test_edit_repricing_never_carries_a_price_across_a_date_change(seeded, book):
    """
    An execution level is a claim that a price was observed on a specific day.
    Moving the trade date must re-resolve it, not reuse the old number.
    """
    from datetime import date

    from app.services import trades

    trade = _book_one(seeded, book, day=date(2026, 6, 10))
    seeded.flush()
    original_level = trade.execution_level
    original_obs = trade.price_observation_date

    updated, _ = trades.edit_trade(
        seeded, trade, trades.TradeEdit(trade_date=date(2026, 6, 17), actor="pytest")
    )
    assert updated.trade_date == date(2026, 6, 17)
    assert updated.price_observation_date != original_obs
    assert updated.execution_level != original_level
    seeded.rollback()


def test_edit_is_audited_as_a_before_after_diff(seeded, book):
    import json

    from sqlalchemy import select

    from app.models import AuditLog

    from app.services import trades

    trade = _book_one(seeded, book, weight=4.0)
    seeded.flush()
    trades.edit_trade(
        seeded, trade, trades.TradeEdit(weight_pct=-2.0, reason="flipped short", actor="pytest")
    )
    seeded.flush()

    event = seeded.scalars(
        select(AuditLog).where(AuditLog.action == "edit").order_by(AuditLog.id.desc())
    ).first()
    assert event is not None
    detail = json.loads(event.detail_json)
    changed = detail["changed"]
    assert changed["weight_delta_pct"]["from"] == 4.0
    assert changed["weight_delta_pct"]["to"] == -2.0
    assert detail["reason"] == "flipped short"
    seeded.rollback()


def test_a_voided_trade_cannot_be_edited_until_restored(seeded, book):
    import pytest as _pytest

    from app.services import trades

    trade = _book_one(seeded, book)
    seeded.flush()
    trades.void_trade(seeded, trade, reason="wrong book", actor="pytest")
    seeded.flush()

    with _pytest.raises(trades.TradeError) as exc:
        trades.edit_trade(seeded, trade, trades.TradeEdit(weight_pct=1.0, actor="pytest"))
    assert "voided" in str(exc.value).lower()

    trades.restore_trade(seeded, trade, actor="pytest")
    assert trade.is_void is False
    updated, _ = trades.edit_trade(seeded, trade, trades.TradeEdit(weight_pct=1.0, actor="pytest"))
    assert updated.weight_delta_pct == 1.0
    seeded.rollback()


def test_edit_rejects_a_zero_weight(seeded, book):
    import pytest as _pytest

    from app.services import trades

    trade = _book_one(seeded, book)
    seeded.flush()
    with _pytest.raises(trades.TradeError) as exc:
        trades.edit_trade(seeded, trade, trades.TradeEdit(weight_pct=0.0, actor="pytest"))
    assert "non-zero" in str(exc.value).lower()
    seeded.rollback()


# ---------------------------------------------------------------------------
# Positioning timeline (the stacked bar chart under the cumulative P&L)
# ---------------------------------------------------------------------------
def test_positioning_series_shares_the_attribution_axis(seeded, book):
    """
    The two charts sit on top of each other and must not drift apart. Buckets
    and series order come from the same two functions, and this asserts it for
    every grouping rather than trusting that they stay in step.
    """
    from datetime import date

    from app.models import ExecutionType
    from app.services import pnl, trades

    for ticker, weight, day in (
        ("ES1 Index", 5.0, date(2026, 6, 1)),
        ("TY1 Comdty", 3.0, date(2026, 6, 8)),
        ("ES1 Index", -2.0, date(2026, 6, 22)),
    ):
        trades.save_trade(
            seeded,
            trades.TradeRequest(
                portfolio_id=book.portfolio_id,
                bbg_ticker=ticker,
                trade_date=day,
                weight_pct=weight,
                execution_type=ExecutionType.MKT_CLOSE,
                actor="pytest",
            ),
        )
    seeded.flush()

    start, end = date(2026, 6, 1), date(2026, 7, 31)
    pnl.compute_daily_pnl(seeded, book, end=end)

    for group_by in ("level_1", "level_2", "ticker"):
        curves = pnl.contribution_curves(
            seeded, book, start=start, end=end, group_by=group_by
        )
        timeline = pnl.positioning_series(
            seeded, book, start=start, end=end, group_by=group_by
        )
        assert timeline["buckets"] == curves["buckets"], f"x-axis drifted for {group_by}"
        assert [s["key"] for s in timeline["series"]] == [s["key"] for s in curves["series"]], (
            f"series order drifted for {group_by}, so the colours would not match"
        )
    seeded.rollback()


def test_positioning_series_nets_to_zero_including_funding(seeded, book):
    """
    Every column must net to zero, because the funding sleeve is by definition
    the negative of the market book. A column that does not is a bug in the
    sleeve, and this chart is where it would be visible.
    """
    from datetime import date

    from app.models import ExecutionType
    from app.services import pnl, trades

    trades.save_trade(
        seeded,
        trades.TradeRequest(
            portfolio_id=book.portfolio_id,
            bbg_ticker="ES1 Index",
            trade_date=date(2026, 6, 1),
            weight_pct=7.0,
            execution_type=ExecutionType.MKT_CLOSE,
            actor="pytest",
        ),
    )
    seeded.flush()
    end = date(2026, 6, 30)
    pnl.compute_daily_pnl(seeded, book, end=end)

    timeline = pnl.positioning_series(seeded, book, start=date(2026, 6, 1), end=end)
    assert timeline["buckets"], "the period should produce at least one bucket"
    for i, net in enumerate(timeline["net_pct"]):
        assert abs(net) < 1e-6, f"bucket {timeline['buckets'][i]} nets to {net}, not 0"
    # And the market side is genuinely there, not all zeros.
    assert max(timeline["gross_pct"]) > 0
    seeded.rollback()


def test_positioning_series_reports_a_level_not_a_flow(seeded, book):
    """
    A weight held flat all month must show the SAME height in every column.
    Summing trades instead of reading the target would show one tall bar and
    then nothing, which is the classic way this chart goes wrong.
    """
    from datetime import date

    from app.models import ExecutionType
    from app.services import pnl, trades

    trades.save_trade(
        seeded,
        trades.TradeRequest(
            portfolio_id=book.portfolio_id,
            bbg_ticker="ES1 Index",
            trade_date=date(2026, 6, 2),
            weight_pct=4.0,
            execution_type=ExecutionType.MKT_CLOSE,
            actor="pytest",
        ),
    )
    seeded.flush()
    end = date(2026, 6, 30)
    pnl.compute_daily_pnl(seeded, book, end=end)

    timeline = pnl.positioning_series(seeded, book, start=date(2026, 6, 2), end=end)
    equity = next(s for s in timeline["series"] if s["key"] == "Equity")
    assert equity["weights"], "the equity series should have values"
    assert all(abs(w - 4.0) < 1e-9 for w in equity["weights"]), equity["weights"]
    seeded.rollback()


def test_edit_carries_a_custom_level_across_a_date_change(seeded, book):
    """
    Custom means "there is no official print, I supplied this". So a date change
    must NOT demand the number again - it carries, with a warning. Demanding it
    is only correct when the trade is BECOMING Custom.
    """
    from datetime import date

    import pytest as _pytest

    from app.models import ExecutionType
    from app.services import trades

    custom = trades.save_trade(
        seeded,
        trades.TradeRequest(
            portfolio_id=book.portfolio_id,
            bbg_ticker="ES1 Index",
            trade_date=date(2026, 6, 10),
            weight_pct=3.0,
            execution_type=ExecutionType.CUSTOM,
            custom_level=5432.5,
            actor="pytest",
        ),
    )
    seeded.flush()

    updated, messages = trades.edit_trade(
        seeded, custom, trades.TradeEdit(trade_date=date(2026, 6, 17), actor="pytest")
    )
    assert updated.execution_level == 5432.5
    assert any("Kept the custom level" in m for m in messages)

    # Becoming Custom without a level is still refused.
    mkt = trades.save_trade(
        seeded,
        trades.TradeRequest(
            portfolio_id=book.portfolio_id,
            bbg_ticker="TY1 Comdty",
            trade_date=date(2026, 6, 10),
            weight_pct=2.0,
            execution_type=ExecutionType.MKT_CLOSE,
            actor="pytest",
        ),
    )
    seeded.flush()
    with _pytest.raises(trades.TradeError) as exc:
        trades.edit_trade(
            seeded, mkt, trades.TradeEdit(execution_type=ExecutionType.CUSTOM, actor="pytest")
        )
    assert "requires a level" in str(exc.value)
    seeded.rollback()
