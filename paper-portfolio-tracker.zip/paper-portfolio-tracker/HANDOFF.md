# Handoff — what to do next, on the machine with the Terminal

This scaffold was built and tested **without** a Bloomberg connection, against a
deterministic synthetic market-data provider. Everything above
`app/bloomberg/base.py` is fully exercised: 82 tests pass, the demo book loads,
the UI runs end to end.

What has **not** been executed against live data is `app/bloomberg/blpapi_provider.py`.
That is the work that has to happen on your machine, and this document is the
punch list for it.

Hand this file to Claude Code (or work through it yourself) in the repo root on
the Windows box where you log into Bloomberg Anywhere.

---

## 0. Environment sanity — do this first

The single most common failure is a Python environment where `blpapi` imports
but cannot reach `bbcomm`.

```powershell
# native Windows Python, NOT WSL - see README for why
python -c "import sys; print(sys.version, sys.executable)"
pip install --index-url=https://blpapi.bloomberg.com/repository/releases/python/simple/ blpapi
python -c "import blpapi; print(blpapi.__version__)"

# is bbcomm actually listening?
netstat -ano | findstr 8194
```

Then:

```powershell
pip install -r requirements.txt
python scripts/init_db.py
python -m pytest tests/ -q          # must be 82 passed, still on synthetic data
```

If the tests fail here, fix that before touching Bloomberg — it means an
environment problem, not an integration problem.

---

## 1. Turn on live data

With the Terminal running, just start the app — `provider: auto` (the default)
detects it and starts in **Live** mode:

```powershell
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Startup logs `Data mode: LIVE (Bloomberg Desktop API on 127.0.0.1:8194)`, the
header shows **LIVE** selected with a green *Bloomberg live* pill, and the amber
offline banner is gone.

You can flip between **Live** and **Offline** in the header at any time; the
choice persists across restarts. The caches are scoped by provider, so switching
never mixes real and synthetic prices.

Two config choices worth making deliberately:

* `provider: "blpapi"` — start live or **refuse to start**. Use this on a
  production box so a missing Terminal is loud rather than a silent downgrade.
* `provider: "fake"` — always offline and the Live toggle is hard-disabled. Use
  this for machines that must not talk to Bloomberg at all.

`/api/data-mode` returns the same information as JSON, including why live is
unavailable when it is.

**Start a fresh book for live.** The demo book's trades were priced offline, and
execution levels are never rewritten. `python scripts/reset_for_live.py --yes`
archives the old database and gives you a clean one. If you don't, the app shows
a red *Mixed data sources* banner — which is the correct warning, not a bug.

---

## 2. The six things most likely to need adjusting

These are the specific places where a live Terminal is likely to disagree with
the code as written. Each is isolated to a few lines.

### 2.1 `instrumentListRequest` filter syntax
`app/bloomberg/blpapi_provider.py` → `search()`

The yellow-key filter block is written defensively (it checks
`hasElement("filterRequest")` before setting) because the exact element name has
varied across SDK versions. Verify against your SDK and simplify. Also confirm
whether your results come back wrapped in `<>` — the code strips them; check it
is not stripping something meaningful.

### 2.2 `REFERENCE_DATE` override on `ReferenceDataRequest`
`app/bloomberg/blpapi_provider.py` → `reference()`

Not every field honours the override; those that don't return the current value.
The as-of date is stored alongside the cached value so the audit trail stays
honest either way — but confirm which of the duration fields actually respect it
for your instruments, and adjust `analytics.duration.field_priority` if a
different field behaves better historically.

### 2.3 Duration fields per instrument type
`config/settings.yaml` → `analytics.duration.field_priority`

Priority as shipped: `FUT_EQV_DUR_NOTL`, `DUR_ADJ_MID`, `DUR_MID`.

Check what actually returns a value for each family in the master:

| Family | Example | Expect |
|---|---|---|
| US Treasury futures | `TY1 Comdty` | should return direct |
| Bund / Gilt / JGB | `RX1 Comdty`, `G 1 Comdty`, `JB1 Comdty` | may need a different field |
| Eris SOFR swap futures | `YIYA Comdty` | check |
| Credit futures | `IQBA Index`, `HYBA Index` | likely falls to proxy |
| MBS TBA futures | `JYAA Comdty` | likely falls to proxy |

Anything that lands on `proxy` shows an amber tag in the UI. Move families from
proxy to direct where a real field exists; update
`config/duration_proxies.yaml` for the ones that genuinely have none.

**Quick check once live:**
```powershell
python -c "from app.db import session_scope; from app.bloomberg import get_provider; \
from app.config import settings; \
ts=['TY1 Comdty','RX1 Comdty','G 1 Comdty','JB1 Comdty','YIYA Comdty','IQBA Index','JYAA Comdty']; \
print(get_provider().reference(ts, settings.analytics.duration.field_priority))"
```

### 2.4 Live-price cadence

`config/settings.yaml` → `bloomberg.live_refresh_*`

Dates within `live_refresh_window_days` of today are re-requested from Bloomberg
before any execution level or current mark is resolved; older dates are served
from settled cache. `live_refresh_ttl_minutes` throttles repeat requests.

Decide the cadence you actually want:

* **active trading screen** — set `live_refresh_ttl_minutes: 0`. Every lookup
  hits the Terminal. Confirm the Terminal is comfortable with the request rate
  for your instrument count (the demo book is ~14 tickers; a 100-name book at
  zero throttle with several users is a different proposition).
* **default** — 15 minutes is a reasonable compromise.
* **production book** — also set `require_live_execution_prices: true`, so a
  same-day trade is refused rather than booked off cached data if the Terminal
  is not reachable. Turn it **off** while backfilling history, or every
  backfilled row will fail.

Verify once live: book a trade dated today and check the tag beside the level
box reads **live**, then book one dated three months ago and check it reads
**cached**. The same distinction appears per row in Trade History, and is
persisted on the trade as `price_from_live_request` / `price_provider`.

Also worth confirming on a real Terminal: `HistoricalDataRequest` for *today*
returns the intraday `PX_LAST` before the official settle publishes. If you want
same-day trades to mark off the last trade rather than wait for settle, that is
already the behaviour (`PX_SETTLE` is tried first and falls through to
`PX_LAST`), but check what your contracts actually return mid-session.

### 2.5 `PX_SETTLE` vs `PX_LAST` coverage
`config/settings.yaml` → `bloomberg.close_field_priority`

Settle is the official futures mark, so it is tried first. Confirm every family
in the master publishes one — the credit and MBS index futures (`IQBA Index`,
`HYBA Index`, `JYAA Comdty`) are the ones worth checking. The code already falls
through to `PX_LAST`; you just want to know which field is actually being used,
and it is recorded on every trade.

### 2.6 Generic vs specific contracts
The master uses generic front-month tickers (`ES1 Index`, `TY1 Comdty`). Those
roll, which introduces a price discontinuity on the roll date that will show up
as spurious P&L.

**This is the most important open modelling question in the application.**
Options, roughly in order of effort:

* accept it for a paper book (defensible, but document it);
* use the ratio- or difference-adjusted generic series where Bloomberg offers
  one, so the history is continuous;
* store the specific contract on each trade and handle rolls explicitly.

`app/services/pricing.py` is the only module that would change.

---

## 3. Validation pass against live data

Once it is connected, walk this list. Each item has a specific thing to look at.

1. **Reload the master** (Settings → Instrument Master) with the real
   `bloomberg_futures_hierarchy` file if it has changed since the copy in
   `data/seed/`. Confirm the added/updated/deactivated counts look right.

2. **Price coverage.** Load the demo book (`python scripts/load_demo_data.py`)
   and check the provenance banner on Positions. Any ticker in
   *unpriced instruments* is a master error or a Bloomberg permission gap —
   find out which.

3. **Holiday fallback.** Book a `Mkt Close` trade in `NK1 Index` on a Japanese
   public holiday and in `RX1 Comdty` on a Eurex holiday. The level box should
   show an amber `stale Nd` tag naming the prior print date. Confirm the date it
   picked is genuinely the last Tokyo/Frankfurt session.

4. **`Mkt Open` coverage.** Book an open trade in a few families. Anything that
   falls to rule 2 (prior close) does not publish `PX_OPEN` — decide whether
   that fallback is acceptable for that family or whether an intraday field
   would be better.

5. **Duration sanity.** Analytics → Fixed income duration detail. Every row
   should be `direct` or a `proxy` you are comfortable with. Compare the
   aggregate duration target against your own calculation for the same book.

6. **Volatility sanity.** Annualised realised vol over ~3 months should land
   roughly: equity index 12–20%, 10y govvie futures 4–7%, G10 FX 6–10%, VIX
   futures much higher. Anything far outside that is a price-series problem
   (very likely a roll — see 2.6).

7. **Reconciliation.** P&L tab. The compounding residual should be small
   relative to total P&L. A large residual with `clean: true` means a long
   holding period or high vol; with `clean: false` it means missing prices.

8. **Import a real file.** Take an actual historical book, run it through
   Trade History mode, and check the preview surfaces exactly the rows you
   expect to be problematic.

---

## 4. Things to build next (my recommended order)

1. **Alembic migrations** — before any schema change hits a shared database.
   Nothing else in this list is safe without it.
2. **Resolve the generic-contract roll question** (2.6). It affects P&L, vol and
   every chart.
3. **Authentication** — replace `_actor()` in `app/routers/api.py`. One function.
4. **NAV series → dollar P&L.** The engine is already in percent-of-NAV; adding a
   NAV time series turns every number into currency without touching the maths.
5. **Covariance matrix → true portfolio volatility**, marginal contribution to
   risk, and beta. The biggest analytics upgrade available.
6. **Scenario / what-if.** `positions.run_lot_engine` is a pure function that
   takes trades and returns lot books — a what-if screen is mostly UI.

---

## 5. If you want to change the P&L convention

The application uses a **target-weight daily contribution series** (see README →
P&L methodology). If your house convention is **fixed-notional from entry**, the
change is localised to `compute_daily_pnl` in `app/services/pnl.py`:

instead of scaling the daily price change by the prior close,

```
carry(i,d) = W_open × ( P(d)/P(d−1) − 1 )
```

scale it by each lot's own entry level,

```
carry(i,d) = Σ over open lots of  w_lot × ( P(d) − P(d−1) ) / L_lot
```

which telescopes exactly onto `w × (P_n/L − 1)` — so realised + unrealised and
the daily series would then reconcile to zero residual. It costs you additivity
of weights and makes the daily number depend on the lot mix. Both conventions
are defensible; pick one deliberately and write it in the README.

`test_realised_and_unrealised_reconcile_with_the_daily_series` in
`tests/test_engine.py` is where you would tighten the tolerance to `0` if you
make this change.

---

## 6. Where to look when something breaks

| Symptom | File |
|---|---|
| wrong or missing execution level | `app/services/pricing.py` |
| book does not net to zero | `app/services/positions.py` → `rebuild_funding_offset` |
| P&L looks wrong | `app/services/pnl.py` → `compute_daily_pnl` |
| duration tagged proxy when it should be direct | `app/services/duration.py` + `config/settings.yaml` |
| volatility implausible | `app/services/volatility.py`, then check for a contract roll |
| import rejects a valid row | `app/services/imports.py` → `validate_rows` |
| a number on screen you cannot explain | click the row — the detail modal has the provenance |
| anything at all | `audit_log`, via Trade History → Audit trail |

Startup logs print the resolved data root and database path. The Settings screen
shows them too.
