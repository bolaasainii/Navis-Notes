# TAA-Notepad

*Paper portfolio, target book and P&L tracker.*

An internal web application for managing paper portfolios, trade history, target
books and trade-/portfolio-level P&L across macro and cross-asset instruments.

Python + FastAPI backend, SQLite storage, server-rendered Jinja templates with
plain ES modules on the front end. Bloomberg data is retrieved through BLPAPI on
the **server only**. There is no build toolchain, no npm dependency tree and no
public cloud requirement.

---

## Contents

1. [Quick start](#quick-start)
2. [Architecture](#architecture)
3. [Repointing the shared drive](#repointing-the-shared-drive)
4. [Bloomberg integration approach](#bloomberg-integration-approach)
5. [Live / Offline data mode](#live--offline-data-mode)
6. [Live prices vs cached history](#live-prices-vs-cached-history)
7. [Pricing logic and holiday fallback](#pricing-logic-and-holiday-fallback)
8. [Trade-entry behaviour](#trade-entry-behaviour)
9. [CSV import modes](#csv-import-modes)
10. [Funding / leverage offset](#funding--leverage-offset)
11. [P&L methodology](#pl-methodology)
12. [Duration methodology](#duration-methodology)
13. [Standalone volatility methodology](#standalone-volatility-methodology)
14. [Exposure aggregation](#exposure-aggregation)
15. [Auditability](#auditability)
16. [Data model](#data-model)
17. [Security posture](#security-posture)
18. [Adding authentication later](#adding-authentication-later)
19. [Testing](#testing)
20. [Known limitations and next steps](#known-limitations-and-next-steps)

---

## Quick start

```bash
python -m venv .venv
.venv\Scripts\activate            # Windows
pip install -r requirements.txt

python scripts/init_db.py         # creates the DB, seeds the instrument master
python scripts/load_demo_data.py  # optional: a worked demonstration book
                                  # (synthetic prices - do NOT mix with a live book)

python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open <http://127.0.0.1:8000>.

The application starts in **Offline** mode (synthetic prices) on any machine
without Bloomberg, and switches itself to **Live** when a Terminal is detected.
Use the **Live | Offline** toggle in the header to change modes at any time —
see [Live / Offline data mode](#live--offline-data-mode).

For live data you also need the Bloomberg package, which is not on PyPI:

```bash
pip install --index-url=https://blpapi.bloomberg.com/repository/releases/python/simple/ blpapi
```

**Going live for the first time?** Run `python scripts/reset_for_live.py --yes`
instead of `load_demo_data.py`. The demo book's trades were priced offline, and
execution levels are never rewritten, so mixing them with live marks produces
meaningless P&L. The app detects that condition and shows a red banner rather
than rendering it quietly.

> **Windows / WSL note.** The Bloomberg Terminal is Windows-only and `bbcomm`
> binds to `127.0.0.1:8194`. A process running inside WSL is in a different
> network namespace and will not see that socket unless WSL mirrored networking
> is enabled. Run this service **natively on Windows**, in the same Python
> environment where `blpapi` is installed.

---

## Architecture

```
config/                    settings.yaml, funding curve, duration proxies
  settings.yaml            <- every path and tunable lives here

app/
  config.py                typed settings loader (+ PPT_* env overrides)
  db.py                    SQLAlchemy engine / session
  models.py                ORM schema - the durable record of the book
  schemas.py               pydantic request/response models
  main.py                  FastAPI app, startup seeding

  bloomberg/
    base.py                MarketDataProvider interface  <- everything above
    blpapi_provider.py     real Desktop API                  this line is
    fake_provider.py       deterministic synthetic data       provider-agnostic
    __init__.py            provider factory (blpapi | fake | auto)

  services/                all business logic; no HTTP, no HTML
    instruments.py         master ingestion, resolution, search
    pricing.py             price cache + execution-level resolution & fallback
    positions.py           FIFO lot engine + funding sleeve maintenance
    funding.py             effective-dated benchmark curve and accrual
    pnl.py                 daily contribution series, periods, reconciliation
    duration.py            duration sourcing hierarchy
    volatility.py          realised standalone volatility
    exposure.py            composes the position view and every aggregate
    imports.py             two-phase CSV/XLSX import, both modes
    portfolios.py          lifecycle: create, clone, archive
    trades.py              trade entry and the recalculation cascade
    audit.py               append-only audit log

  routers/
    api.py                 JSON API
    pages.py               Jinja page shells

  templates/               6 page templates + a shared base
  static/css/app.css       the whole design system, CSS custom properties
  static/js/*.js           plain ES modules, one per page

data/
  seed/                    bloomberg_futures_hierarchy.csv (canonical taxonomy)
  templates/, samples/     downloadable CSV templates and worked samples
  db/                      the SQLite file
  imports/                 archived copies of every uploaded file

scripts/                   init_db.py, load_demo_data.py
tests/                     112 tests, no Terminal required
```

**Layering rule.** Routers call services; services call the provider interface
and the ORM. Nothing above `app/bloomberg/base.py` knows BLPAPI exists. That is
what allows the entire engine to be unit-tested offline, and it is also what
keeps Bloomberg strictly server-side.

**Front end.** Each page is a small server-rendered shell; the dense grids fetch
JSON from `/api` and render it client-side. No framework, no bundler, nothing to
audit in a supply-chain review beyond the Python dependencies.

---

## Repointing the shared drive

Search the codebase for the exact string:

```
REPOINT SHARED DRIVE LATER
```

It appears in `config/settings.yaml`, `app/config.py`, `app/db.py`,
`app/services/instruments.py`, `app/services/imports.py`,
`app/routers/pages.py`, `app/routers/api.py`, `app/main.py`, `scripts/init_db.py`
and this README.

**Every** filesystem path used by the application is declared in one block:

```yaml
paths:
  data_root: "data"
  database_path: "data/db/paper_portfolio.sqlite"
  instrument_master_seed: "data/seed/bloomberg_futures_hierarchy.csv"
  import_archive_dir: "data/imports"
  templates_dir: "data/templates"
  samples_dir: "data/samples"
```

To move onto an internal share:

1. Stop the service.
2. Edit `config/settings.yaml`:
   ```yaml
   paths:
     data_root: "\\\\corp-fs01\\Investments\\MacroPaperBook"
     database_path: "\\\\corp-fs01\\Investments\\MacroPaperBook\\ppt.sqlite"
   ```
   or set environment variables instead — `PPT_PATHS__DATABASE_PATH=...`
   (double underscore separates nesting; useful for keeping UAT and production
   on one codebase).
3. Copy the existing `.sqlite` file to the new location.
4. In `app/db.py`, set `SHARED_DRIVE_JOURNAL_MODE = "DELETE"`. WAL journalling
   is not reliable on all SMB shares; the code already falls back automatically
   and logs when it does, but setting it explicitly avoids the warning.
5. Restart. The current paths are printed at startup and displayed on the
   Settings screen so you can confirm at a glance.

**No code change is required.** Absolute paths, including Windows UNC paths, are
used verbatim.

Operational notes for shared-drive SQLite: the concurrency model is
single-writer, which suits a small team doing occasional trade entry and a lot
of reading. Take a copy of the `.sqlite` file before any bulk import. If you
outgrow it, the ORM means moving to PostgreSQL is a connection-string change
plus a migration, with no business-logic changes.

---

## Bloomberg integration approach

**Services used**

| Service | Request | Used for |
|---|---|---|
| `//blp/refdata` | `HistoricalDataRequest` | daily OHLC / settle history |
| `//blp/refdata` | `ReferenceDataRequest` | duration and other reference fields |
| `//blp/instruments` | `instrumentListRequest` | security search beyond the master |

**Session model.** One long-lived session per process, started lazily, with
auto-restart on disconnection. Requests are chunked (50 securities for
historical, 100 for reference) to stay inside BLPAPI limits.

**Field priority.** Configured in `settings.yaml`, not hard-coded:

* close: `PX_SETTLE` then `PX_LAST` — settle is the official mark for a futures
  contract; `PX_LAST` covers instruments that do not publish one
* open: `PX_OPEN`
* duration: `FUT_EQV_DUR_NOTL`, then `DUR_ADJ_MID`, then `DUR_MID`

The field actually used is recorded on every trade and every cached value.

### Live / Offline data mode

There is a **Live | Offline** toggle in the header, next to the valuation date.

| Mode | Source | Availability |
|---|---|---|
| **Live** | Bloomberg Desktop API (BLPAPI) | only when the Terminal is running and logged in on this machine |
| **Offline** | deterministic synthetic data | always |

**Offline is the default for anyone without Bloomberg.** The application starts
either way, every workflow and calculation is identical, and only the price
source differs. The Live button is disabled — with the reason on hover — when
`blpapi` is not installed or nothing is listening on the Desktop API port, and
switching to Live is *refused with an explanation* rather than failing later at
the first price lookup.

`bloomberg.provider` in `config/settings.yaml` sets the **startup preference**:

| Value | Behaviour |
|---|---|
| `auto` (default) | live if a Terminal is reachable, else offline |
| `blpapi` | start live; refuse to start at all if no Terminal is reachable |
| `fake` | always offline, and the Live toggle is **hard-disabled** — use this on a machine that must not talk to Bloomberg |

The operator's last explicit choice is persisted in the `app_state` table and
wins on the next start, provided it is still achievable.

**Switching is safe and lossless for prices.** The pricing and reference caches
are scoped by provider (`pricing_history_cache` is unique on ticker + date +
**provider**), so live and synthetic data coexist and each mode reads only its
own. Nothing is deleted on a switch and flipping back is instant. Manual
duration overrides are the deliberate exception — they are stored under
`provider='manual'` and are honoured in both modes.

**Switching is not automatically safe for a BOOK, and the app says so.** A
trade's execution level is a historical fact recorded at booking time and is
never rewritten. A book whose trades were priced offline, viewed in live mode,
would compare synthetic entry levels against real marks — meaningless. That
condition is detected and shown as a red banner naming the counts, and the
per-trade provider is visible in Trade History. The clean move is a fresh book
per mode (`scripts/reset_for_live.py`).

### Live prices vs cached history

This matters, so it is spelled out. Two different things are being priced, and
they are handled differently on purpose.

**Recent dates are always requested live.** Any observation date within
`bloomberg.live_refresh_window_days` (default 5) of today is inside the **live
window**. Before an execution level or a current mark is resolved for a date in
that window, `refresh_live_window()` issues a fresh `HistoricalDataRequest` to
Bloomberg and **overwrites** the cached rows for those dates. This is what makes
both of the following genuinely live rather than cache-warmed:

* the **execution level** for a trade dated today or in the last few sessions;
* the **"Latest" mark** used for unrealised P&L, today's carry and the KPI band.

Repeated lookups are throttled by `live_refresh_ttl_minutes` (default 15) so a
screen refresh does not hammer the Terminal. **Set it to `0` to make every
lookup hit Bloomberg** — correct for an active trading screen, heavier load.

**Older dates are served from cache**, deliberately. A trade dated three months
ago is settled history; re-requesting years of unchanged data on every screen
refresh would be pointless Terminal load. Prints older than
`price_cache_final_after_days` (default 3) are treated as final.

**Every level records which it was.** `ResolvedLevel.from_live_request` is
persisted on the trade as `price_from_live_request`, alongside
`price_provider`. The trade-entry form shows a `live` / `cached` / `synthetic`
tag beside the level box, and the Trade History grid shows it per row. You never
have to guess whether a number came off the wire.

**Strict mode.** Setting `bloomberg.require_live_execution_prices: true` makes a
trade dated inside the live window **fail** rather than be booked against cached
data when no live Bloomberg request can be made. Recommended for a production
book; leave it `false` while backfilling history, since a backfill legitimately
prices from settled cache.

```yaml
bloomberg:
  live_refresh_window_days: 5        # dates within this of today are re-requested
  live_refresh_ttl_minutes: 15       # 0 = every lookup goes live
  require_live_execution_prices: false
```

**Caching mechanics.** Prices land in `pricing_history_cache`, one row per
ticker per observation date, with `fetched_at` and `provider` stamped on every
row; reference data in `instrument_reference_cache`, keyed by
`(ticker, field, as_of_date)`. Live refreshes update rows **in place** rather
than duplicating them (asserted in the tests). The cache also means the
application stays usable, in read-only terms, when the Terminal is briefly
unavailable — and it says so rather than pretending the numbers are current.

**Entitlement — read this before deploying.** Desktop API entitlement belongs to
the interactive Bloomberg Anywhere user logged into the machine. It is not an
application credential, it cannot be shared, and redistributing the data to
other consumers is a licensing violation. Consequences:

* the service must run on the user's own machine, as that user;
* it dies when their Terminal session dies, so it is **not** suitable for
  unattended or scheduled operation;
* serving a whole team from a central server requires **B-PIPE or Server API
  (SAPI)** — a separate, paid entitlement. The provider interface means that is
  a new implementation of `MarketDataProvider`, not a rewrite.

There are deliberately **no Bloomberg credentials anywhere in this codebase**,
including config files, and no Bloomberg data or field name is ever sent to the
browser except as an already-computed number.

---

## Pricing logic and holiday fallback

### Why the cache stores only actual prints

BLPAPI can perform the holiday fill itself
(`nonTradingDayFillOption=ALL_CALENDAR_DAYS` +
`nonTradingDayFillMethod=PREVIOUS_VALUE`). This application deliberately does
**not** use that for the pricing cache. If the fill happens inside Bloomberg, a
carried-forward value is indistinguishable from a real print by the time it
reaches us — and the audit trail loses the one fact an institutional user will
ask about: *was this an actual print on that date, or the last one before it,
and how stale?*

So the cache is populated with `ACTIVE_DAYS_ONLY` and the carry-forward is
performed here, explicitly, recording the true observation date and the
staleness in calendar days on every trade.

### Resolution rules

**`Mkt Close`**
1. Official close on the trade date, using the configured field priority.
2. If there is no print on that date — holiday, market closure, or a non-US
   market that simply did not trade — use the **most recent prior official
   print**, and record `price_fallback_days` and a human-readable reason.

**`Mkt Open`**
1. `PX_OPEN` on the trade date.
2. If the date has a print but no published open (some contracts do not publish
   one), use the **prior trading day's official close**. This is the most
   defensible proxy for "the level available at the start of the session".
   Tagged as a fallback (rule 2).
3. If the date has no print at all, use the most recent prior official close.
   Tagged as a fallback (rule 3).

**`Custom`** — the user's level is used verbatim, tagged `manual`, and is never
overwritten by a later refresh.

### Timezone perspective

The application reasons in **US dates**. For an instrument whose home market is
Tokyo or Frankfurt, a US trade date may not correspond to a new local official
print. The rule is uniform and documented: *use the most recent official print
at or before the requested US date, and record how many calendar days stale it
was.* No timezone arithmetic is performed on the prices themselves, because
Bloomberg already stamps each print with its local trade date.

Every fallback is written to `audit_log`, surfaced as a `stale` tag on the row,
and summarised in the provenance banner above the grid.

---

## Trade-entry behaviour

1. Select a portfolio (header) and a trade date (calendar widget).
2. Search for an instrument by name, Bloomberg ticker or symbol. The seeded
   instrument master is the primary source; Bloomberg's own security search
   augments it, and those hits are flagged as not in the master.
3. On selection the row's Level 1–4 hierarchy is displayed.
4. Enter a notional weight. **`4` means +4.00%.** `4%`, `+4.0` and `1,000` all
   parse. Negatives are shorts.
5. Choose an execution type. The **level box sits immediately beside it** and:
   * `Mkt Close` / `Mkt Open` — auto-populates from Bloomberg, read-only, with a
     tag showing the field used and the observation date, or an amber `stale Nd`
     tag plus the fallback reason if a prior print was used;
   * `Custom` — becomes editable and required.
6. Save.

On save, in one transaction:

1. the execution level is resolved and its provenance recorded;
2. the dated trade event is written;
3. the **funding sleeve is rebuilt** so the book still nets to 0%;
4. **FIFO lot history is rebuilt**;
5. the **daily P&L series is recomputed**;
6. an audit entry is written.

Trades are **voided, never deleted** — the row stays, flagged, and drops out of
every calculation.

---

## CSV import modes

The import system is a first-class workflow, not a side feature. Upload is
two-phase: **validate and preview**, then **commit**. Nothing touches the book
until you confirm, and the staged rows persist afterwards as permanent lineage.

### Mode 1 — Trade History

Dated trade **events**. Each row is a signed *change* in notional weight. Used
to backfill prior activity, rebuild lot history and populate historical P&L.
Rows are always **appended**; an import never overwrites existing trades.

### Mode 2 — Target Snapshot

A target **book** as of a date. Each row is an *absolute* intended weight. Used
to establish and monitor intended positioning. A snapshot for a date that
already has one **supersedes** it — the earlier snapshot is retained, flagged
`superseded_by_id`, and remains queryable. An instrument may appear only once
per date (enforced; in trade-history mode repeats are entirely normal).

Snapshots carry their own balancing sleeve row, so an intended book displays as
netting to zero exactly like the live one.

### Schema

| Column | Required | Notes |
|---|---|---|
| `portfolio_id` | yes | must match an existing portfolio, e.g. `Navi-S1` |
| `bbg_ticker` | yes | full ticker **including the yellow key**, e.g. `ES1 Index` |
| `notional_weight_pct` | yes | `4` = +4.00%; negatives are shorts |
| `trade_date` | yes | ISO `YYYY-MM-DD`; cannot be in the future |
| `execution_time` | yes | `Mkt Close` \| `Mkt Open` \| `Custom` |
| `level` | **only when `Custom`** | blank for market executions — Bloomberg fills it |
| `notes` | no | free text, carried through to the trade |

Templates and worked samples are downloadable from the Imports tab and written
to `data/templates/` and `data/samples/` on startup.

> **Why the yellow key is part of the key.** The shipped master contains
> `NO1 Index` (Nikkei 225 mini) *and* `NO1 Curncy` (Norwegian krone). Keying on
> the root code alone would silently merge two unrelated instruments. A bare
> root such as `ES1` is accepted only when it is unambiguous; `NO1` is rejected
> with both candidates listed.

Column headers are matched case- and punctuation-insensitively, so
`portfolio_id`, `Portfolio ID` and `portfolio-id` all work.

---

## Funding / leverage offset

A paper book expressed in notional weights must net to 0%. Every market position
is financed: a +100% long book is 100% borrowed; a −20% net short book leaves
+20% of cash on deposit. The application therefore maintains a synthetic sleeve:

```
USD_CASH_OFFSET weight = −(sum of all market instrument weights)
```

Users never enter it. It is recomputed on every change, on every date on which
market weights moved. `test_book_always_nets_to_zero` asserts the invariant.

**It is not a market instrument.** No price, no duration, no beta, no standalone
volatility. It is classified under `Cash & Funding`, outside Equity / Fixed
Income / FX, and is excluded from every hierarchy aggregate and asset-class KPI.
The UI hides it by default. Treating it like a Treasury future or an equity
index would double-count risk.

**Leverage vs the cost of leverage.** The sleeve weight is a *leverage*
measure: a −9% sleeve means 9% of NAV is financed. It is **not** a cost, and the
KPI band does not present it as one. The tile reports **Cost of leverage** —
the annualised run rate, `sleeve weight × all-in funding rate` — with the
financed notional and the funding source underneath, e.g.
*“−0.37% p.a. on 9.00% financed · 1M SOFR 3.85% +25bp = 4.10% p.a., ACT/360”*.
Accrued MTD / YTD / since-inception figures are on the tile's tooltip and in
full on the Analytics tab. The accrued number ties exactly to the funding
component of P&L and to the *Cash & Funding* series in the attribution chart —
asserted in the tests. A net-short book leaves cash on deposit, so the same tile
shows income rather than cost.

**Accrual.** Simple interest on the daily sleeve weight, day-counted per
`funding.day_count` (ACT/360 by default, matching SOFR convention), accruing
every **calendar** day — financing does not stop at the weekend:

```
daily_pnl_pct = sleeve_weight_pct × rate_pct / 100 × days / basis
```

* positive sleeve (cash on deposit) earns `benchmark + positive_spread`
* negative sleeve (borrowing) pays `benchmark + negative_spread`

Defaults: 1M SOFR both ways, +25bp on the borrowing side. Benchmark rates are
**effective-dated** (`funding_benchmarks` table, seeded from
`config/funding_benchmarks.yaml`, editable in Settings). Portfolio-level
overrides for benchmark and spread live on the portfolio record.

---

## P&L methodology

Total return from entry level, computed as a chained **daily contribution
series** in portfolio percent. For instrument *i* on calendar day *d*:

```
carry(i,d) = W_open(i,d) × ( P(i,d) / P(i,d−1) − 1 )
trade(i,d) = Σ over trades on d of  ΔW × ( P(i,d) / L − 1 )
total(i,d) = carry + trade                      (+ funding, for the sleeve)
```

where `W_open` is the weight carried into the day, `P` is the official close (or
the last prior print), and `L` is the trade's execution level.

**Why this shape.** Every execution type falls out correctly with no special
cases:

* `Mkt Close` → `L == P(i,d)`, so the trade-day contribution is exactly **zero**.
  A trade done on the close contributes nothing that day. Correct, and asserted
  in the tests.
* `Mkt Open` → the position earns open-to-close on day one.
* `Custom` → the position earns custom-level-to-close on day one, which is
  precisely what a manually marked fill should do.

Adds, trims, exits and reversals need no branching, because a trade is only ever
a delta applied against that day's close.

Chaining daily contributions rather than differencing a mark-to-market makes
period P&L **additive** across instruments and across time — which is what makes
MTD/QTD/YTD reconcile with the sum of their daily parts.

Periods reported: **Today, MTD, QTD, YTD, since inception, and custom**.
Attribution splits any window into **carry / trade-day / funding**.

### The attribution chart

The P&L tab plots cumulative P&L for a selectable period (**MTD / QTD / YTD /
ITD**), rebased to zero at the start of that period, with contributors stacked
underneath it: by **asset class**, **Level 2 bucket**, or **instrument**.

The stack sums *exactly* to the overlaid total line at every point, because both
are running sums of the same daily rows, merely partitioned — asserted in
`tests/test_engine.py`. That is why it is a single y-axis: a second scale here
would be the classic dual-axis lie. Positive contributions stack upward from
zero and negative downward, so the line lands on the net.

Directly beneath the chart sits a **positioning bar chart** for the same period
and the same grouping. One horizontal bar per position: longs extend right of
zero, shorts left, each bar coloured by the same series — and the same series
index — as the band above it, so asset-class grouping paints by asset class and
instrument grouping gives each name its own hue. The bar is the target
**leaving** the period; a tick marks the target **entering** it, so an add, a
trim or an exit inside the period reads in a single mark. Positions closed
inside the period are faded and sit at zero with their entering tick still
visible. A **Table** toggle shows the same data as start / end / changes /
contribution rows. The chart and the table are built from **one shared grouping function**
on the server, so they cannot disagree on keys, order or therefore colour; the
tests assert the orders match for every grouping.

Buckets adapt to the window (daily under ~75 days, then weekly, then monthly) so
a year does not become 250 unreadable columns; the totals are unaffected. Grouped
by instrument, only the largest contributors get their own colour and the rest
fold into **Other** — a categorical palette is assigned in fixed order and never
cycled, so a ninth series never gets an invented hue.

The series palette is validated, not eyeballed: both the light and dark steps
pass the lightness band, chroma floor, colourblind separation (worst adjacent
ΔE 9.1 light / 8.4 dark) and normal-vision floor against these exact surfaces.
Two light-mode hues fall below 3:1 contrast, so the legend carries a written
label **and** each series' value — identity is never colour alone.

### Realised vs unrealised, and the reconciliation residual

The FIFO lot engine independently produces the from-entry decomposition:

```
realised   = Σ over closed lot slices of  w × (close_level/open_level − 1)
unrealised = Σ over open lots of          w × (mark/open_level − 1)
```

These two measures answer **different questions** and are not expected to be
identical:

* the daily series is a **target-weight** measure — it assumes the stated weight
  is maintained each day;
* realised + unrealised is a **from-entry, fixed-notional** measure.

A sum of daily simple returns does not equal the simple return over the whole
period whenever the price compounds, so the gap is the compounding /
implied-rebalancing effect. It is second-order for normal holding periods and
grows with holding period and volatility. Both numbers are displayed side by
side with the residual labelled, on the P&L tab and in the analytics drawer.

What *would* be an error is an **unpriced instrument**; those are reported
separately and surfaced in the UI rather than absorbed into the residual.

*(If your house convention is fixed-notional-from-entry rather than
target-weight, that is a change to `compute_daily_pnl` alone: scale the daily
price change by the lot's entry level instead of the prior close, which makes
the series telescope exactly onto the lot measure. See HANDOFF.md.)*

### Positioning window vs performance window

Deliberately separate throughout. `period_summary()` takes a *performance*
window and answers "what did the book earn?". `exposure.py` and `volatility.py`
take a *positioning* window and answer "what was the book holding, and how risky
was it?". A user looking at August targets still sees QTD and YTD P&L. Nothing
conflates the two.

---

## Duration methodology

```
duration contribution (years) = notional weight (as a fraction) × modified duration
```

A +10% position in `TY1 Comdty` at 6.5y contributes 0.65 years. Contributions
are additive — the fixed-income duration target is the sum of its parts.

**Sourcing hierarchy**, in order, with every row tagged in the UI:

| Tag | Source |
|---|---|
| `override` | human override — always wins, always logged with who and when |
| `direct` | a Bloomberg reference field (`FUT_EQV_DUR_NOTL` first: for a bond future it is the futures-equivalent duration of the notional, which is what a weight-based book wants) |
| `proxy` | the static table in `config/duration_proxies.yaml`, matched by exact ticker → Level 3 → Level 2 |
| `n/a` | not meaningful — see below |
| `unavailable` | nothing found; excluded from the target and reported |

**Deliberate exclusions.** The CME Treasury *yield* futures (`YQT1`, `YQI1`,
`YQB1`, `YQE1` — Level 3 `US Treasury Yield`) quote a **rate, not a price**, so a
notional-weight duration is not meaningful for them. They are excluded from the
duration target and flagged, rather than being silently assigned zero. Short-rate
futures use the accrual period of the underlying deposit/OIS leg (0.25y).
Equity and FX return `n/a` with no flag — that is not a data gap.

The proxy table is deliberately conservative round numbers and is marked
**review annually**: contract duration drifts as the cheapest-to-deliver and the
underlying baskets roll.

---

## Standalone volatility methodology

```
instrument_vol = stdev( daily log returns ) × √252     [annualised]
standalone_vol = |notional weight| × instrument_vol
```

`standalone_vol` is what the position would contribute to portfolio volatility
if it were the only position — hence "standalone". Computed over the selected
**positioning window**, so "the positions active during August, measured over
August", while the P&L panels continue to show QTD and YTD.

**The total is a sum of standalone contributions and is labelled
`undiversified`.** It is an upper bound on portfolio volatility, attained only at
perfect correlation — not an estimate of it. A true portfolio vol needs a
covariance matrix, which is a much heavier piece of machinery; the
sum-of-standalone number is the honest, cheap answer and is what desks use for a
quick sizing sanity check.

**Data hygiene.** Returns come from **actual prints only**. Filling non-trading
days with the previous close would inject zero-return days and bias realised vol
downwards — badly so for instruments on a non-US holiday calendar. If the
positioning window is too short for a usable sample the window is extended
backwards to reach `min_observations` and **the extension is reported on the
row**, rather than returning a number computed from nine data points as though it
were reliable.

Lookback, annualisation factor, minimum observations and daily-vs-annualised
mode are all configurable; the lookback is also a control in the Analytics tab.

---

## Exposure aggregation

Available at portfolio level and rolled up by **Level 1, 2, 3 and 4**, nested and
expandable:

* gross, net, long, short notional
* subtotals by hierarchy bucket

**Target history.** The grid's weight column is labelled **Current target %**
and carries a small expander. Expanded, each position gains dated sub-rows
showing what its target actually *was* across the selected positioning window —
the weight carried into the window, then each dated change, with the execution
level, its provenance tags and the P&L that position earned **while that target
was in force**. Legs tile the window exactly, so leg P&L sums to the
instrument's window contribution (asserted).

Expanding also **widens the row set** to everything that was on at any point in
the window, including positions since closed — a position opened in July and
closed in August belongs to the quarter's positioning even though it is flat
today, and it is tagged `closed`. Change the window (Active month / Quarter /
Year / Custom) and the history follows it.

**Presentation order.** Level 1 always reads **Equity → Fixed Income → FX →
Cash & Funding** — the order a macro book is discussed in — and it does not
reshuffle because one bucket happened to grow. Deeper levels sort by gross
exposure, where biggest-first is the useful ordering. The same order is used by
the positions grid, the analytics rollup, the drawer and the attribution chart
(`ASSET_CLASS_ORDER` in `app/services/exposure.py` is the single source).

**Totals lead.** The grand total is the first row of the grid, pinned under the
sticky header rather than buried at the bottom of a long book, and group
aggregates sit on the group's header row at the top of the group. A trailing
subtotal is available as an opt-in toggle for anyone who wants the repeat.
* duration contribution per bucket
* summed standalone volatility per bucket
* current target exposure vs a selected snapshot's exposure, with the difference

Asset-class KPIs (total / equity / fixed income / FX) sit in the header band
alongside the duration target and the P&L periods. Toggles: Gross/Net,
Compact/Detailed, Basic/Advanced, Flat/L1/L2/L3/L4 grouping, show-or-hide the
funding sleeve, include exited positions, show-or-hide duration and volatility
columns, positioning window, custom P&L window, and a free-text filter.

---

## Auditability

An institutional user must be able to see where a number came from.

* **Execution levels** are tagged `bloomberg`, `bloomberg_fallback`, `manual`,
  `imported` or `synthetic`, and carry the field used, the true observation date
  and the staleness in days.
* **Price fallbacks** are logged with a human-readable reason and shown as an
  amber `stale Nd` tag.
* **Duration** is tagged `direct`, `proxy`, `override`, `n/a` or `unavailable`,
  with the note explaining which and why.
* **Volatility** carries its observation count and a note when the sample was
  extended or is thin.
* **Imports** store the file's SHA-256, an archived copy on disk, every row
  exactly as parsed, the resolved values, and whether the behaviour was
  *append* or *supersede*.
* **Every row is clickable** — the detail modal shows full lot history, entry
  levels, realised and unrealised, and all provenance tags.
* `audit_log` is append-only and covers pricing fallbacks, duration overrides,
  trade creation and voiding, import staging and commits, funding-curve edits,
  instrument-master reloads and portfolio lifecycle events.
* A **provenance banner** above the grid summarises anything a reviewer should
  be told rather than have to discover.

---

## Data model

| Table | Purpose |
|---|---|
| `portfolios` | book identity, owner, funding overrides, archive state |
| `instruments_master` | the taxonomy, keyed on full ticker + yellow key |
| `instrument_master_versions` | one row per ingestion; never deleted |
| `trades` | dated signed weight deltas + full level provenance, including whether the price was live |
| `trade_lots` | FIFO lot history (derived, persisted, recomputable) |
| `portfolio_snapshots` / `portfolio_snapshot_rows` | dated target books |
| `imported_files` / `import_rows` | complete import lineage |
| `pricing_history_cache` | actual prints only, one row per ticker per date |
| `instrument_reference_cache` | reference data + duration overrides |
| `funding_benchmarks` | effective-dated benchmark curve |
| `calculated_positions` | materialised position state (cache) |
| `pnl_snapshots` | the daily contribution series — the authoritative P&L |
| `analytics_snapshots` | cached aggregates |
| `audit_log` | append-only |

Guarantees: imports never destroy history; trade events and target snapshots
coexist as distinct concepts; lot history is preserved; manual overrides are
tracked permanently; Bloomberg-derived values are cached with provenance; every
calculation is recomputable from `trades` alone.

---

## Security posture

* **No secrets anywhere.** Desktop API entitlement is the logged-in Terminal
  session, not an application credential. There is nothing in config to leak.
* **No browser-side Bloomberg.** BLPAPI is imported only in
  `app/bloomberg/blpapi_provider.py`, which is server-side. The browser receives
  computed numbers, never field names, sessions or raw responses.
* **Minimal dependency surface.** Eight runtime Python packages, all widely
  audited. **Zero** npm dependencies — no bundler, no CDN, no build step.
* **No public cloud requirement.** Binds to loopback by default. No outbound
  internet access at runtime.
* **File-based storage** on a drive the firm already controls and backs up.
* **Clear separation of concerns**, so a reviewer can read one layer at a time.
* **Everything auditable** — imports, calculations, overrides and fallbacks.

---

## Adding authentication later

There is deliberately no authentication in this scaffold: it is designed to run
on an internal network behind whatever SSO or reverse proxy the firm already
operates.

Every write path already threads an `actor` string through to the audit log.
Wiring a real identity is a **one-function change**: replace `_actor()` in
`app/routers/api.py` with something that reads the authenticated principal (from
a reverse-proxy header, an OIDC session, or Windows integrated auth). Add a
FastAPI dependency for entitlement checks at the same point if per-book
permissions are needed; `portfolios.owner` already exists to key them on.

---

## Testing

```bash
python -m pytest tests/ -q
```

112 tests, all passing, **no Bloomberg Terminal required** — they run against the
deterministic synthetic provider. They cover:

* the Live/Offline toggle: offline always available, live refused with a
  readable reason when no Terminal is present, mode choice persists, and the
  price cache is provably scoped by provider so the two never mix
* live pricing: recent dates force a Bloomberg request, older dates are served
  from settled cache, refreshes update rows in place rather than duplicating,
  the live flag is persisted on the trade, and strict mode refuses a same-day
  trade when no live session is available
* instrument master ingestion, the `NO1 Index` / `NO1 Curncy` collision,
  ambiguous-root rejection, tickers with internal spaces, column aliasing,
  non-destructive reload
* the lot engine: adds, trims, full exits, reversals, shorts that rally,
  partial closes spanning multiple lots
* pricing: weekend fallback, foreign-holiday fallback, `Mkt Open` vs
  `Mkt Close`, custom levels
* the funding invariant (`book nets to zero on every date`), financing cost sign,
  weekend accrual, exclusion from market aggregates
* P&L: a close trade earns nothing on its trade date, an open trade earns
  open-to-close, period totals equal the sum of their daily parts,
  realised + unrealised reconciles within the compounding tolerance
* import validation: every rule in the schema table above, both mode semantics,
  supersede-not-delete, double-commit refusal, and that the **shipped sample
  file validates against the shipped rules**
* duration: direct vs proxy vs override vs n/a, yield-quoted exclusion,
  short-rate accrual period, contribution arithmetic
* volatility: plausible magnitudes, bonds below equities, short-window extension
  and flagging, weight scaling, sleeve exclusion

---

## Known limitations and next steps

Honest list, in rough priority order.

1. **No schema migrations.** `create_all` only. Add Alembic before the first
   schema change lands on a shared database.
2. **No authentication.** See above — the hook is in place.
3. **Portfolio-level volatility is undiversified.** A covariance matrix, and
   therefore true portfolio vol, marginal contribution to risk and beta, is the
   obvious next analytics step.
4. **Duration proxies need annual review** and are a static table; a
   cheapest-to-deliver-aware calculation would be better.
5. **FX exposure is expressed through futures weights**, not decomposed into
   currency exposure of the underlying positions. A macro book usually wants
   both views.
6. **No P&L in currency terms** — everything is in percent of NAV. Adding a NAV
   series would let the same engine produce dollar P&L.
7. **`analytics_snapshots` and `calculated_positions` are written but the read
   path recomputes** rather than reading cache. Fine at this data size; wire the
   cache read if books grow large.
8. **Bloomberg security search** is best-effort and returns nothing under the
   synthetic provider — the instrument master is the primary search path.
9. **Single-writer SQLite.** See the shared-drive notes.

---

## Instrument search and the taxonomy boundary

Trade entry searches **only the internal instrument master** — the universe
loaded from `bloomberg_futures_hierarchy.csv` plus anything added since.
Bloomberg's own security search is not reachable from that box. This is
deliberate: everything selectable at trade entry is already classified, so a
trade can never enter a book against an unclassified instrument.

Matching is punctuation-insensitive and token-based, so `sp500` finds
`S&P 500 E-mini`, `10yr treasury` finds `10Y Treasury bond`, and word order
does not matter.

When the master genuinely does not have something, the dropdown offers
**"Add instrument"**. That panel — and only that panel — reaches
`//blp/instruments`. Adding requires **all four hierarchy levels**; placeholders
like `Unclassified` are rejected by both the Pydantic schema and the service
layer. An unclassified instrument is invisible to `build_rollup`, contributes no
duration and gets no attribution colour, so it consumes weight while vanishing
from every aggregate. Refusing it at entry is the only place that is cheap.

The classification is captured once and applies to that instrument **for every
user of the app from then on**. Manually-added instruments are exempt from the
"deactivate anything missing" rule on a master reload, so a revised seed file
never erases them.

The panel proposes a classification derived from the closest instrument already
in *your* master (same yellow key, most overlapping description words) and names
the row it came from. It is a prefill, never a commit. Bloomberg has no field for
"Developed Non-US Equities" or "G10 FX" — those are house views, and inventing a
mapping and attributing it to Bloomberg would be worse than offering nothing.

Bloomberg returns securities in Terminal display notation (`SPX<index>`), which
`//blp/refdata` will not accept. `parse_security_string` normalises at the
provider boundary to `SPX Index`, so no other layer ever sees brackets.

## Amending trades

Trade History supports **Edit** alongside **Void**. An edit keeps the trade's
id, so the audit trail, import batches and snapshot comparisons all still
resolve, and the change is written as a before/after diff rather than as an
unexplained disappearance followed by an unexplained appearance.

Changing the date or the execution type **re-resolves the execution level**
through the same path `save_trade` uses. A price is a claim about a specific
day and is never carried across a date change. The exception is a `Custom`
execution, where there is no official print by definition: the level the user
supplied carries over, with a warning naming the date it was entered for.

A voided trade cannot be edited until it is restored — "should not have been
booked" and "was booked wrongly" are different claims and the log should not
merge them. The funding sleeve is derived and is not hand-editable.

## Positioning chart

Under the cumulative P&L sits a **stacked bar chart of the target weights that
produced it**, on the same period. Longs stack above zero, shorts below, so the
funding sleeve reads as the mirror of the market book it finances and every
column nets to zero.

Both charts call the same `_bucket_size` and `_grouping` functions server-side,
so bucket boundaries, series keys and series order are identical by
construction rather than by coincidence — asserted by
`test_positioning_series_shares_the_attribution_axis` for every grouping.

Each column is the target **in force at the end of that bucket** — a level, not
a sum of trades. `test_positioning_series_reports_a_level_not_a_flow` pins this,
because summing trades would show one tall bar and then nothing.

**Clicking a legend entry hides that series in both charts.** The selection is
shared state keyed by series label. With a series hidden the attribution total
is recomputed from what is visible and relabelled `Total (visible)`, so the
stack and the line never disagree, and the positioning y-axis rescales to the
remaining series.
