"""
Convenience launcher.

    python run.py                 # 127.0.0.1:8000
    python run.py --port 8080
    python run.py --host 0.0.0.0  # only behind an internal reverse proxy

Loopback is the default on purpose: this is an internal tool and the Bloomberg
Desktop API entitlement belongs to the interactive user on this machine.
"""
from __future__ import annotations

import argparse


def main() -> None:
    parser = argparse.ArgumentParser(description="Paper Portfolio & P&L Tracker")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--reload", action="store_true")
    args = parser.parse_args()

    import uvicorn

    uvicorn.run("app.main:app", host=args.host, port=args.port, reload=args.reload)


if __name__ == "__main__":
    main()
