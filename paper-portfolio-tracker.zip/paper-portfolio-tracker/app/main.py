"""
FastAPI application entry point.

Run locally:

    python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload

Deliberate deployment posture:
  * binds to loopback by default - this is an internal tool, not a public service;
  * no outbound internet dependency at runtime;
  * no CDN, no npm, no build step - every asset is served from app/static;
  * BLPAPI is touched only inside the server process.
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app.config import REPO_ROOT, settings
from app.db import init_db, session_scope
from app.routers import api, pages

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-7s %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(_: FastAPI):
    # REPOINT SHARED DRIVE LATER - everything below resolves through
    # settings.paths; log it on boot so an operator can see immediately which
    # database the process actually attached to.
    logger.info("Data root : %s", settings.paths.data_root_path)
    logger.info("Database  : %s", settings.paths.database_file)
    init_db()

    from app.services import funding, imports, instruments

    with session_scope() as db:
        result = instruments.seed_from_disk(db)
        if result:
            logger.info(
                "Seeded instrument master v%s (%s rows)", result.version, result.row_count
            )
        funding.seed_curve(db)
    imports.write_template_files()

    # Resolve the Live / Offline data mode. The operator's last explicit choice
    # (persisted in app_state) wins if it is still achievable; otherwise we fall
    # back to whatever `bloomberg.provider` allows. Offline is always possible,
    # so the application always starts.
    from app.services import datamode

    with session_scope() as db:
        mode = datamode.initialise_from_db(db)

    if mode["is_live"]:
        logger.info("Data mode: LIVE (Bloomberg Desktop API on %s)", mode["endpoint"])
    else:
        logger.warning(
            "Data mode: OFFLINE - synthetic market data. %s",
            mode.get("live_unavailable_reason")
            or "Switch to Live in the header once a Terminal is available.",
        )
        if mode["live_available"]:
            logger.info("A Bloomberg Terminal IS reachable - Live can be enabled in the UI.")

    yield


app = FastAPI(
    title=settings.app.name,
    version="0.1.0",
    description=(
        "TAA-Notepad - internal paper portfolio, target book and P&L tracker "
        "for macro and cross-asset instruments."
    ),
    lifespan=lifespan,
)

app.mount("/static", StaticFiles(directory=str(REPO_ROOT / "app" / "static")), name="static")
app.include_router(api.router)
app.include_router(pages.router)


@app.exception_handler(ValueError)
async def value_error_handler(_: Request, exc: ValueError):
    return JSONResponse(status_code=400, content={"detail": str(exc)})


@app.get("/healthz", include_in_schema=False)
def healthz():
    return {"status": "ok"}
