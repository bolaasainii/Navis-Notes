import {
  get, post, postForm, pct, num, isoDate, signClass, escapeHtml, toast, currentPortfolio,
} from './core.js';

const PORTFOLIO = currentPortfolio();
let mode = 'trade_history';
let staged = null;

const EXPLAIN = {
  trade_history: `<div><strong>Trade history.</strong> Each row is a dated trade <em>event</em> — a signed
    change in notional weight. Use this to backfill prior activity, rebuild lot history and populate
    historical P&amp;L. Rows are always <strong>appended</strong>; an import never overwrites existing trades.
    The funding sleeve is recomputed automatically afterwards.</div>`,
  target_snapshot: `<div><strong>Target snapshot.</strong> Each row is an <em>absolute</em> intended weight
    as of the given date. Use this to load and monitor a target book. A snapshot for a date that already has
    one <strong>supersedes</strong> it — the earlier snapshot is retained, flagged and still queryable.
    An instrument may appear only once per date.</div>`,
};

function setMode(next) {
  mode = next;
  document.querySelectorAll('#seg-import-mode button').forEach((b) =>
    b.setAttribute('aria-pressed', String(b.dataset.mode === next)));
  document.getElementById('mode-explainer').innerHTML = EXPLAIN[next];
  document.getElementById('dl-template').href = `/api/imports/template?mode=${next}`;
  document.getElementById('dl-sample').href = `/api/imports/template?mode=${next}&with_sample=true`;
  document.getElementById('snapshot-label-wrap').classList.toggle('hidden', next !== 'target_snapshot');
}

document.querySelectorAll('#seg-import-mode button').forEach((b) =>
  b.addEventListener('click', () => setMode(b.dataset.mode)));

document.getElementById('import-file').addEventListener('change', (e) => {
  document.getElementById('stage-btn').disabled = !e.target.files.length;
});

document.getElementById('stage-btn').addEventListener('click', async () => {
  const file = document.getElementById('import-file').files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append('file', file);
  fd.append('mode', mode);
  if (PORTFOLIO) fd.append('portfolio_id', PORTFOLIO);

  const btn = document.getElementById('stage-btn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Validating…';
  try {
    staged = await postForm('/api/imports/stage', fd);
    renderPreview();
  } catch (e) {
    toast(e.message, 'error', 8000);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Validate & preview';
  }
});

function renderPreview() {
  const panel = document.getElementById('preview-panel');
  panel.classList.remove('hidden');
  const s = staged;

  document.getElementById('preview-summary').innerHTML =
    `${escapeHtml(s.filename)} · ${s.row_count} row(s) · ` +
    `<span class="pos">${s.valid_count} valid</span> · ` +
    `<span class="${s.warning_count ? '' : 'faint'}">${s.warning_count} warning</span> · ` +
    `<span class="${s.error_count ? 'neg' : 'faint'}">${s.error_count} error</span> · ` +
    `behaviour: <strong>${escapeHtml(s.replace_behaviour)}</strong>`;

  if (s.message) {
    document.getElementById('preview-wrap').innerHTML =
      `<div class="banner banner-error" style="margin:10px">${escapeHtml(s.message)}</div>`;
    document.getElementById('commit-btn').disabled = true;
    return;
  }
  document.getElementById('commit-btn').disabled = s.valid_count + s.warning_count === 0;

  document.getElementById('preview-wrap').innerHTML = `
    <table class="grid"><thead><tr>
      <th style="min-width:48px">Row</th><th>Status</th><th>Portfolio</th>
      <th class="mono">Ticker</th><th class="num">Weight</th><th>Date</th>
      <th>Execution</th><th class="num">Level</th><th>Source</th><th class="num">Stale</th>
      <th style="min-width:340px">Messages</th>
    </tr></thead><tbody>
      ${s.rows.map((r) => {
        const cls = r.status === 'error' ? 'inactive-row' : '';
        const badge = { valid: 'tag-direct', warning: 'tag-fallback', error: 'tag-manual' }[r.status] || 'tag-na';
        return `<tr class="${cls}">
          <td class="num">${r.row_number}</td>
          <td><span class="tag ${badge}">${escapeHtml(r.status)}</span></td>
          <td>${escapeHtml(r.portfolio_id || '')}</td>
          <td class="mono">${escapeHtml(r.bbg_ticker || '')}</td>
          <td class="num ${signClass(r.notional_weight_pct)}">${r.notional_weight_pct === null ? '–' : pct(r.notional_weight_pct)}</td>
          <td>${isoDate(r.trade_date)}</td>
          <td>${escapeHtml(r.execution_time || '')}</td>
          <td class="num">${r.level === null || r.level === undefined ? '–' : num(r.level, 3)}</td>
          <td class="small faint">${escapeHtml(r.level_source || '')}</td>
          <td class="num ${r.fallback_days ? 'neg' : 'zero'}">${r.fallback_days || '–'}</td>
          <td class="small ${r.status === 'error' ? 'neg' : 'faint'}">${escapeHtml((r.messages || []).join(' · '))}</td>
        </tr>`;
      }).join('')}
    </tbody></table>`;
}

document.getElementById('commit-btn').addEventListener('click', async () => {
  if (!staged) return;
  const btn = document.getElementById('commit-btn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Committing…';
  try {
    const result = await post(`/api/imports/${staged.import_id}/commit`, {
      skip_error_rows: document.getElementById('skip-errors').checked,
      snapshot_label: document.getElementById('snapshot-label').value.trim() || null,
      make_current: document.getElementById('make-current').checked,
    });
    toast(`Committed ${result.committed} row(s)`, 'ok');
    if (result.snapshots_superseded && result.snapshots_superseded.length) {
      toast(`Superseded snapshot ${result.snapshots_superseded.join(', ')} (retained, not deleted)`, 'warn', 7000);
    }
    document.getElementById('preview-panel').classList.add('hidden');
    staged = null;
    loadHistory();
  } catch (e) {
    toast(e.message, 'error', 8000);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Commit import';
  }
});

async function loadHistory() {
  const rows = await get(`/api/imports?${PORTFOLIO ? `portfolio_id=${encodeURIComponent(PORTFOLIO)}` : ''}`);
  document.getElementById('imports-wrap').innerHTML = rows.length ? `
    <table class="grid"><thead><tr>
      <th style="min-width:150px">Uploaded</th><th>Mode</th><th>Status</th>
      <th style="min-width:220px">File</th><th class="num">Rows</th><th class="num">Valid</th>
      <th class="num">Warn</th><th class="num">Error</th><th class="num">Committed</th>
      <th>Behaviour</th><th class="mono">SHA-256</th><th>By</th>
    </tr></thead><tbody>
      ${rows.map((r) => `<tr>
        <td class="small">${escapeHtml(String(r.uploaded_at).replace('T', ' ').slice(0, 19))}</td>
        <td><span class="tag">${escapeHtml(r.mode)}</span></td>
        <td><span class="tag ${r.status === 'committed' ? 'tag-direct' : r.status === 'failed_validation' ? 'tag-manual' : 'tag-na'}">${escapeHtml(r.status)}</span></td>
        <td title="${escapeHtml(r.message || '')}">${escapeHtml(r.filename)}</td>
        <td class="num">${r.row_count}</td>
        <td class="num pos">${r.valid_count}</td>
        <td class="num">${r.warning_count}</td>
        <td class="num ${r.error_count ? 'neg' : ''}">${r.error_count}</td>
        <td class="num">${r.committed_count}</td>
        <td class="small">${escapeHtml(r.replace_behaviour)}${r.superseded_snapshot_id ? ` <span class="tag tag-fallback">superseded #${r.superseded_snapshot_id}</span>` : ''}</td>
        <td class="mono small">${escapeHtml(r.sha256.slice(0, 12))}</td>
        <td class="small faint">${escapeHtml(r.uploaded_by || '')}</td>
      </tr>`).join('')}
    </tbody></table>` : '<div class="empty-state">No imports yet.</div>';
}

setMode('trade_history');
loadHistory();
