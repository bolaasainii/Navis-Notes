import {
  get, pct, num, isoDate, signClass, escapeHtml, currentPortfolio,
  contributionChart, positioningChart, seriesColor, ui, onSeriesVisibilityChange,
} from './core.js';

const PORTFOLIO = currentPortfolio();
let data = null;
let attribution = null;
let period = 'mtd';                                   // contribution table
let curvePeriod = ui.get('curvePeriod', 'itd');       // cumulative chart window
let curveGroup = ui.get('curveGroup', 'level_1');     // attribution breakdown
let positions = null;

async function load() {
  if (!PORTFOLIO) return;
  const asOf = document.getElementById('valuation-date').value;
  const start = document.getElementById('pnl-start').value;
  const end = document.getElementById('pnl-end').value;
  const params = new URLSearchParams({ as_of: asOf });
  if (start) params.set('start', start);
  if (end) params.set('end', end);

  data = await get(`/api/portfolios/${encodeURIComponent(PORTFOLIO)}/pnl?${params}`);
  positions = await get(`/api/portfolios/${encodeURIComponent(PORTFOLIO)}/positions?valuation_date=${asOf}&include_inactive=true`);
  render();
}

function render() {
  document.getElementById('pnl-sub').textContent =
    `Inception ${isoDate(data.inception)} · valued ${isoDate(data.as_of)}`;

  const p = data.periods;
  const cards = [
    ['Today', p.today], ['MTD', p.mtd], ['QTD', p.qtd], ['YTD', p.ytd], ['Since inception', p.itd],
  ];
  document.getElementById('pnl-kpis').innerHTML = cards.map(([label, v]) => `
    <div class="kpi">
      <div class="kpi-label">${label}</div>
      <div class="kpi-value ${signClass(v)}">${pct(v, 3)}</div>
    </div>`).join('');

  const a = data.attribution;
  document.getElementById('attribution').innerHTML = `
    <div class="panel-title mb-8">Attribution over the selected window</div>
    <table class="grid" style="max-width:560px"><thead><tr>
      <th>Component</th><th class="num">Contribution</th><th>What it is</th>
    </tr></thead><tbody>
      <tr><td>Carry</td><td class="num ${signClass(a.carry)}">${pct(a.carry, 4)}</td>
        <td class="small faint">Weight held into the day × that day's price return</td></tr>
      <tr><td>Trade day</td><td class="num ${signClass(a.trade)}">${pct(a.trade, 4)}</td>
        <td class="small faint">Execution level to that day's close, on the day a trade was booked</td></tr>
      <tr><td>Funding</td><td class="num ${signClass(a.funding)}">${pct(a.funding, 4)}</td>
        <td class="small faint">Cash sleeve accrual at the configured benchmark ± spread</td></tr>
      <tr class="total-row"><td>Total</td><td class="num ${signClass(a.total)}">${pct(a.total, 4)}</td><td></td></tr>
    </tbody></table>

    <div class="panel-title mt-12 mb-8">Reconciliation</div>
    <table class="grid" style="max-width:560px"><tbody>
      <tr><td>Daily contribution series (target-weight)</td>
        <td class="num ${signClass(data.reconciliation.daily_series_total)}">${pct(data.reconciliation.daily_series_total, 4)}</td></tr>
      <tr><td>Realised (closed lots)</td>
        <td class="num ${signClass(data.reconciliation.realised)}">${pct(data.reconciliation.realised, 4)}</td></tr>
      <tr><td>Unrealised (open lots)</td>
        <td class="num ${signClass(data.reconciliation.unrealised)}">${pct(data.reconciliation.unrealised, 4)}</td></tr>
      <tr><td>From-entry lot total</td>
        <td class="num ${signClass(data.reconciliation.lot_total)}">${pct(data.reconciliation.lot_total, 4)}</td></tr>
      <tr><td class="faint">Compounding residual</td>
        <td class="num faint">${pct(data.reconciliation.compounding_residual, 4)}</td></tr>
    </tbody></table>
    <div class="small faint mt-8" style="max-width:560px">
      The two measures answer different questions and are not expected to be identical.
      The daily series assumes the stated weight is maintained each day; the lot measure marks a
      fixed notional from entry. The gap is the compounding effect.
      ${data.reconciliation.unpriced_tickers.length
        ? `<div class="neg mt-8">Unpriced: ${data.reconciliation.unpriced_tickers.map(escapeHtml).join(', ')}</div>` : ''}
    </div>`;

  renderContributions();
}

function renderContributions() {
  const byTicker = data.per_instrument;
  const meta = new Map((positions ? positions.rows : []).map((r) => [r.ticker, r]));
  const rows = Object.entries(byTicker)
    .map(([ticker, periods]) => ({
      ticker,
      value: periods[period] || 0,
      row: meta.get(ticker),
    }))
    .filter((r) => Math.abs(r.value) > 1e-9)
    .sort((a, b) => b.value - a.value);

  const total = rows.reduce((s, r) => s + r.value, 0);
  document.getElementById('contrib-wrap').innerHTML = rows.length ? `
    <table class="grid"><thead><tr>
      <th style="min-width:200px">Instrument</th><th class="mono">Ticker</th>
      <th>L1</th><th>L2</th><th class="num">Weight</th><th class="num">Contribution</th>
    </tr></thead><tbody>
      ${rows.map((r) => `<tr class="${r.row && r.row.is_funding_offset ? 'offset-row' : ''}">
        <td>${escapeHtml(r.row ? r.row.instrument_name : r.ticker)}</td>
        <td class="mono">${escapeHtml(r.ticker)}</td>
        <td>${escapeHtml(r.row ? r.row.level_1 : '')}</td>
        <td>${escapeHtml(r.row ? r.row.level_2 : '')}</td>
        <td class="num ${signClass(r.row ? r.row.net_weight_pct : 0)}">${r.row ? pct(r.row.net_weight_pct) : '–'}</td>
        <td class="num ${signClass(r.value)}">${pct(r.value, 4)}</td>
      </tr>`).join('')}
      <tr class="total-row"><td>Total</td><td></td><td></td><td></td><td></td>
        <td class="num ${signClass(total)}">${pct(total, 4)}</td></tr>
    </tbody></table>` : '<div class="empty-state">No contributions in this period.</div>';
}

document.querySelectorAll('#seg-pnl-period button').forEach((b) =>
  b.addEventListener('click', () => {
    document.querySelectorAll('#seg-pnl-period button').forEach((x) => x.setAttribute('aria-pressed', 'false'));
    b.setAttribute('aria-pressed', 'true');
    period = b.dataset.period;
    renderContributions();
  }));

/* ==========================================================================
   Cumulative P&L + attribution
   --------------------------------------------------------------------------
   The chart answers two questions at once: how did the period accumulate, and
   who drove it. The stacked contributions sum exactly to the overlaid total
   line - both are running sums of the same daily rows, partitioned - so one
   y-axis is correct and a second would be a lie.
   ========================================================================== */
const GROUP_LABEL = {
  level_1: 'asset class',
  level_2: 'Level 2 bucket',
  level_3: 'Level 3 bucket',
  ticker: 'instrument',
};

async function loadAttribution() {
  const host = document.getElementById('attribution-chart');
  if (!PORTFOLIO || !host) return;
  const asOf = document.getElementById('valuation-date').value;
  const params = new URLSearchParams({
    period: curvePeriod,
    as_of: asOf,
    // 'Off' still needs a partition to compute the total; we simply do not
    // draw the bars, which keeps the request and the maths identical.
    group_by: curveGroup === 'none' ? 'level_1' : curveGroup,
  });
  host.innerHTML = '<div class="empty-state"><span class="spinner"></span> Building attribution…</div>';
  try {
    attribution = await get(`/api/portfolios/${encodeURIComponent(PORTFOLIO)}/pnl/attribution?${params}`);
  } catch (e) {
    host.innerHTML = `<div class="empty-state">${escapeHtml(e.message)}</div>`;
    return;
  }
  drawAttribution();
  loadPositioning();
}

/* --------------------------------------------------------------------------
   Positioning behind the chart
   --------------------------------------------------------------------------
   Same period, same grouping, same colours as the bars above it - the server
   builds both from one grouping function, so a series and its rows can never
   drift apart. Shows the target entering and leaving the period, including
   positions closed inside it.
   -------------------------------------------------------------------------- */
let positioning = null;
let positioningView = ui.get('positioningView', 'chart');

async function loadPositioning() {
  const wrap = document.getElementById('positioning-wrap');
  if (!PORTFOLIO || !wrap) return;
  const params = new URLSearchParams({
    period: curvePeriod,
    as_of: document.getElementById('valuation-date').value,
    group_by: curveGroup === 'none' ? 'level_1' : curveGroup,
  });
  wrap.innerHTML = '<div class="empty-state"><span class="spinner"></span> Loading positioning…</div>';
  try {
    positioning = await get(`/api/portfolios/${encodeURIComponent(PORTFOLIO)}/pnl/positioning?${params}`);
  } catch (e) {
    wrap.innerHTML = `<div class="empty-state">${escapeHtml(e.message)}</div>`;
    return;
  }
  drawPositioning();
}

function drawPositioning() {
  if (!positioning) return;
  const wrap = document.getElementById('positioning-wrap');
  const series = positioning.series || [];

  // --- chart view (default) ---------------------------------------------
  const chartOn = positioningView === 'chart';
  document.getElementById('positioning-chart-body').classList.toggle('hidden', !chartOn);
  document.getElementById('positioning-table-body').classList.toggle('hidden', chartOn);
  if (chartOn) {
    positioningChart(document.getElementById('positioning-chart'), positioning.timeline || {});
    const tl = positioning.timeline || {};
    const rowCount = series.reduce((n, s) => n + (s.rows || []).length, 0);
    document.getElementById('positioning-note').innerHTML = `
      Each column is the target weight in force at the end of that
      ${escapeHtml(tl.bucket || 'period')} bucket — a level, not a sum of trades — stacked with
      longs above zero and shorts below. Same x-axis, same series and same colours as the
      cumulative P&amp;L above, so a column here explains the line up there.
      <strong>Click any legend entry to hide that series in both charts.</strong>
      ${rowCount} position(s) across ${(tl.buckets || []).length} bucket(s).`;
  }

  document.getElementById('positioning-sub').textContent =
    `${curvePeriod.toUpperCase()} · ${isoDate(positioning.start)} → ${isoDate(positioning.end)} · ` +
    `grouped by ${GROUP_LABEL[positioning.group_by] || positioning.group_by}`;

  if (!series.length) {
    wrap.innerHTML = '<div class="empty-state">No positioning in this period.</div>';
    return;
  }

  const body = series.map((s, i) => {
    // Colour by series INDEX, exactly as the chart does - the server returns
    // both in the same order from the same grouping.
    const colour = seriesColor(i, s.key);
    const header = `<tr class="series-row">
      <td><span class="series-swatch" style="background:${colour}"></span>${escapeHtml(s.label)}
          <span class="faint">${s.rows.length}</span></td>
      <td></td>
      <td class="num ${signClass(s.start_target_pct)}">${pct(s.start_target_pct)}</td>
      <td class="num ${signClass(s.end_target_pct)}">${pct(s.end_target_pct)}</td>
      <td class="num"></td>
      <td class="num ${signClass(s.contribution_pct)}">${pct(s.contribution_pct, 3)}</td>
    </tr>`;
    const rows = s.rows.map((r) => `<tr class="${r.closed_in_window ? 'inactive-row' : ''}">
      <td style="padding-left:24px">${escapeHtml(r.name)}${r.closed_in_window
        ? ' <span class="tag tag-fallback" title="On during the period, flat at the end of it">closed</span>' : ''}</td>
      <td class="mono">${escapeHtml(r.ticker)}</td>
      <td class="num ${signClass(r.start_target_pct)}">${pct(r.start_target_pct)}</td>
      <td class="num ${signClass(r.end_target_pct)}">${pct(r.end_target_pct)}</td>
      <td class="num faint">${r.changes || '–'}</td>
      <td class="num ${signClass(r.contribution_pct)}">${pct(r.contribution_pct, 3)}</td>
    </tr>`).join('');
    return header + rows;
  }).join('');

  wrap.innerHTML = `<table class="grid"><thead><tr>
      <th style="min-width:230px">Position</th>
      <th class="mono">Ticker</th>
      <th class="num" title="Target entering the period">Start target</th>
      <th class="num" title="Target leaving the period">End target</th>
      <th class="num" title="Number of target changes inside the period">Changes</th>
      <th class="num">Contribution</th>
    </tr></thead><tbody>
      <tr class="total-row total-top">
        <td>Total</td><td></td><td></td><td></td><td></td>
        <td class="num ${signClass(positioning.total_contribution_pct)}">${pct(positioning.total_contribution_pct, 3)}</td>
      </tr>
      ${body}
    </tbody></table>`;
}

function drawAttribution() {
  if (!attribution) return;
  contributionChart(document.getElementById('attribution-chart'), attribution, {
    height: 300,
    showBars: curveGroup !== 'none',
  });

  const n = (attribution.buckets || []).length;
  document.getElementById('curve-sub').textContent =
    `${curvePeriod.toUpperCase()} · ${isoDate(attribution.start)} → ${isoDate(attribution.end)} · ${n} ${attribution.bucket} bucket(s)`;

  document.getElementById('curve-note').innerHTML = curveGroup === 'none'
    ? 'Cumulative P&amp;L rebased to zero at the start of the selected period.'
    : `Bars are cumulative contribution by ${escapeHtml(GROUP_LABEL[curveGroup] || curveGroup)}, stacked above and below zero;
       the line is the cumulative total. They agree at every point by construction — both are running sums of the same
       daily rows. ${curveGroup === 'ticker'
         ? 'Only the largest contributors are shown separately; the rest are folded into “Other” rather than given their own colour.'
         : 'The funding sleeve appears as its own contributor, since financing is a real part of the return.'}`;
}

function wirePositioningView() {
  const seg = document.getElementById('seg-positioning-view');
  if (!seg) return;
  seg.querySelectorAll('button').forEach((btn) => {
    btn.setAttribute('aria-pressed', String(btn.dataset.view === positioningView));
    btn.addEventListener('click', () => {
      seg.querySelectorAll('button').forEach((b) => b.setAttribute('aria-pressed', 'false'));
      btn.setAttribute('aria-pressed', 'true');
      positioningView = btn.dataset.view;
      ui.set('positioningView', positioningView);
      drawPositioning();
    });
  });
}

function wireCurveControls() {
  [['seg-curve-period', 'period', (v) => { curvePeriod = v; ui.set('curvePeriod', v); }],
   ['seg-curve-group', 'group', (v) => { curveGroup = v; ui.set('curveGroup', v); }]]
    .forEach(([id, attr, apply]) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.querySelectorAll('button').forEach((btn) => {
        btn.addEventListener('click', () => {
          el.querySelectorAll('button').forEach((b) => b.setAttribute('aria-pressed', 'false'));
          btn.setAttribute('aria-pressed', 'true');
          apply(btn.dataset[attr]);
          if (attr === 'period') { loadAttribution(); loadPositioning(); }
          else if (curveGroup === 'none') { drawAttribution(); loadPositioning(); }
          else { loadAttribution(); loadPositioning(); }
        });
      });
      const current = attr === 'period' ? curvePeriod : curveGroup;
      el.querySelectorAll('button').forEach((b) =>
        b.setAttribute('aria-pressed', String(b.dataset[attr] === current)));
    });
}

document.getElementById('pnl-apply').addEventListener('click', () => { load(); loadAttribution(); });
document.addEventListener('ppt:valuation-changed', () => { load(); loadAttribution(); });

/* Legend clicks are shared state: hiding a series must repaint BOTH charts,
   or the page shows two different books at once. */
onSeriesVisibilityChange(() => { drawAttribution(); drawPositioning(); });

let resizeTimer = null;
window.addEventListener('resize', () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => { drawAttribution(); drawPositioning(); }, 150);
});

wireCurveControls();
wirePositioningView();
load();
loadAttribution();
