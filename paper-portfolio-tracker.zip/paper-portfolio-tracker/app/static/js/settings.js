import { get, post, postForm, num, isoDate, escapeHtml, toast } from './core.js';

async function loadFunding() {
  const data = await get('/api/settings/funding');
  document.getElementById('funding-wrap').innerHTML = `
    <table class="grid"><thead><tr>
      <th>Benchmark</th><th>Effective from</th><th class="num">Rate %</th><th>Source</th><th>Note</th>
    </tr></thead><tbody>
      ${data.curve.map((p) => `<tr>
        <td class="mono">${escapeHtml(p.benchmark)}</td>
        <td>${isoDate(p.effective_date)}</td>
        <td class="num">${num(p.rate_pct, 3)}</td>
        <td><span class="tag ${p.source === 'manual' ? 'tag-manual' : 'tag-na'}">${escapeHtml(p.source)}</span></td>
        <td class="small faint">${escapeHtml(p.note || '')}</td>
      </tr>`).join('')}
    </tbody></table>`;

  const c = data.config;
  document.getElementById('funding-config').innerHTML = `
    Sleeve ticker <span class="mono">${escapeHtml(c.offset_ticker)}</span> ·
    day count ${escapeHtml(c.day_count)} ·
    cash earns ${escapeHtml(c.positive_cash_benchmark)} ${c.positive_cash_spread_bps >= 0 ? '+' : ''}${c.positive_cash_spread_bps}bp ·
    borrowing pays ${escapeHtml(c.negative_cash_benchmark)} +${c.negative_cash_spread_bps}bp.
    Per-portfolio overrides are set on the portfolio record.`;
}

document.getElementById('fb-add').addEventListener('click', async () => {
  try {
    await post('/api/settings/funding', {
      benchmark: document.getElementById('fb-benchmark').value.trim(),
      effective_date: document.getElementById('fb-date').value,
      rate_pct: parseFloat(document.getElementById('fb-rate').value),
      note: document.getElementById('fb-note').value.trim() || null,
    });
    toast('Benchmark point saved', 'ok');
    loadFunding();
  } catch (e) { toast(e.message, 'error'); }
});

async function setOverride(clear) {
  try {
    await post('/api/settings/duration-override', {
      bbg_ticker: document.getElementById('do-ticker').value.trim(),
      years: clear ? null : parseFloat(document.getElementById('do-years').value),
      as_of: document.getElementById('do-date').value || null,
      reason: document.getElementById('do-reason').value.trim() || null,
    });
    toast(clear ? 'Override cleared' : 'Override applied', 'ok');
  } catch (e) { toast(e.message, 'error'); }
}
document.getElementById('do-apply').addEventListener('click', () => setOverride(false));
document.getElementById('do-clear').addEventListener('click', () => setOverride(true));

document.getElementById('im-file').addEventListener('change', (e) => {
  document.getElementById('im-upload').disabled = !e.target.files.length;
});

document.getElementById('im-upload').addEventListener('click', async () => {
  const fd = new FormData();
  fd.append('file', document.getElementById('im-file').files[0]);
  const btn = document.getElementById('im-upload');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Loading…';
  try {
    const r = await postForm('/api/instruments/master/reload', fd);
    document.getElementById('im-result').innerHTML = `
      <div class="banner banner-ok"><div>
        <strong>Instrument master v${r.version} loaded.</strong>
        ${r.row_count} row(s) read · ${r.added} added · ${r.updated} updated ·
        ${r.unchanged} unchanged · ${r.deactivated} deactivated.
        ${r.skipped.length ? `<div class="small mt-8">Skipped: ${r.skipped.slice(0, 8).map(escapeHtml).join('; ')}${r.skipped.length > 8 ? ` … and ${r.skipped.length - 8} more` : ''}</div>` : ''}
      </div></div>`;
    toast('Instrument master reloaded', 'ok');
  } catch (e) {
    document.getElementById('im-result').innerHTML =
      `<div class="banner banner-error"><div>${escapeHtml(e.message)}</div></div>`;
  } finally {
    btn.disabled = false;
    btn.textContent = 'Reload master';
  }
});

async function loadAnalytics() {
  const a = await get('/api/settings/analytics');
  document.getElementById('analytics-config').innerHTML = `
    <div class="dl">
      <dt>Vol lookback</dt><dd>${a.volatility.default_lookback_days} trading days</dd>
      <dt>Annualisation</dt><dd>√${a.volatility.annualisation_factor}</dd>
      <dt>Min observations</dt><dd>${a.volatility.min_observations}</dd>
      <dt>Vol mode</dt><dd>${escapeHtml(a.volatility.default_mode)}</dd>
      <dt>Duration fields</dt><dd class="mono">${a.duration.field_priority.map(escapeHtml).join(' → ')}</dd>
      <dt>Proxy fallback</dt><dd>${a.duration.allow_proxy_fallback ? 'enabled' : 'disabled'}</dd>
      <dt>Base currency</dt><dd>${escapeHtml(a.pnl.base_currency)}</dd>
      <dt>Inception</dt><dd>${escapeHtml(a.pnl.inception_mode)}</dd>
    </div>
    <div class="small faint mt-8">
      These are read from <span class="mono">config/settings.yaml</span> at startup.
      Edit that file and restart the service to change them.
    </div>`;
}

document.getElementById('fb-date').value = document.body.dataset.today;
document.getElementById('do-date').value = document.body.dataset.today;
loadFunding();
loadAnalytics();
