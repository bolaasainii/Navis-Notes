/* ==========================================================================
   core.js - shared utilities
   Plain ES modules. No framework, no bundler, no runtime dependencies.
   ========================================================================== */

/* ---------------------------------------------------------------- fetch --- */
export async function api(path, options = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  });
  const text = await res.text();
  let body = null;
  if (text) {
    try { body = JSON.parse(text); } catch { body = text; }
  }
  if (!res.ok) {
    const detail = (body && body.detail) || res.statusText || 'Request failed';
    const err = new Error(typeof detail === 'string' ? detail : JSON.stringify(detail));
    err.status = res.status;
    err.body = body;
    throw err;
  }
  return body;
}

export const get = (p) => api(p);
export const post = (p, body) => api(p, { method: 'POST', body: JSON.stringify(body || {}) });
export const patch = (p, body) => api(p, { method: 'PATCH', body: JSON.stringify(body || {}) });

export async function postForm(path, formData) {
  const res = await fetch(path, { method: 'POST', body: formData });
  const body = await res.json().catch(() => null);
  if (!res.ok) {
    const err = new Error((body && body.detail) || 'Upload failed');
    err.body = body;
    throw err;
  }
  return body;
}

/* --------------------------------------------------------------- format --- */
export function pct(value, digits = 2, withSign = true) {
  if (value === null || value === undefined || Number.isNaN(value)) return '–';
  const n = Number(value);
  const s = n.toFixed(digits);
  return (withSign && n > 0 ? '+' : '') + s + '%';
}

export function num(value, digits = 2) {
  if (value === null || value === undefined || Number.isNaN(value)) return '–';
  return Number(value).toLocaleString(undefined, {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

export function yrs(value, digits = 3) {
  if (value === null || value === undefined || Number.isNaN(value)) return '–';
  const n = Number(value);
  return (n > 0 ? '+' : '') + n.toFixed(digits);
}

export function isoDate(value) {
  if (!value) return '–';
  return String(value).slice(0, 10);
}

/** Return a CSS class for a signed number. */
export function signClass(value) {
  if (value === null || value === undefined || Number.isNaN(value)) return 'zero';
  const n = Number(value);
  if (Math.abs(n) < 1e-9) return 'zero';
  return n > 0 ? 'pos' : 'neg';
}

/** Signed cell: <td class="num pos">+4.00%</td> */
export function signedCell(value, formatter = pct, extraClass = '') {
  const cls = `num ${signClass(value)} ${extraClass}`.trim();
  return `<td class="${cls}">${formatter(value)}</td>`;
}

export function escapeHtml(s) {
  if (s === null || s === undefined) return '';
  return String(s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/* ---------------------------------------------------------------- toast --- */
let toastStack = null;
export function toast(message, kind = 'ok', ms = 4200) {
  if (!toastStack) {
    toastStack = document.createElement('div');
    toastStack.className = 'toast-stack';
    document.body.appendChild(toastStack);
  }
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.innerHTML = escapeHtml(message);
  toastStack.appendChild(el);
  setTimeout(() => el.remove(), ms);
  return el;
}

/* ---------------------------------------------------------------- state --- */
const STORE_KEY = 'ppt.ui.v1';

export const ui = {
  read() {
    try { return JSON.parse(localStorage.getItem(STORE_KEY)) || {}; }
    catch { return {}; }
  },
  get(key, fallback) {
    const v = this.read()[key];
    return v === undefined ? fallback : v;
  },
  set(key, value) {
    const s = this.read();
    s[key] = value;
    try { localStorage.setItem(STORE_KEY, JSON.stringify(s)); } catch { /* private mode */ }
  },
};

/* ---------------------------------------------------------------- theme --- */
export function initTheme(defaultTheme, defaultDensity) {
  const theme = ui.get('theme', defaultTheme || 'dark');
  const density = ui.get('density', defaultDensity || 'compact');
  document.body.setAttribute('data-theme', theme);
  document.body.setAttribute('data-density', density);
  document.documentElement.setAttribute('data-theme', theme);

  const btn = document.getElementById('theme-toggle');
  if (btn) {
    const label = () => { btn.textContent = document.body.getAttribute('data-theme') === 'dark' ? 'Light' : 'Dark'; };
    label();
    btn.addEventListener('click', () => {
      const next = document.body.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      document.body.setAttribute('data-theme', next);
      document.documentElement.setAttribute('data-theme', next);
      ui.set('theme', next);
      label();
    });
  }
}

/* ------------------------------------------------------- portfolio nav --- */
export function currentPortfolio() {
  const params = new URLSearchParams(location.search);
  const sel = document.getElementById('portfolio-select');
  return params.get('portfolio') || (sel && sel.value) || null;
}

export function initPortfolioSelect() {
  const sel = document.getElementById('portfolio-select');
  if (!sel) return;
  const params = new URLSearchParams(location.search);
  const current = params.get('portfolio');
  if (current) sel.value = current;
  sel.addEventListener('change', () => {
    const p = new URLSearchParams(location.search);
    p.set('portfolio', sel.value);
    location.search = p.toString();
  });
}

/* ---------------------------------------------------------- date fields --- */
/**
 * Make every date input open a calendar on click, not just on the small
 * indicator glyph. `showPicker()` is native, so there is no datepicker library
 * to audit and the control stays keyboard- and locale-correct.
 *
 * Safe to call repeatedly; inputs are wired once. Call it again after
 * injecting markup that contains date fields.
 */
export function initDatePickers(root = document) {
  root.querySelectorAll('input[type="date"]').forEach((el) => {
    if (el.dataset.pickerWired) return;
    el.dataset.pickerWired = '1';
    const open = () => {
      // showPicker() throws without user activation, and is absent on older
      // browsers - in both cases the native indicator still works.
      try { if (typeof el.showPicker === 'function') el.showPicker(); } catch { /* no-op */ }
    };
    el.addEventListener('click', open);
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); }
    });
  });
}

/* --------------------------------------------------------------- modals --- */
export function openModal(id) {
  const el = document.getElementById(id);
  if (el) {
    el.hidden = false;
    document.body.style.overflow = 'hidden';
    initDatePickers(el);
  }
}
export function closeModal(id) {
  const el = document.getElementById(id);
  if (el) { el.hidden = true; document.body.style.overflow = ''; }
}
export function wireModal(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.addEventListener('click', (e) => { if (e.target === el) closeModal(id); });
  el.querySelectorAll('[data-close-modal]').forEach((b) =>
    b.addEventListener('click', () => closeModal(id))
  );
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !el.hidden) closeModal(id);
  });
}

/* -------------------------------------------------------------- sorting --- */
export function makeSortable(table, rows, render, initial = null) {
  let state = initial ? { ...initial } : { key: null, dir: 1 };

  function apply() {
    let sorted = rows.slice();
    if (state.key) {
      sorted.sort((a, b) => {
        const av = a[state.key], bv = b[state.key];
        if (av === bv) return 0;
        if (av === null || av === undefined) return 1;
        if (bv === null || bv === undefined) return -1;
        if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * state.dir;
        return String(av).localeCompare(String(bv)) * state.dir;
      });
    }
    render(sorted);
    table.querySelectorAll('thead th.sortable').forEach((th) => {
      const mark = th.querySelector('.sort-mark');
      if (mark) mark.remove();
      if (th.dataset.sortKey === state.key) {
        const s = document.createElement('span');
        s.className = 'sort-mark';
        s.textContent = state.dir > 0 ? '▲' : '▼';
        th.appendChild(s);
      }
    });
  }

  table.querySelectorAll('thead th.sortable').forEach((th) => {
    th.addEventListener('click', () => {
      const key = th.dataset.sortKey;
      if (state.key === key) state.dir = -state.dir;
      else { state.key = key; state.dir = key === 'instrument_name' || key === 'ticker' ? 1 : -1; }
      apply();
    });
  });

  apply();
  return { setRows(next) { rows = next; apply(); } };
}

/* --------------------------------------------------------------- charts --- */
/**
 * Minimal inline SVG line chart. Deliberately dependency-free: a single
 * cumulative series with a zero line is all this application needs, and a
 * charting library would be another item in a security review for no gain.
 */
export function lineChart(el, points, { height = 170, valueKey = 'y', dateKey = 'x' } = {}) {
  if (!el) return;
  el.innerHTML = '';
  if (!points || points.length < 2) {
    el.innerHTML = '<div class="empty-state">Not enough data to plot</div>';
    return;
  }
  const width = Math.max(el.clientWidth || 640, 320);
  const padL = 46, padR = 10, padT = 10, padB = 20;
  const ys = points.map((p) => Number(p[valueKey]));
  let min = Math.min(...ys, 0), max = Math.max(...ys, 0);
  if (min === max) { min -= 1; max += 1; }
  const pad = (max - min) * 0.08;
  min -= pad; max += pad;

  const sx = (i) => padL + (i / (points.length - 1)) * (width - padL - padR);
  const sy = (v) => padT + (1 - (v - min) / (max - min)) * (height - padT - padB);

  const path = points.map((p, i) => `${i ? 'L' : 'M'}${sx(i).toFixed(1)},${sy(Number(p[valueKey])).toFixed(1)}`).join(' ');
  const area = `${path} L${sx(points.length - 1).toFixed(1)},${sy(0).toFixed(1)} L${sx(0).toFixed(1)},${sy(0).toFixed(1)} Z`;

  const ticks = 4;
  let gridlines = '';
  for (let i = 0; i <= ticks; i++) {
    const v = min + (i / ticks) * (max - min);
    const y = sy(v).toFixed(1);
    gridlines += `<line class="gridline" x1="${padL}" x2="${width - padR}" y1="${y}" y2="${y}"/>`;
    gridlines += `<text x="${padL - 6}" y="${Number(y) + 3}" text-anchor="end">${v.toFixed(2)}%</text>`;
  }

  const first = isoDate(points[0][dateKey]);
  const last = isoDate(points[points.length - 1][dateKey]);

  el.innerHTML = `
    <svg class="chart" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" height="${height}">
      ${gridlines}
      <line class="zero-line" x1="${padL}" x2="${width - padR}" y1="${sy(0).toFixed(1)}" y2="${sy(0).toFixed(1)}"/>
      <path class="area" d="${area}"/>
      <path class="curve" d="${path}"/>
      <text x="${padL}" y="${height - 5}">${first}</text>
      <text x="${width - padR}" y="${height - 5}" text-anchor="end">${last}</text>
    </svg>`;
}

/** Horizontal +/- bar for exposure rollups. */
export function exposureBar(value, scale) {
  const magnitude = Math.min(Math.abs(value) / (scale || 1), 1) * 50;
  const cls = value >= 0 ? 'pos' : 'neg';
  const style = value >= 0
    ? `left:50%;width:${magnitude}%`
    : `right:50%;width:${magnitude}%`;
  return `<div class="bar-track"><div class="bar-mid" style="left:50%"></div><div class="bar-fill ${cls}" style="${style}"></div></div>`;
}

/* ==========================================================================
   Attribution chart
   --------------------------------------------------------------------------
   Stacked cumulative contributions with the cumulative total overlaid as a
   line. One y-axis, deliberately: the stack and the line are the same
   quantity, and the stack sums exactly to the line at every bucket because
   both are running sums of the same daily rows. (A second axis here would be
   the classic dual-axis lie.)

   Positive contributions stack upward from zero, negative downward, so the
   line lands on the net. Colours come from the validated categorical palette
   in app.css, assigned in fixed order and never cycled - a ninth series is
   folded into "Other" server-side.
   ========================================================================== */
const SERIES_VARS = [
  '--series-1', '--series-2', '--series-3', '--series-4',
  '--series-5', '--series-6', '--series-7', '--series-8',
];

export function seriesColor(index, key) {
  const css = getComputedStyle(document.body);
  if (key === 'Other') return css.getPropertyValue('--series-other').trim() || '#888';
  return css.getPropertyValue(SERIES_VARS[index % SERIES_VARS.length]).trim() || '#888';
}

/* --------------------------------------------------------------------------
   Hidden series
   --------------------------------------------------------------------------
   Clicking a legend entry hides that series. The set is shared between the
   attribution chart and the positioning chart below it, because they are two
   views of the same decomposition - hiding "Cash & Funding" in one and not the
   other would put two different books on the screen at once.

   Keyed by series LABEL rather than index: the index of a given asset class
   changes when the grouping changes, the label does not.
   -------------------------------------------------------------------------- */
const hiddenSeries = new Set();
const seriesListeners = new Set();

export function isSeriesHidden(label) { return hiddenSeries.has(label); }

export function onSeriesVisibilityChange(fn) {
  seriesListeners.add(fn);
  return () => seriesListeners.delete(fn);
}

export function toggleSeries(label) {
  if (hiddenSeries.has(label)) hiddenSeries.delete(label);
  else hiddenSeries.add(label);
  seriesListeners.forEach((fn) => { try { fn(label); } catch { /* a bad listener must not break the chart */ } });
}

export function resetHiddenSeries() {
  if (!hiddenSeries.size) return;
  hiddenSeries.clear();
  seriesListeners.forEach((fn) => { try { fn(null); } catch { /* ignore */ } });
}

/* Legend markup shared by both charts. `values` are already formatted. */
function legendHtml(entries, { totalEntry = null } = {}) {
  const items = entries.map((e) => `
        <button type="button" class="lg-item lg-toggle${e.hidden ? ' is-hidden' : ''}"
                data-series="${escapeHtml(e.label)}"
                aria-pressed="${e.hidden ? 'false' : 'true'}"
                title="${e.hidden ? 'Show' : 'Hide'} ${escapeHtml(e.label)}">
          <span class="lg-swatch" style="background:${e.hidden ? 'transparent' : e.color};box-shadow:inset 0 0 0 1.5px ${e.color}"></span>
          <span class="lg-label">${escapeHtml(e.label)}</span>
          <span class="lg-value ${e.sign}">${e.value}</span>
        </button>`).join('');
  const total = totalEntry ? `
        <span class="lg-item lg-total">
          <span class="lg-swatch"></span>
          <span class="lg-label">${escapeHtml(totalEntry.label)}</span>
          <span class="lg-value ${totalEntry.sign}">${totalEntry.value}</span>
        </span>` : '';
  return items + total;
}

function wireLegend(host, redraw) {
  host.querySelectorAll('.lg-toggle').forEach((btn) => {
    btn.addEventListener('click', () => toggleSeries(btn.dataset.series));
  });
}

export function contributionChart(host, data, { height = 280, showBars = true } = {}) {
  if (!host) return;
  host.innerHTML = '';
  host.classList.add('chart-host');

  const buckets = data.buckets || [];
  const allSeries = data.series || [];
  if (buckets.length < 1 || !allSeries.length) {
    host.innerHTML = '<div class="empty-state">No P&amp;L in this period yet.</div>';
    return;
  }

  // Colour is bound to the series' position in the FULL list, so hiding one
  // never recolours the others - the palette is an identity, not a sequence.
  const palette = new Map(allSeries.map((s, i) => [s.label, seriesColor(i, s.key)]));
  const series = allSeries.filter((s) => !isSeriesHidden(s.label));
  const colors = series.map((s) => palette.get(s.label));
  const anyHidden = series.length !== allSeries.length;

  // With a series hidden, the stack no longer sums to the reported total. Show
  // the total of what is VISIBLE so the bars and the line still agree, and say
  // so in the label rather than quietly showing a line the bars cannot explain.
  const total = anyHidden
    ? buckets.map((_, i) => series.reduce((acc, sr) => acc + (sr.cumulative[i] || 0), 0))
    : (data.total || []);

  if (!series.length) {
    host.innerHTML = `<div class="empty-state">Every series is hidden.
      <button type="button" class="btn btn-sm" id="unhide-all">Show all</button></div>`;
    const btn = host.querySelector('#unhide-all');
    if (btn) btn.addEventListener('click', () => resetHiddenSeries());
    return;
  }
  const width = Math.max(host.clientWidth || 760, 380);
  const padL = 54, padR = 14, padT = 12, padB = 30;
  const plotW = width - padL - padR;
  const plotH = height - padT - padB;

  // --- scale: stack extents and the total line share one axis -------------
  let lo = 0, hi = 0;
  buckets.forEach((_, i) => {
    let up = 0, down = 0;
    series.forEach((s) => {
      const v = s.cumulative[i] || 0;
      if (v >= 0) up += v; else down += v;
    });
    hi = Math.max(hi, up, total[i] || 0);
    lo = Math.min(lo, down, total[i] || 0);
  });
  if (hi === lo) { hi += 0.5; lo -= 0.5; }
  const pad = (hi - lo) * 0.10;
  hi += pad; lo -= pad;

  const band = plotW / buckets.length;
  const barW = Math.min(band * 0.68, 26);
  const cx = (i) => padL + band * (i + 0.5);
  const sy = (v) => padT + (1 - (v - lo) / (hi - lo)) * plotH;
  const zeroY = sy(0);

  // --- gridlines ----------------------------------------------------------
  let grid = '';
  const ticks = 4;
  for (let t = 0; t <= ticks; t++) {
    const v = lo + (t / ticks) * (hi - lo);
    const y = sy(v).toFixed(1);
    grid += `<line class="gridline" x1="${padL}" x2="${width - padR}" y1="${y}" y2="${y}"/>`;
    grid += `<text x="${padL - 7}" y="${Number(y) + 3}" text-anchor="end">${v.toFixed(2)}%</text>`;
  }

  // --- stacked bars -------------------------------------------------------
  const GAP = 2;                       // surface gap between stacked segments
  let bars = '';
  if (showBars) {
    buckets.forEach((_, i) => {
      let up = 0, down = 0;
      series.forEach((s, si) => {
        const v = s.cumulative[i] || 0;
        if (Math.abs(v) < 1e-9) return;
        const from = v >= 0 ? up : down;
        const to = from + v;
        if (v >= 0) up = to; else down = to;
        const yTop = sy(Math.max(from, to));
        const raw = Math.abs(sy(to) - sy(from));
        const h = Math.max(raw - GAP, 0.6);
        bars += `<rect class="bar-seg" x="${(cx(i) - barW / 2).toFixed(1)}" y="${(yTop + (v >= 0 ? GAP : 0)).toFixed(1)}"
                   width="${barW.toFixed(1)}" height="${h.toFixed(1)}" rx="1.5"
                   fill="${colors[si]}" fill-opacity="0.9"/>`;
      });
    });
  }

  // --- total line, with a surface halo where it crosses the bars ----------
  const path = buckets.map((_, i) =>
    `${i ? 'L' : 'M'}${cx(i).toFixed(1)},${sy(total[i] || 0).toFixed(1)}`).join(' ');
  const lastX = cx(buckets.length - 1).toFixed(1);
  const lastY = sy(total[buckets.length - 1] || 0).toFixed(1);

  // --- x labels: first, last, and a couple between -------------------------
  let xLabels = '';
  const labelIdx = new Set([0, buckets.length - 1]);
  if (buckets.length > 6) {
    labelIdx.add(Math.floor(buckets.length / 3));
    labelIdx.add(Math.floor((2 * buckets.length) / 3));
  }
  [...labelIdx].sort((a, b) => a - b).forEach((i) => {
    const anchor = i === 0 ? 'start' : i === buckets.length - 1 ? 'end' : 'middle';
    const x = i === 0 ? padL : i === buckets.length - 1 ? width - padR : cx(i);
    xLabels += `<text x="${x.toFixed(1)}" y="${height - 8}" text-anchor="${anchor}">${isoDate(buckets[i])}</text>`;
  });

  // --- hover targets -------------------------------------------------------
  const hits = buckets.map((_, i) =>
    `<rect class="hit" data-i="${i}" x="${(padL + band * i).toFixed(1)}" y="${padT}"
           width="${band.toFixed(1)}" height="${plotH.toFixed(1)}"/>`).join('');

  host.innerHTML = `
    <svg class="chart" viewBox="0 0 ${width} ${height}" height="${height}" role="img"
         aria-label="Cumulative profit and loss attribution by contributor">
      ${grid}
      <line class="zero-line" x1="${padL}" x2="${width - padR}" y1="${zeroY.toFixed(1)}" y2="${zeroY.toFixed(1)}"/>
      ${bars}
      <path class="total-halo" d="${path}"/>
      <path class="total-line" d="${path}"/>
      <circle class="total-dot" cx="${lastX}" cy="${lastY}" r="3.5"/>
      <line class="crosshair" id="ch-line" x1="0" x2="0" y1="${padT}" y2="${padT + plotH}" style="display:none"/>
      ${xLabels}
      ${hits}
    </svg>
    <div class="chart-tooltip" hidden></div>
    <div class="chart-legend">
      ${legendHtml(
        allSeries.map((sr) => ({
          label: sr.label,
          color: palette.get(sr.label),
          hidden: isSeriesHidden(sr.label),
          sign: signClass(sr.total),
          value: pct(sr.total, 2),
        })),
        { totalEntry: {
            label: anyHidden ? 'Total (visible)' : 'Total',
            sign: signClass(total[total.length - 1]),
            value: pct(total[total.length - 1], 2),
        } },
      )}
    </div>`;

  // --- interaction ---------------------------------------------------------
  const tip = host.querySelector('.chart-tooltip');
  const chLine = host.querySelector('#ch-line');
  const svg = host.querySelector('svg');

  host.querySelectorAll('.hit').forEach((rect) => {
    rect.addEventListener('mouseenter', () => {
      const i = Number(rect.dataset.i);
      const rows = series
        .map((s, si) => ({ label: s.label, value: s.cumulative[i] || 0, color: colors[si] }))
        .filter((r) => Math.abs(r.value) > 1e-9)
        .sort((a, b) => b.value - a.value);
      tip.innerHTML = `
        <div class="tt-date">${isoDate(buckets[i])} · cumulative</div>
        <table>
          ${rows.map((r) => `<tr>
            <td><span class="lg-swatch" style="display:inline-block;width:8px;height:8px;border-radius:2px;background:${r.color};margin-right:5px"></span>${escapeHtml(r.label)}</td>
            <td class="tt-val ${signClass(r.value)}">${pct(r.value, 3)}</td></tr>`).join('')}
          <tr class="tt-total"><td>Total</td>
            <td class="tt-val ${signClass(total[i])}">${pct(total[i], 3)}</td></tr>
        </table>`;
      tip.hidden = false;

      const scale = (host.clientWidth || width) / width;
      const px = cx(i) * scale;
      tip.style.left = `${Math.min(Math.max(px + 12, 4), (host.clientWidth || width) - tip.offsetWidth - 4)}px`;
      tip.style.top = `${Math.max(padT * scale, 4)}px`;

      chLine.setAttribute('x1', cx(i).toFixed(1));
      chLine.setAttribute('x2', cx(i).toFixed(1));
      chLine.style.display = '';
    });
    rect.addEventListener('mouseleave', () => {
      tip.hidden = true;
      chLine.style.display = 'none';
    });
  });

  wireLegend(host);

  return { redraw: () => contributionChart(host, data, { height, showBars }) };
}

/* ==========================================================================
   Positioning chart
   --------------------------------------------------------------------------
   Stacked bars showing what the book was HOLDING through the period, on the
   same x-axis and in the same colours as the cumulative P&L chart above it.
   Longs stack upward from zero, shorts downward, so the funding sleeve sits
   below the line as the mirror of the market book it finances.

   Two rules make this chart trustworthy:
     * The buckets come from the server, computed by the same function that
       buckets the attribution chart, so the two axes cannot drift apart.
     * A weight is a LEVEL, so each column is the target in force at the END of
       that bucket - the same convention the cumulative line uses. It is not a
       sum of trades.

   Clicking a legend entry hides that series here AND in the chart above.
   ========================================================================== */
export function positioningChart(host, data, { height = 240 } = {}) {
  if (!host) return;
  host.innerHTML = '';
  host.classList.add('chart-host');

  const buckets = data.buckets || [];
  const allSeries = data.series || [];
  if (!buckets.length || !allSeries.length) {
    host.innerHTML = '<div class="empty-state">No positioning in this period.</div>';
    return;
  }

  const palette = new Map(allSeries.map((s, i) => [s.label, seriesColor(i, s.key)]));
  const series = allSeries.filter((s) => !isSeriesHidden(s.label));
  const colors = series.map((s) => palette.get(s.label));

  if (!series.length) {
    host.innerHTML = `<div class="empty-state">Every series is hidden.
      <button type="button" class="btn btn-sm" id="unhide-pos">Show all</button></div>`;
    const btn = host.querySelector('#unhide-pos');
    if (btn) btn.addEventListener('click', () => resetHiddenSeries());
    return;
  }

  const width = Math.max(host.clientWidth || 760, 380);
  const padL = 54, padR = 14, padT = 12, padB = 30;
  const plotW = width - padL - padR;
  const plotH = height - padT - padB;

  // Scale from the VISIBLE stack only, so hiding the funding sleeve actually
  // zooms into the market book rather than leaving it squashed against a scale
  // set by a series that is no longer drawn.
  let lo = 0, hi = 0;
  buckets.forEach((_, i) => {
    let up = 0, down = 0;
    series.forEach((sr) => {
      const v = sr.weights[i] || 0;
      if (v >= 0) up += v; else down += v;
    });
    hi = Math.max(hi, up);
    lo = Math.min(lo, down);
  });
  if (hi === lo) { hi += 1; lo -= 1; }
  const padV = (hi - lo) * 0.10;
  hi += padV; lo -= padV;

  const band = plotW / buckets.length;
  const barW = Math.min(band * 0.68, 26);
  const cx = (i) => padL + band * (i + 0.5);
  const sy = (v) => padT + (1 - (v - lo) / (hi - lo)) * plotH;
  const zeroY = sy(0);

  let grid = '';
  const ticks = 4;
  for (let t = 0; t <= ticks; t++) {
    const v = lo + (t / ticks) * (hi - lo);
    const y = sy(v).toFixed(1);
    grid += `<line class="gridline" x1="${padL}" x2="${width - padR}" y1="${y}" y2="${y}"/>`;
    grid += `<text x="${padL - 7}" y="${Number(y) + 3}" text-anchor="end">${v.toFixed(1)}%</text>`;
  }

  const GAP = 1.5;
  let bars = '';
  buckets.forEach((_, i) => {
    let up = 0, down = 0;
    series.forEach((sr, si) => {
      const v = sr.weights[i] || 0;
      if (Math.abs(v) < 1e-9) return;
      const from = v >= 0 ? up : down;
      const to = from + v;
      if (v >= 0) up = to; else down = to;
      const yTop = sy(Math.max(from, to));
      const raw = Math.abs(sy(to) - sy(from));
      const h = Math.max(raw - GAP, 0.6);
      bars += `<rect class="bar-seg" x="${(cx(i) - barW / 2).toFixed(1)}" y="${(yTop + (v >= 0 ? GAP : 0)).toFixed(1)}"
                 width="${barW.toFixed(1)}" height="${h.toFixed(1)}" rx="1.5"
                 fill="${colors[si]}" fill-opacity="0.9"/>`;
    });
  });

  let xLabels = '';
  const labelIdx = new Set([0, buckets.length - 1]);
  if (buckets.length > 6) {
    labelIdx.add(Math.floor(buckets.length / 3));
    labelIdx.add(Math.floor((2 * buckets.length) / 3));
  }
  [...labelIdx].sort((a, b) => a - b).forEach((i) => {
    const anchor = i === 0 ? 'start' : i === buckets.length - 1 ? 'end' : 'middle';
    const x = i === 0 ? padL : i === buckets.length - 1 ? width - padR : cx(i);
    xLabels += `<text x="${x.toFixed(1)}" y="${height - 8}" text-anchor="${anchor}">${isoDate(buckets[i])}</text>`;
  });

  const hits = buckets.map((_, i) =>
    `<rect class="hit" data-i="${i}" x="${(padL + band * i).toFixed(1)}" y="${padT}"
           width="${band.toFixed(1)}" height="${plotH.toFixed(1)}"/>`).join('');

  host.innerHTML = `
    <svg class="chart" viewBox="0 0 ${width} ${height}" height="${height}" role="img"
         aria-label="Target weight through the period, stacked by contributor">
      ${grid}
      <line class="zero-line" x1="${padL}" x2="${width - padR}" y1="${zeroY.toFixed(1)}" y2="${zeroY.toFixed(1)}"/>
      ${bars}
      <line class="crosshair" id="pos-ch" x1="0" x2="0" y1="${padT}" y2="${padT + plotH}" style="display:none"/>
      ${xLabels}
      ${hits}
    </svg>
    <div class="chart-tooltip" hidden></div>
    <div class="chart-legend">
      ${legendHtml(allSeries.map((sr) => ({
        label: sr.label,
        color: palette.get(sr.label),
        hidden: isSeriesHidden(sr.label),
        sign: signClass(sr.end_weight_pct),
        value: pct(sr.end_weight_pct, 2),
      })))}
    </div>`;

  const tip = host.querySelector('.chart-tooltip');
  const chLine = host.querySelector('#pos-ch');

  host.querySelectorAll('.hit').forEach((rect) => {
    rect.addEventListener('mouseenter', () => {
      const i = Number(rect.dataset.i);
      const rows = series
        .map((sr, si) => ({ label: sr.label, value: sr.weights[i] || 0, color: colors[si] }))
        .filter((r) => Math.abs(r.value) > 1e-9)
        .sort((a, b) => b.value - a.value);
      const net = rows.reduce((a, r) => a + r.value, 0);
      const gross = rows.reduce((a, r) => a + Math.abs(r.value), 0);
      tip.innerHTML = `
        <div class="tt-date">${isoDate(buckets[i])} \u00b7 target weights</div>
        <table>
          ${rows.map((r) => `<tr>
            <td><span class="lg-swatch" style="display:inline-block;width:8px;height:8px;border-radius:2px;background:${r.color};margin-right:5px"></span>${escapeHtml(r.label)}</td>
            <td class="tt-val ${signClass(r.value)}">${pct(r.value, 2)}</td></tr>`).join('')}
          <tr class="tt-total"><td>Gross</td><td class="tt-val">${pct(gross, 2)}</td></tr>
          <tr><td>Net</td><td class="tt-val ${signClass(net)}">${pct(net, 2)}</td></tr>
        </table>`;
      tip.hidden = false;

      const scale = (host.clientWidth || width) / width;
      const px = cx(i) * scale;
      tip.style.left = `${Math.min(Math.max(px + 12, 4), (host.clientWidth || width) - tip.offsetWidth - 4)}px`;
      tip.style.top = `${Math.max(padT * scale, 4)}px`;

      chLine.setAttribute('x1', cx(i).toFixed(1));
      chLine.setAttribute('x2', cx(i).toFixed(1));
      chLine.style.display = '';
    });
    rect.addEventListener('mouseleave', () => {
      tip.hidden = true;
      chLine.style.display = 'none';
    });
  });

  wireLegend(host);

  return { redraw: () => positioningChart(host, data, { height }) };
}
