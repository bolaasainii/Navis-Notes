/* Header/chrome behaviour shared by every page. */
import {
  initTheme, initPortfolioSelect, wireModal, openModal, closeModal,
  get as apiGet, post, toast, ui, currentPortfolio, initDatePickers,
} from './core.js';

const body = document.body;

initTheme(body.dataset.theme, body.dataset.density);
initDatePickers();
initPortfolioSelect();
wireModal('portfolio-modal');
wireModal('clone-modal');

/* ---- valuation date is shared state across tabs -------------------------- */
const valuationInput = document.getElementById('valuation-date');
if (valuationInput) {
  const stored = ui.get('valuationDate', null);
  if (stored && stored <= body.dataset.today) valuationInput.value = stored;
  valuationInput.addEventListener('change', () => {
    ui.set('valuationDate', valuationInput.value);
    document.dispatchEvent(new CustomEvent('ppt:valuation-changed', {
      detail: { date: valuationInput.value },
    }));
  });
}

export function valuationDate() {
  return (valuationInput && valuationInput.value) || body.dataset.today;
}

/* ---- new portfolio ------------------------------------------------------- */
const newBtn = document.getElementById('new-portfolio-btn');
if (newBtn) newBtn.addEventListener('click', () => openModal('portfolio-modal'));

const pfSave = document.getElementById('pf-save');
if (pfSave) {
  pfSave.addEventListener('click', async () => {
    const err = document.getElementById('pf-error');
    err.classList.add('hidden');
    const payload = {
      portfolio_id: document.getElementById('pf-id').value.trim(),
      name: document.getElementById('pf-name').value.trim(),
      owner: document.getElementById('pf-owner').value.trim() || null,
      inception_date: document.getElementById('pf-inception').value || null,
      description: document.getElementById('pf-desc').value.trim() || null,
      funding_benchmark: document.getElementById('pf-benchmark').value.trim() || null,
      funding_spread_bps: parseFloat(document.getElementById('pf-spread').value) || null,
    };
    try {
      const created = await post('/api/portfolios', payload);
      toast(`Created ${created.portfolio_id}`, 'ok');
      const p = new URLSearchParams(location.search);
      p.set('portfolio', created.portfolio_id);
      location.search = p.toString();
    } catch (e) {
      err.textContent = e.message;
      err.classList.remove('hidden');
    }
  });
}

/* ---- clone portfolio ----------------------------------------------------- */
const cloneBtn = document.getElementById('clone-portfolio-btn');
if (cloneBtn) {
  cloneBtn.addEventListener('click', () => {
    const src = currentPortfolio();
    if (!src) { toast('Select a portfolio first', 'warn'); return; }
    document.getElementById('cl-id').value = `${src}-copy`;
    openModal('clone-modal');
  });
}

const clSave = document.getElementById('cl-save');
if (clSave) {
  clSave.addEventListener('click', async () => {
    const err = document.getElementById('cl-error');
    err.classList.add('hidden');
    try {
      const created = await post(`/api/portfolios/${encodeURIComponent(currentPortfolio())}/clone`, {
        new_portfolio_id: document.getElementById('cl-id').value.trim(),
        new_name: document.getElementById('cl-name').value.trim() || null,
        copy_trades: document.getElementById('cl-trades').checked,
        copy_snapshots: document.getElementById('cl-snapshots').checked,
      });
      closeModal('clone-modal');
      toast(`Cloned to ${created.portfolio_id}`, 'ok');
      const p = new URLSearchParams(location.search);
      p.set('portfolio', created.portfolio_id);
      location.search = p.toString();
    } catch (e) {
      err.textContent = e.message;
      err.classList.remove('hidden');
    }
  });
}

/* ==========================================================================
   Live / Offline data mode
   --------------------------------------------------------------------------
   Live  = Bloomberg Desktop API. Only offered when a Terminal is actually
           reachable on this machine; otherwise the button is disabled and
           explains why on hover.
   Offline = deterministic synthetic data. Always available, and the default
           for anyone without Bloomberg.

   Switching reloads the page: prices, marks, duration and volatility all come
   from the other source, so re-rendering piecemeal would show a mix.
   ========================================================================== */
const seg = document.getElementById('seg-data-mode');

function paintMode(payload) {
  if (!seg) return;
  seg.querySelectorAll('button').forEach((b) => {
    b.setAttribute('aria-pressed', String(b.dataset.mode === payload.mode));
  });

  const liveBtn = seg.querySelector('button[data-mode="live"]');
  if (liveBtn) {
    const usable = payload.live_supported && (payload.live_available || payload.is_live);
    liveBtn.disabled = !usable;
    liveBtn.title = usable
      ? 'Bloomberg Desktop API — live prices from the Terminal on this machine'
      : (payload.live_unavailable_reason || 'Live Bloomberg data is not available on this machine');
  }

  const pill = document.getElementById('data-mode-pill');
  const label = document.getElementById('data-mode-label');
  if (pill && label) {
    pill.className = `pill ${payload.is_live ? 'live' : 'synthetic'}`;
    label.textContent = payload.is_live ? 'Bloomberg live' : 'Synthetic data';
    pill.title = payload.detail || '';
  }

  // Warn when the selected book's trades were priced in the OTHER mode. Entry
  // levels are historical fact and are never rewritten, so mixing sources
  // produces P&L that means nothing - say so rather than render it quietly.
  const box = document.getElementById('book-mode-warning');
  if (box) {
    const w = payload.book && payload.book.warning;
    box.innerHTML = w
      ? `<div class="banner banner-error" style="margin:8px 12px 0;"><div><strong>Mixed data sources.</strong> ${w}</div></div>`
      : '';
  }
}

async function refreshMode() {
  if (!seg) return;
  const p = currentPortfolio();
  try {
    paintMode(await apiGet(`/api/data-mode${p ? `?portfolio_id=${encodeURIComponent(p)}` : ''}`));
  } catch { /* header stays as server-rendered */ }
}

if (seg) {
  seg.querySelectorAll('button').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const target = btn.dataset.mode;
      if (btn.getAttribute('aria-pressed') === 'true' || btn.disabled) return;

      const previous = seg.querySelector('button[aria-pressed="true"]');
      btn.disabled = true;
      try {
        const result = await post('/api/data-mode', {
          mode: target,
          portfolio_id: currentPortfolio(),
        });
        if (result.switch_ok) {
          toast(`Switched to ${target === 'live' ? 'live Bloomberg' : 'offline synthetic'} data`, 'ok');
          location.reload();
        } else {
          paintMode(result);
          if (previous) previous.setAttribute('aria-pressed', 'true');
          toast(result.switch_reason || 'Could not switch data mode', 'error', 12000);
        }
      } catch (e) {
        toast(e.message, 'error', 10000);
      } finally {
        btn.disabled = false;
      }
    });
  });

  refreshMode();
}
