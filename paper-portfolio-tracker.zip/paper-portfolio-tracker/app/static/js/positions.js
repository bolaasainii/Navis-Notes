/* ==========================================================================
   positions.js - main grid, KPI band, analytics drawer, trade entry.

   Grid features:
     * multi-level nested grouping (pick any combination of L1-L4)
     * user-configurable columns: show / hide / reorder, with presets
     * per-group subtotals and a pinned grand total
   Layout choices persist per browser via localStorage.
   ========================================================================== */
import {
  get, post, pct, num, yrs, isoDate, signClass, escapeHtml, toast,
  openModal, closeModal, wireModal, ui, currentPortfolio, exposureBar,
  initDatePickers,
} from './core.js';

const body = document.body;
const TODAY = body.dataset.today;
const PORTFOLIO = currentPortfolio();

/* ==========================================================================
   Column definitions
   --------------------------------------------------------------------------
   `agg` controls what a group/subtotal/total row shows for the column:
     'sum'  - additive across rows (weights, P&L, duration contribution)
     null   - not meaningful to aggregate; left blank rather than summed,
              because summing entry prices or durations would be nonsense.
   ========================================================================== */
const COLUMN_DEFS = [
  { key: 'instrument_name', label: 'Instrument', width: 210, sort: true, locked: true, group: 'Identity' },
  { key: 'ticker',          label: 'Ticker',     width: 108, sort: true, locked: true, mono: true, group: 'Identity' },

  { key: 'level_1', label: 'L1', width: 96,  sort: true, group: 'Hierarchy' },
  { key: 'level_2', label: 'L2', width: 150, sort: true, group: 'Hierarchy' },
  { key: 'level_3', label: 'L3', width: 140, sort: true, group: 'Hierarchy' },
  { key: 'level_4', label: 'L4', width: 130, sort: true, group: 'Hierarchy' },
  { key: 'primary_exchange', label: 'Exchange', width: 90, sort: true, group: 'Hierarchy' },

  { key: 'net_weight_pct', label: 'Current target %', num: true, sort: true, agg: 'sum', group: 'Position', expander: true },
  { key: 'exec',           label: 'Exec',     width: 130, group: 'Position' },
  { key: 'avg_open_level', label: 'Entry',    num: true, sort: true, group: 'Position' },
  { key: 'latest_level',   label: 'Latest',   num: true, sort: true, group: 'Position' },
  { key: 'latest_level_date', label: 'Mark date', width: 90, sort: true, group: 'Position' },

  { key: 'pnl.today', label: 'Today', num: true, sort: true, agg: 'sum', group: 'P&L' },
  { key: 'pnl.mtd',   label: 'MTD',   num: true, sort: true, agg: 'sum', group: 'P&L' },
  { key: 'pnl.qtd',   label: 'QTD',   num: true, sort: true, agg: 'sum', group: 'P&L' },
  { key: 'pnl.ytd',   label: 'YTD',   num: true, sort: true, agg: 'sum', group: 'P&L' },
  { key: 'pnl.itd',   label: 'ITD',   num: true, sort: true, agg: 'sum', group: 'P&L' },
  { key: 'realised_pnl_pct',   label: 'Realised',   num: true, sort: true, agg: 'sum', group: 'P&L' },
  { key: 'unrealised_pnl_pct', label: 'Unrealised', num: true, sort: true, agg: 'sum', group: 'P&L' },

  { key: 'duration_years',        label: 'Dur',         num: true, sort: true, group: 'Risk' },
  { key: 'duration_contribution', label: 'Dur contrib', num: true, sort: true, agg: 'sum', group: 'Risk' },
  { key: 'instrument_vol_pct',    label: 'Inst vol',    num: true, sort: true, group: 'Risk' },
  { key: 'standalone_vol_pct',    label: 'S/A vol',     num: true, sort: true, agg: 'sum', group: 'Risk' },
  { key: 'vol_observations',      label: 'Vol obs',     num: true, sort: true, group: 'Risk' },

  // Only populated on expanded history rows: what the position earned while
  // that particular target was in force. Blank on the parent row, where the
  // period columns already answer the question.
  { key: 'leg_pnl_pct', label: 'Leg P&L', num: true, group: 'P&L' },

  { key: 'notes', label: 'Notes / source', width: 200, group: 'Other' },
];

const DEF_BY_KEY = Object.fromEntries(COLUMN_DEFS.map((c) => [c.key, c]));
const LOCKED = COLUMN_DEFS.filter((c) => c.locked).map((c) => c.key);

const PRESETS = {
  basic: ['instrument_name', 'ticker', 'level_1', 'level_2', 'net_weight_pct',
    'avg_open_level', 'latest_level', 'pnl.today', 'pnl.mtd', 'pnl.qtd', 'pnl.ytd',
    'duration_years', 'duration_contribution', 'standalone_vol_pct', 'leg_pnl_pct', 'notes'],
  advanced: ['instrument_name', 'ticker', 'level_1', 'level_2', 'level_3', 'level_4',
    'net_weight_pct', 'exec', 'avg_open_level', 'latest_level', 'latest_level_date',
    'pnl.today', 'pnl.mtd', 'pnl.qtd', 'pnl.ytd', 'pnl.itd',
    'realised_pnl_pct', 'unrealised_pnl_pct',
    'duration_years', 'duration_contribution', 'instrument_vol_pct',
    'standalone_vol_pct', 'leg_pnl_pct', 'notes'],
  risk: ['instrument_name', 'ticker', 'level_1', 'level_3', 'net_weight_pct',
    'duration_years', 'duration_contribution', 'instrument_vol_pct',
    'standalone_vol_pct', 'vol_observations'],
  all: COLUMN_DEFS.map((c) => c.key),
};

const GROUP_LEVELS = ['level_1', 'level_2', 'level_3', 'level_4'];

/* Canonical presentation order for the top of the hierarchy: risk assets, then
   rates, then currency, with the financing leg last. This is the order the book
   is discussed in - it should not reshuffle because one bucket happened to grow
   this week. Deeper levels still sort by gross exposure, where biggest-first is
   the useful ordering. Mirrors ASSET_CLASS_ORDER in app/services/exposure.py. */
const ASSET_CLASS_ORDER = ['Equity', 'Fixed Income', 'FX', 'Cash & Funding'];
function assetClassRank(label) {
  const i = ASSET_CLASS_ORDER.indexOf(label);
  return i < 0 ? ASSET_CLASS_ORDER.length : i;
}

/* ==========================================================================
   State
   ========================================================================== */
const state = {
  view: null,
  basis: ui.get('basis', 'net'),
  density: ui.get('density', 'compact'),
  windowKey: ui.get('windowKey', 'mtd'),
  groupBy: ui.get('groupBy', []),            // ordered subset of GROUP_LEVELS
  columns: ui.get('columns', PRESETS.basic),
  showOffset: ui.get('showOffset', body.dataset.showOffset === 'true'),
  includeInactive: ui.get('includeInactive', false),
  showSubtotals: ui.get('showSubtotals', false),
  // Expands each position into its dated target history for the selected
  // positioning window, and widens the row set to include positions closed
  // inside that window.
  showHistory: ui.get('showHistory', false),
  filter: '',
  sortKey: null,
  sortDir: 1,
  collapsed: new Set(ui.get('collapsedGroups', [])),
};

// Drop any column keys from an older build.
state.columns = state.columns.filter((k) => DEF_BY_KEY[k]);
LOCKED.forEach((k, i) => { if (!state.columns.includes(k)) state.columns.splice(i, 0, k); });

const visibleColumns = () => state.columns
  .map((k) => DEF_BY_KEY[k])
  .filter(Boolean)
  // Leg P&L only exists on history rows, so the column is suppressed entirely
  // when history is collapsed rather than sitting there empty.
  .filter((c) => c.key !== 'leg_pnl_pct' || state.showHistory);
const cellValueOf = (row, key) =>
  key.startsWith('pnl.') ? (row.pnl || {})[key.slice(4)] : row[key];

/* ==========================================================================
   Windows
   ========================================================================== */
function windowBounds() {
  const v = document.getElementById('valuation-date').value || TODAY;
  const d = new Date(`${v}T00:00:00`);
  const iso = (x) => x.toISOString().slice(0, 10);
  switch (state.windowKey) {
    case 'qtd': {
      const q = Math.floor(d.getMonth() / 3) * 3;
      return [iso(new Date(d.getFullYear(), q, 1)), v];
    }
    case 'ytd': return [iso(new Date(d.getFullYear(), 0, 1)), v];
    case 'custom': {
      const s = document.getElementById('window-start').value;
      const e = document.getElementById('window-end').value;
      return [s || iso(new Date(d.getFullYear(), d.getMonth(), 1)), e || v];
    }
    default: return [iso(new Date(d.getFullYear(), d.getMonth(), 1)), v];
  }
}

/* ==========================================================================
   Load
   ========================================================================== */
async function load() {
  if (!PORTFOLIO) {
    document.getElementById('grid-wrap').innerHTML =
      '<div class="empty-state"><strong>No portfolio selected</strong>Create one with the “New” button in the header.</div>';
    return;
  }
  const valuation = document.getElementById('valuation-date').value || TODAY;
  const [ws, we] = windowBounds();
  const params = new URLSearchParams({
    valuation_date: valuation,
    window_start: ws,
    window_end: we,
    include_inactive: String(state.includeInactive),
    include_offset: 'true',
    include_history: String(state.showHistory),
  });
  document.getElementById('grid-wrap').innerHTML =
    '<div class="empty-state"><span class="spinner"></span> Recomputing…</div>';
  try {
    state.view = await get(`/api/portfolios/${encodeURIComponent(PORTFOLIO)}/positions?${params}`);
  } catch (e) {
    document.getElementById('grid-wrap').innerHTML =
      `<div class="empty-state"><strong>Could not load positions</strong>${escapeHtml(e.message)}</div>`;
    return;
  }
  renderAll();
}

function renderAll() {
  renderKpis();
  renderDiagnostics();
  renderGrid();
  renderDrawer();
  const w = state.view.windows;
  document.getElementById('window-summary').textContent =
    `Valued ${isoDate(w.valuation_date)} · positioning ${isoDate(w.positioning_start)} → ${isoDate(w.positioning_end)} · vol lookback ${w.vol_lookback_days}d`;
}

/* ==========================================================================
   KPI band
   ========================================================================== */
function setKpi(id, value, formatter = pct, subId = null, subText = null) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = formatter(value);
  el.className = `kpi-value ${signClass(value)}`;
  if (subId && subText !== null) document.getElementById(subId).textContent = subText;
}

function renderKpis() {
  const k = state.view.kpis;
  setKpi('kpi-net', k.total.net_pct, pct, 'kpi-net-sub', `${k.total.row_count} positions`);

  const grossEl = document.getElementById('kpi-gross');
  grossEl.textContent = pct(k.total.gross_pct, 2, false);
  grossEl.className = 'kpi-value';
  document.getElementById('kpi-gross-sub').textContent =
    `L ${pct(k.total.long_pct, 1)} / S ${pct(k.total.short_pct, 1)}`;

  setKpi('kpi-eq', k.equity.net_pct, pct, 'kpi-eq-sub', `gross ${pct(k.equity.gross_pct, 1, false)}`);
  setKpi('kpi-fi', k.fixed_income.net_pct, pct, 'kpi-fi-sub', `gross ${pct(k.fixed_income.gross_pct, 1, false)}`);
  setKpi('kpi-fx', k.fx.net_pct, pct, 'kpi-fx-sub', `gross ${pct(k.fx.gross_pct, 1, false)}`);
  setKpi('kpi-dur', k.duration_target_years, yrs);

  setKpi('kpi-today', k.pnl.today);
  setKpi('kpi-mtd', k.pnl.mtd);
  setKpi('kpi-qtd', k.pnl.qtd);
  setKpi('kpi-ytd', k.pnl.ytd);
  setKpi('kpi-itd', k.pnl.itd);
  renderLeverage(k);
}

/* --------------------------------------------------------------------------
   Cost of leverage
   --------------------------------------------------------------------------
   The funding sleeve weight is a LEVERAGE measure - how much of NAV is
   financed - not a cost. The cost is the accrual on it, so that is what the
   tile reports: the annualised run rate (what holding this book costs per
   year at today's rate), with the financed notional and the funding source
   underneath, and the accrued-to-date figures on hover.
   -------------------------------------------------------------------------- */
function renderLeverage(k) {
  const lev = k.leverage || {};
  const el = document.getElementById('kpi-lev');
  const sub = document.getElementById('kpi-lev-sub');
  const tile = document.getElementById('kpi-lev-tile');
  if (!el) return;

  const financed = lev.financed_pct ?? k.funding_sleeve_pct ?? 0;
  const annual = lev.annual_run_rate_pct;

  if (Math.abs(financed) < 1e-9) {
    el.textContent = '–';
    el.className = 'kpi-value zero';
    sub.textContent = 'unlevered';
    tile.title = 'The book carries no financed notional.';
    return;
  }

  el.textContent = `${pct(annual, 2)}`;
  el.className = `kpi-value ${signClass(annual)}`;
  // A negative sleeve is borrowing; a positive one is cash on deposit.
  sub.textContent = financed < 0
    ? `p.a. on ${pct(Math.abs(financed), 2, false)} financed`
    : `p.a. earned on ${pct(financed, 2, false)} cash`;
  tile.title =
    `${lev.footnote || ''}\n` +
    `Accrued MTD ${pct(lev.accrued_mtd_pct, 3)} · YTD ${pct(lev.accrued_ytd_pct, 3)} · ` +
    `since inception ${pct(lev.accrued_itd_pct, 3)}\n` +
    `Book nets to ${pct(k.book_nets_to, 4)} including the sleeve.`;
}

/* ==========================================================================
   Diagnostics banner
   ========================================================================== */
function renderDiagnostics() {
  const d = state.view.diagnostics;
  const parts = [];
  if (d.unpriced_instruments.length) {
    parts.push(`<div class="banner banner-error"><div><strong>${d.unpriced_instruments.length} instrument(s) have no price.</strong>
      Their P&amp;L and volatility are excluded: <span class="mono">${d.unpriced_instruments.map(escapeHtml).join(', ')}</span></div></div>`);
  }
  const soft = [];
  if (d.prices_with_fallback.length)
    soft.push(`${d.prices_with_fallback.length} position(s) used a prior official print (holiday or closed market)`);
  if (d.duration_from_proxy.length)
    soft.push(`${d.duration_from_proxy.length} duration(s) from the static proxy table`);
  if (d.duration_unavailable.length)
    soft.push(`${d.duration_unavailable.length} duration(s) unavailable and excluded from the target`);
  if (d.manual_execution_levels.length)
    soft.push(`${d.manual_execution_levels.length} position(s) carry a manually entered level`);
  if (d.thin_volatility_samples.length)
    soft.push(`${d.thin_volatility_samples.length} volatility estimate(s) from a thin sample`);
  if (soft.length) {
    parts.push(`<div class="banner banner-info"><div><strong>Provenance.</strong> ${soft.join(' · ')}.
      Tags on each row show which. Open the analytics panel for detail.</div></div>`);
  }
  document.getElementById('diagnostics').innerHTML = parts.join('');
}

/* ==========================================================================
   Row selection, sorting, formatting
   ========================================================================== */
function visibleRows() {
  let rows = state.view.rows.slice();
  if (!state.showOffset) rows = rows.filter((r) => !r.is_funding_offset);
  if (state.filter) {
    const f = state.filter.toLowerCase();
    rows = rows.filter((r) =>
      [r.ticker, r.instrument_name, r.level_1, r.level_2, r.level_3, r.level_4, r.notes]
        .filter(Boolean).some((v) => String(v).toLowerCase().includes(f)));
  }
  if (state.sortKey) {
    const k = state.sortKey;
    rows.sort((a, b) => {
      let av = cellValueOf(a, k);
      let bv = cellValueOf(b, k);
      if (state.basis === 'gross' && k === 'net_weight_pct') { av = Math.abs(av); bv = Math.abs(bv); }
      if (av === bv) return 0;
      if (av === null || av === undefined) return 1;
      if (bv === null || bv === undefined) return -1;
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * state.sortDir;
      return String(av).localeCompare(String(bv)) * state.sortDir;
    });
  }
  return rows;
}

function formatCell(row, col) {
  const v = cellValueOf(row, col.key);
  switch (col.key) {
    case 'instrument_name':
      return `<span title="${escapeHtml(row.instrument_name)}">${escapeHtml(row.instrument_name)}</span>`;
    case 'ticker':
      return `<span class="mono">${escapeHtml(row.ticker)}</span>`;
    case 'net_weight_pct': {
      const w = state.basis === 'gross' ? Math.abs(row.net_weight_pct) : row.net_weight_pct;
      return pct(w, 2, state.basis !== 'gross');
    }
    case 'exec': return execTags(row);
    case 'avg_open_level':
    case 'latest_level':
      return v === null || v === undefined ? '–' : num(v, 3);
    case 'latest_level_date': return isoDate(v);
    case 'duration_years': return durationCell(row);
    case 'duration_contribution':
      return v === null || v === undefined ? '–' : yrs(v, 3);
    case 'instrument_vol_pct':
    case 'standalone_vol_pct':
      return v === null || v === undefined ? '–' : pct(v, 2, false);
    case 'vol_observations': return v === null || v === undefined ? '–' : String(v);
    case 'notes':
      return `<span class="faint" title="${escapeHtml(v || '')}">${escapeHtml(v || '')}</span>`;
    default:
      if (col.num) return v === null || v === undefined ? '–' : pct(v, 3);
      return escapeHtml(v === null || v === undefined ? '' : v);
  }
}

function execTags(row) {
  const tags = (row.execution_types || []).map((t) => `<span class="tag">${escapeHtml(t)}</span>`);
  if (row.has_price_fallback) tags.push('<span class="tag tag-fallback" title="One or more legs used a prior official print">stale</span>');
  if (row.has_manual_level) tags.push('<span class="tag tag-manual" title="One or more legs carry a manually entered level">manual</span>');
  return tags.join(' ');
}

function durationCell(row) {
  if (row.duration_years === null || row.duration_years === undefined) {
    return row.duration_source === 'n/a'
      ? '<span class="tag tag-na" title="Duration is not meaningful for this instrument">n/a</span>'
      : '<span class="tag tag-fallback">none</span>';
  }
  const cls = { direct: 'tag-direct', proxy: 'tag-proxy', override: 'tag-manual' }[row.duration_source] || 'tag-na';
  return `${num(row.duration_years, 2)} <span class="tag ${cls}" title="${escapeHtml(row.duration_note || row.duration_source)}">${escapeHtml(row.duration_source || '')}</span>`;
}

/* ==========================================================================
   Aggregation
   ========================================================================== */
function aggregate(rows, col) {
  if (!col.agg) return null;   // includes leg_pnl_pct: legs live under rows
  const market = rows.filter((r) => !r.is_funding_offset);
  if (col.key === 'net_weight_pct' && state.basis === 'gross') {
    return market.reduce((s, r) => s + Math.abs(r.net_weight_pct || 0), 0);
  }
  return market.reduce((s, r) => s + (cellValueOf(r, col.key) || 0), 0);
}

function formatAggregate(value, col) {
  if (value === null) return '';
  if (col.key === 'duration_contribution') return yrs(value, 3);
  if (col.key === 'standalone_vol_pct') return pct(value, 2, false);
  if (col.key === 'net_weight_pct') return pct(value, 2, state.basis !== 'gross');
  return pct(value, 3);
}

/* ==========================================================================
   Grid rendering
   ========================================================================== */
function stickyClass(col, index) {
  if (index === 0) return 'sticky-1';
  if (index === 1 && col.locked) return 'sticky-2';
  return '';
}

function renderGrid() {
  const cols = visibleColumns();
  const rows = visibleRows();
  const wrap = document.getElementById('grid-wrap');

  document.getElementById('group-path').textContent = state.groupBy.length
    ? state.groupBy.map((g) => g.replace('level_', 'L')).join(' › ')
    : '';

  if (!rows.length) {
    wrap.innerHTML =
      '<div class="empty-state"><strong>No positions</strong>Add a trade or import a history file to populate this book.</div>';
    return;
  }

  const head = cols.map((c, i) => {
    const cls = [stickyClass(c, i), c.num ? 'num' : '', c.sort ? 'sortable' : '']
      .filter(Boolean).join(' ');
    const mark = state.sortKey === c.key
      ? `<span class="sort-mark">${state.sortDir > 0 ? '▲' : '▼'}</span>` : '';
    const style = c.width ? ` style="min-width:${c.width}px"` : '';
    // The target column carries the history expander, to the left of its label.
    const exp = c.expander
      ? `<button class="hist-toggle" id="history-toggle" aria-pressed="${state.showHistory}"
                 title="Show each position's target history for the selected positioning window, including positions closed inside it">${state.showHistory ? '▾' : '▸'}</button>`
      : '';
    return `<th class="${cls}" data-sort-key="${c.key}"${style}>${exp}${escapeHtml(c.label)}${mark}</th>`;
  }).join('');

  const bodyHtml = state.groupBy.length
    ? renderGroups(buildTree(rows, 0), cols, 0, '')
    : rows.map((r) => positionRow(r, cols)).join('');

  // The grand total leads the table rather than trailing it: it is the number
  // most often read, and putting it under the header means it is visible
  // without scrolling to the bottom of a long book. It stays pinned there.
  const grand = aggregateRow(rows.filter((r) => !r.is_funding_offset), cols,
    'Total (ex funding)', 'total-row total-top', 0);

  wrap.innerHTML =
    `<table class="grid"><thead><tr>${head}</tr></thead><tbody>${grand}${bodyHtml}</tbody></table>`;

  const histBtn = wrap.querySelector('#history-toggle');
  if (histBtn) {
    histBtn.addEventListener('click', (e) => {
      e.stopPropagation();                 // do not also sort the column
      state.showHistory = !state.showHistory;
      ui.set('showHistory', state.showHistory);
      load();                              // the row set itself changes
    });
  }

  wrap.querySelectorAll('thead th.sortable').forEach((th) => {
    th.addEventListener('click', (e) => {
      if (e.target.closest('.hist-toggle')) return;
      const key = th.dataset.sortKey;
      if (state.sortKey === key) state.sortDir = -state.sortDir;
      else { state.sortKey = key; state.sortDir = -1; }
      renderGrid();
    });
  });
  wrap.querySelectorAll('tr.group-row').forEach((tr) => {
    tr.addEventListener('click', () => {
      const path = tr.dataset.path;
      if (state.collapsed.has(path)) state.collapsed.delete(path);
      else state.collapsed.add(path);
      ui.set('collapsedGroups', [...state.collapsed]);
      renderGrid();
    });
  });
  wrap.querySelectorAll('tr[data-ticker]').forEach((tr) => {
    tr.addEventListener('click', () => showDetail(tr.dataset.ticker));
  });
}

/** Nest rows into a tree keyed by the selected hierarchy levels. */
function buildTree(rows, depth) {
  if (depth >= state.groupBy.length) return rows;
  const key = state.groupBy[depth];
  const buckets = new Map();
  rows.forEach((r) => {
    const k = r[key] || 'Unclassified';
    if (!buckets.has(k)) buckets.set(k, []);
    buckets.get(k).push(r);
  });
  const entries = [...buckets.entries()];
  if (key === 'level_1') {
    entries.sort((a, b) => {
      const d = assetClassRank(a[0]) - assetClassRank(b[0]);
      return d !== 0 ? d : a[0].localeCompare(b[0]);
    });
  } else {
    // Largest gross exposure first - the biggest risk at the top of its parent.
    const g = (list) => list.reduce((s, r) => s + Math.abs(r.net_weight_pct || 0), 0);
    entries.sort((a, b) => g(b[1]) - g(a[1]));
  }
  return entries
    .map(([label, groupRows]) => ({
      label,
      rows: groupRows,
      children: buildTree(groupRows, depth + 1),
    }));
}

function renderGroups(nodes, cols, depth, parentPath) {
  if (!Array.isArray(nodes) || !nodes.length) return '';
  if (depth >= state.groupBy.length) {
    return nodes.map((r) => positionRow(r, cols, depth)).join('');
  }
  return nodes.map((node) => {
    const path = `${parentPath}/${node.label}`;
    const open = !state.collapsed.has(path);
    let html = groupRow(node, cols, depth, path, open);
    if (open) {
      html += renderGroups(node.children, cols, depth + 1, path);
      // The group header row already carries the group's aggregates at the TOP
      // of the group, so a trailing subtotal is a repeat. Offered, not default.
      if (state.showSubtotals && depth === state.groupBy.length - 1) {
        html += aggregateRow(node.rows, cols, `${node.label} subtotal`, 'subtotal-row', depth + 1);
      }
    }
    return html;
  }).join('');
}

/** A collapsible group header that also carries the group's aggregates. */
function groupRow(node, cols, depth, path, open) {
  const market = node.rows.filter((r) => !r.is_funding_offset);
  const tds = cols.map((c, i) => {
    const cls = [stickyClass(c, i), c.num ? 'num' : ''].filter(Boolean).join(' ');
    if (i === 0) {
      return `<td class="${cls}">
        <span class="group-label" style="padding-left:${depth * 14}px">
          <button class="expand-btn">${open ? '▾' : '▸'}</button>
          ${escapeHtml(node.label)}
          <span class="group-count">${market.length}</span>
        </span></td>`;
    }
    const value = aggregate(node.rows, c);
    if (value === null) return `<td class="${cls}"></td>`;
    return `<td class="${cls} ${signClass(value)}">${formatAggregate(value, c)}</td>`;
  }).join('');
  return `<tr class="group-row depth-${Math.min(depth, 3)}" data-path="${escapeHtml(path)}">${tds}</tr>`;
}

function positionRow(row, cols, depth = 0) {
  const classes = [];
  if (row.is_funding_offset) classes.push('offset-row');
  if (!row.is_active) classes.push('inactive-row');
  if (state.showHistory && !row.is_active) classes.push('closed-in-window');
  const tds = cols.map((c, i) => {
    const value = cellValueOf(row, c.key);
    const cls = [stickyClass(c, i), c.num ? 'num' : '', c.num ? signClass(value) : '']
      .filter(Boolean).join(' ');
    const pad = i === 0 && depth
      ? ` style="padding-left:${8 + depth * 14}px"` : '';
    return `<td class="${cls}"${pad}>${formatCell(row, c)}</td>`;
  }).join('');
  let html = `<tr data-ticker="${escapeHtml(row.ticker)}" class="${classes.join(' ')}">${tds}</tr>`;

  if (state.showHistory && (row.target_history || []).length) {
    html += row.target_history.map((leg) => historyRow(row, leg, cols, depth)).join('');
  }
  return html;
}

/* One dated target that was in force during the positioning window. */
function historyRow(row, leg, cols, depth) {
  const span = leg.effective_to
    ? `${isoDate(leg.effective_from)} → ${isoDate(leg.effective_to)}`
    : `${isoDate(leg.effective_from)} → on`;

  const tds = cols.map((c, i) => {
    const cls = [stickyClass(c, i), c.num ? 'num' : ''].filter(Boolean).join(' ');
    switch (c.key) {
      case 'instrument_name': {
        const tag = leg.is_opening
          ? '<span class="tag tag-na" title="Weight carried into the window, not traded inside it">carried in</span>'
          : `<span class="tag ${leg.delta_pct >= 0 ? 'tag-direct' : 'tag-manual'}">${pct(leg.delta_pct)}</span>`;
        const flat = leg.is_closing_flat
          ? ' <span class="tag tag-fallback" title="This change took the position flat">closed</span>' : '';
        return `<td class="${cls}" style="padding-left:${20 + depth * 14}px">
                  <span class="hist-span">${span}</span> ${tag}${flat}</td>`;
      }
      case 'ticker':
        return `<td class="${cls}"><span class="mono faint">${escapeHtml(row.ticker)}</span></td>`;
      case 'net_weight_pct': {
        const w = state.basis === 'gross' ? Math.abs(leg.target_pct) : leg.target_pct;
        return `<td class="${cls} ${signClass(w)}">${pct(w, 2, state.basis !== 'gross')}</td>`;
      }
      case 'avg_open_level':
        return `<td class="${cls}">${leg.level === null || leg.level === undefined ? '' : num(leg.level, 3)}</td>`;
      case 'latest_level_date':
        return `<td class="${cls}">${isoDate(leg.effective_from)}</td>`;
      case 'exec': {
        if (leg.is_opening) return `<td class="${cls}"></td>`;
        const tags = [];
        if (leg.execution_type) tags.push(`<span class="tag">${escapeHtml(leg.execution_type)}</span>`);
        if (leg.fallback_days) tags.push(`<span class="tag tag-fallback">stale ${leg.fallback_days}d</span>`);
        if (leg.level_source === 'manual' || leg.level_source === 'imported')
          tags.push('<span class="tag tag-manual">manual</span>');
        return `<td class="${cls}">${tags.join(' ')}</td>`;
      }
      case 'leg_pnl_pct':
        return `<td class="${cls} ${signClass(leg.leg_pnl_pct)}">${pct(leg.leg_pnl_pct, 3)}</td>`;
      case 'notes':
        return `<td class="${cls}"><span class="faint">${escapeHtml(leg.notes || '')}</span></td>`;
      // Hierarchy repeats and period P&L are properties of the instrument, not
      // of one leg - left blank rather than restated or, worse, invented.
      default:
        return `<td class="${cls}"></td>`;
    }
  }).join('');
  return `<tr class="history-row">${tds}</tr>`;
}

function aggregateRow(rows, cols, label, rowClass, depth) {
  const tds = cols.map((c, i) => {
    const cls = [stickyClass(c, i), c.num ? 'num' : ''].filter(Boolean).join(' ');
    if (i === 0) {
      return `<td class="${cls}" style="padding-left:${8 + depth * 14}px"><strong>${escapeHtml(label)}</strong></td>`;
    }
    const value = aggregate(rows, c);
    if (value === null) return `<td class="${cls}"></td>`;
    return `<td class="${cls} ${signClass(value)}">${formatAggregate(value, c)}</td>`;
  }).join('');
  return `<tr class="${rowClass}">${tds}</tr>`;
}

/* ==========================================================================
   Column chooser
   ========================================================================== */
function renderColumnChooser() {
  const listEl = document.getElementById('col-list');
  const chosen = state.columns;
  const rest = COLUMN_DEFS.map((c) => c.key).filter((k) => !chosen.includes(k));
  const ordered = [...chosen, ...rest];

  listEl.innerHTML = ordered.map((key) => {
    const def = DEF_BY_KEY[key];
    const on = chosen.includes(key);
    return `<div class="col-item ${def.locked ? 'locked' : ''}" data-key="${key}"
                 ${def.locked ? '' : 'draggable="true"'}>
      <span class="col-handle">⠿</span>
      <input type="checkbox" ${on ? 'checked' : ''} ${def.locked ? 'disabled' : ''}>
      <span class="col-name">${escapeHtml(def.label)}</span>
      <span class="col-group">${escapeHtml(def.group)}</span>
      <span class="col-move">
        <button data-dir="up" title="Move up">▲</button>
        <button data-dir="down" title="Move down">▼</button>
      </span>
    </div>`;
  }).join('');

  listEl.querySelectorAll('.col-item').forEach((item) => {
    const key = item.dataset.key;

    const cb = item.querySelector('input[type="checkbox"]');
    if (cb) {
      cb.addEventListener('change', () => {
        if (cb.checked) {
          if (!state.columns.includes(key)) state.columns.push(key);
        } else {
          state.columns = state.columns.filter((k) => k !== key);
        }
        persistColumns();
      });
    }

    item.querySelectorAll('.col-move button').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        moveColumn(key, btn.dataset.dir === 'up' ? -1 : 1);
      });
    });

    item.addEventListener('dragstart', (e) => {
      item.classList.add('dragging');
      e.dataTransfer.setData('text/plain', key);
      e.dataTransfer.effectAllowed = 'move';
    });
    item.addEventListener('dragend', () => {
      item.classList.remove('dragging');
      listEl.querySelectorAll('.col-item').forEach((x) => x.classList.remove('drop-target'));
    });
    item.addEventListener('dragover', (e) => {
      e.preventDefault();
      item.classList.add('drop-target');
    });
    item.addEventListener('dragleave', () => item.classList.remove('drop-target'));
    item.addEventListener('drop', (e) => {
      e.preventDefault();
      const from = e.dataTransfer.getData('text/plain');
      if (from && from !== key) dropColumn(from, key);
    });
  });
}

function moveColumn(key, delta) {
  const i = state.columns.indexOf(key);
  if (i < 0) return;
  const j = i + delta;
  // Locked identity columns stay pinned at the front.
  if (j < LOCKED.length || j >= state.columns.length) return;
  const [item] = state.columns.splice(i, 1);
  state.columns.splice(j, 0, item);
  persistColumns();
}

function dropColumn(fromKey, ontoKey) {
  if (!state.columns.includes(fromKey)) state.columns.push(fromKey);
  const from = state.columns.indexOf(fromKey);
  if (from >= 0) state.columns.splice(from, 1);
  let onto = state.columns.indexOf(ontoKey);
  if (onto < 0) onto = state.columns.length;
  state.columns.splice(Math.max(onto, LOCKED.length), 0, fromKey);
  persistColumns();
}

function persistColumns() {
  // Identity columns are always present and always first.
  state.columns = [
    ...LOCKED,
    ...state.columns.filter((k) => !LOCKED.includes(k)),
  ];
  ui.set('columns', state.columns);
  renderColumnChooser();
  renderGrid();
}

/* ==========================================================================
   Drawer
   ========================================================================== */
function renderDrawer() {
  const v = state.view;
  const rollups = v.rollups;
  const maxGross = Math.max(...(rollups.level_1 || []).map((b) => Math.abs(b.gross_pct)), 1);

  const rollupRows = (buckets) => buckets.map((b) => `
    <tr>
      <td>${escapeHtml(b.label)}</td>
      <td class="num ${signClass(b.net_pct)}">${pct(b.net_pct, 2)}</td>
      <td class="num">${pct(b.gross_pct, 2, false)}</td>
      <td style="width:74px">${exposureBar(b.net_pct, maxGross)}</td>
    </tr>`).join('');

  document.getElementById('rollup-body').innerHTML = `
    <div class="row mb-8">
      <div class="seg" id="seg-rollup">
        ${['level_1', 'level_2', 'level_3', 'level_4'].map((l, i) =>
          `<button data-rollup="${l}" aria-pressed="${i === 0}">L${i + 1}</button>`).join('')}
      </div>
    </div>
    <table class="grid"><thead><tr>
      <th>Bucket</th><th class="num">Net</th><th class="num">Gross</th><th></th>
    </tr></thead><tbody id="rollup-rows">${rollupRows(rollups.level_1 || [])}</tbody></table>`;

  document.querySelectorAll('#seg-rollup button').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#seg-rollup button').forEach((b) => b.setAttribute('aria-pressed', 'false'));
      btn.setAttribute('aria-pressed', 'true');
      document.getElementById('rollup-rows').innerHTML = rollupRows(rollups[btn.dataset.rollup] || []);
    });
  });

  const fiRows = v.rows.filter((r) => r.level_1 === 'Fixed Income' && r.duration_contribution !== null);
  const fiBuckets = new Map();
  fiRows.forEach((r) => fiBuckets.set(r.level_2, (fiBuckets.get(r.level_2) || 0) + (r.duration_contribution || 0)));
  const durTotal = v.kpis.duration_target_years;
  document.getElementById('duration-body').innerHTML = `
    <div class="dl mb-8">
      <dt>FI duration target</dt><dd class="${signClass(durTotal)}">${yrs(durTotal, 3)} yrs</dd>
      <dt>Contributing rows</dt><dd>${fiRows.length}</dd>
      <dt>From proxy</dt><dd>${v.diagnostics.duration_from_proxy.length}</dd>
      <dt>Unavailable</dt><dd>${v.diagnostics.duration_unavailable.length}</dd>
    </div>
    <table class="grid"><thead><tr><th>Bucket</th><th class="num">Contribution</th></tr></thead>
    <tbody>${[...fiBuckets.entries()].sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]))
      .map(([k, val]) => `<tr><td>${escapeHtml(k)}</td><td class="num ${signClass(val)}">${yrs(val, 3)}</td></tr>`).join('')
      || '<tr><td colspan="2" class="faint">No fixed income exposure</td></tr>'}</tbody></table>
    <div class="small faint mt-8">Contribution = weight × modified duration. Yield-quoted contracts are excluded.</div>`;

  const volRows = v.rows.filter((r) => r.standalone_vol_pct !== null && !r.is_funding_offset)
    .sort((a, b) => (b.standalone_vol_pct || 0) - (a.standalone_vol_pct || 0));
  const volSum = volRows.reduce((s, r) => s + (r.standalone_vol_pct || 0), 0);
  document.getElementById('vol-body').innerHTML = `
    <div class="dl mb-8">
      <dt>Sum of standalone</dt><dd>${pct(volSum, 2, false)}</dd>
      <dt>Window</dt><dd>${isoDate(v.windows.positioning_start)} → ${isoDate(v.windows.positioning_end)}</dd>
      <dt>Rows covered</dt><dd>${volRows.length}</dd>
    </div>
    <table class="grid"><thead><tr><th>Instrument</th><th class="num">Inst vol</th><th class="num">S/A</th></tr></thead>
    <tbody>${volRows.slice(0, 12).map((r) => `<tr>
      <td title="${escapeHtml(r.vol_note || '')}">${escapeHtml(r.instrument_name)}</td>
      <td class="num">${pct(r.instrument_vol_pct, 1, false)}</td>
      <td class="num">${pct(r.standalone_vol_pct, 2, false)}</td></tr>`).join('')
      || '<tr><td colspan="3" class="faint">No volatility computed</td></tr>'}</tbody></table>
    <div class="small faint mt-8">
      Annualised realised vol of daily log returns. The sum is <strong>undiversified</strong> —
      an upper bound on portfolio vol, not an estimate of it.
    </div>`;

  const rec = v.diagnostics.reconciliation;
  document.getElementById('recon-body').innerHTML = `
    <div class="dl">
      <dt>Daily series</dt><dd class="${signClass(rec.daily_series_total)}">${pct(rec.daily_series_total, 4)}</dd>
      <dt>Realised</dt><dd class="${signClass(rec.realised)}">${pct(rec.realised, 4)}</dd>
      <dt>Unrealised</dt><dd class="${signClass(rec.unrealised)}">${pct(rec.unrealised, 4)}</dd>
      <dt>Lot total</dt><dd class="${signClass(rec.lot_total)}">${pct(rec.lot_total, 4)}</dd>
      <dt>Residual</dt><dd class="faint">${pct(rec.compounding_residual, 4)}</dd>
    </div>
    <div class="small faint mt-8">
      The residual is the compounding difference between a target-weight daily series and a
      from-entry lot measure. It is expected and grows with holding period and volatility.
      ${rec.clean ? '' : '<span class="neg">Unpriced instruments detected.</span>'}
    </div>`;
}

/* ==========================================================================
   Row detail
   ========================================================================== */
async function showDetail(ticker) {
  const row = state.view.rows.find((r) => r.ticker === ticker);
  if (!row) return;
  document.getElementById('detail-title').textContent = `${row.instrument_name} — ${row.ticker}`;
  document.getElementById('detail-body').innerHTML =
    '<div class="empty-state"><span class="spinner"></span> Loading lot history…</div>';
  openModal('detail-modal');

  let lots = [];
  try {
    lots = await get(`/api/portfolios/${encodeURIComponent(PORTFOLIO)}/lots?ticker=${encodeURIComponent(ticker)}`);
  } catch { /* the summary is still useful */ }

  document.getElementById('detail-body').innerHTML = `
    <div class="dl mb-8">
      <dt>Hierarchy</dt><dd>${escapeHtml([row.level_1, row.level_2, row.level_3, row.level_4].join(' › '))}</dd>
      <dt>Exchange</dt><dd>${escapeHtml(row.primary_exchange || '–')}</dd>
      <dt>Net weight</dt><dd class="${signClass(row.net_weight_pct)}">${pct(row.net_weight_pct)}</dd>
      <dt>Average entry</dt><dd>${num(row.avg_open_level, 4)}</dd>
      <dt>Latest level</dt><dd>${num(row.latest_level, 4)} <span class="faint small">as of ${isoDate(row.latest_level_date)}</span></dd>
      <dt>Realised</dt><dd class="${signClass(row.realised_pnl_pct)}">${pct(row.realised_pnl_pct, 4)}</dd>
      <dt>Unrealised</dt><dd class="${signClass(row.unrealised_pnl_pct)}">${pct(row.unrealised_pnl_pct, 4)}</dd>
      <dt>Duration</dt><dd>${row.duration_years === null ? '–' : num(row.duration_years, 3)}
        <span class="tag ${row.duration_source === 'direct' ? 'tag-direct' : row.duration_source === 'proxy' ? 'tag-proxy' : 'tag-na'}">${escapeHtml(row.duration_source || '')}</span></dd>
      <dt>Duration note</dt><dd class="small faint">${escapeHtml(row.duration_note || '–')}</dd>
      <dt>Instrument vol</dt><dd>${pct(row.instrument_vol_pct, 2, false)} <span class="faint small">${row.vol_observations} obs</span></dd>
      <dt>Vol note</dt><dd class="small faint">${escapeHtml(row.vol_note || '–')}</dd>
      <dt>Level sources</dt><dd>${(row.level_sources || []).map((s) => `<span class="tag">${escapeHtml(s)}</span>`).join(' ')}</dd>
    </div>
    <div class="panel-title mt-12 mb-8">Lot history</div>
    <table class="grid"><thead><tr>
      <th>Opened</th><th class="num">Level</th><th class="num">Size</th><th class="num">Remaining</th>
      <th>Closed</th><th class="num">Close</th><th class="num">Realised</th>
    </tr></thead><tbody>
      ${lots.length ? lots.map((l) => `<tr>
        <td>${isoDate(l.open_date)}</td>
        <td class="num">${num(l.open_level, 3)}</td>
        <td class="num ${signClass(l.open_weight_pct)}">${pct(l.open_weight_pct)}</td>
        <td class="num ${signClass(l.remaining_weight_pct)}">${pct(l.remaining_weight_pct)}</td>
        <td>${isoDate(l.close_date)}</td>
        <td class="num">${l.close_level ? num(l.close_level, 3) : '–'}</td>
        <td class="num ${signClass(l.realised_pnl_pct)}">${pct(l.realised_pnl_pct, 4)}</td>
      </tr>`).join('') : '<tr><td colspan="7" class="faint">No lots</td></tr>'}
    </tbody></table>`;
}

/* ==========================================================================
   Trade entry
   ========================================================================== */
let selectedInstrument = null;
let searchTimer = null;

function wireTradeEntry() {
  wireModal('trade-modal');
  wireModal('detail-modal');
  wireModal('columns-modal');

  document.getElementById('new-trade-btn').addEventListener('click', () => {
    if (!PORTFOLIO) { toast('Create a portfolio first', 'warn'); return; }
    selectedInstrument = null;
    ['tr-search', 'tr-weight', 'tr-level', 'tr-notes'].forEach((id) => {
      document.getElementById(id).value = '';
    });
    document.getElementById('tr-selected').textContent = 'No instrument selected.';
    document.getElementById('tr-adhoc').classList.add('hidden');
    document.getElementById('tr-level-meta').textContent = '';
    document.getElementById('tr-error').classList.add('hidden');
    document.getElementById('tr-date').value = document.getElementById('valuation-date').value || TODAY;
    openModal('trade-modal');
    setTimeout(() => document.getElementById('tr-search').focus(), 40);
  });

  const search = document.getElementById('tr-search');
  const results = document.getElementById('tr-results');

  search.addEventListener('input', () => {
    clearTimeout(searchTimer);
    const q = search.value.trim();
    if (q.length < 1) { results.hidden = true; return; }
    searchTimer = setTimeout(async () => {
      try {
        // MASTER ONLY. Bloomberg is not reachable from this box - anything
        // selected here is already classified, so a trade can never enter the
        // book against an unclassified instrument.
        const hits = await get(`/api/instruments/search?q=${encodeURIComponent(q)}&limit=20`);
        results.innerHTML = hits.length ? hits.map((h, i) => `
          <div class="search-item" data-idx="${i}">
            <span class="si-ticker">${escapeHtml(h.bbg_ticker)}</span>
            <span class="si-name">${escapeHtml(h.instrument_name)}</span>
            <span class="si-hier">${escapeHtml(h.level_1)} \u203a ${escapeHtml(h.level_3)}</span>
          </div>`).join('')
          : `<div class="search-item" data-adhoc="1">
               <span class="si-name">Not in the instrument master —
                 <strong>add \u201c${escapeHtml(q)}\u201d</strong></span>
               <span class="si-hier">search Bloomberg and classify it</span>
             </div>`;
        results.querySelectorAll('.search-item[data-idx]').forEach((el) => {
          el.addEventListener('click', () => selectInstrument(hits[Number(el.dataset.idx)]));
        });
        const adhocRow = results.querySelector('.search-item[data-adhoc]');
        if (adhocRow) adhocRow.addEventListener('click', () => openAdhoc('', '', q));
        results.hidden = false;
      } catch { results.hidden = true; }
    }, 160);
  });

  document.addEventListener('click', (e) => {
    if (!e.target.closest('.search-wrap')) results.hidden = true;
  });

  document.getElementById('tr-adhoc-toggle').addEventListener('click', () => {
    const panel = document.getElementById('tr-adhoc');
    // Seed the Bloomberg box with whatever they were looking for, not the
    // ticker field - they searched by name and it was not in the master.
    if (panel.classList.contains('hidden')) openAdhoc('', '', document.getElementById('tr-search').value.trim());
    else panel.classList.add('hidden');
  });
  document.getElementById('ad-save').addEventListener('click', saveAdhoc);

  const lookupInput = document.getElementById('ad-lookup');
  lookupInput.addEventListener('input', () => {
    clearTimeout(lookupTimer);
    lookupTimer = setTimeout(runLookup, 250);
  });
  lookupInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); clearTimeout(lookupTimer); runLookup(); }
  });

  document.getElementById('tr-exec').addEventListener('change', onExecChange);
  document.getElementById('tr-date').addEventListener('change', refreshLevel);
  document.getElementById('tr-save').addEventListener('click', saveTrade);
}

/* --- manual instrument entry --------------------------------------------
   The seeded taxonomy will never contain everything anyone wants to trade.
   Rather than dead-ending the user, let them supply the Bloomberg ticker,
   validate it server-side, and add it to the master so hierarchy rollups,
   duration and volatility all work for it from then on.

   Deliberately NOT a third-party lookup service: sending instrument
   identifiers from an internal book to an external API is a data-governance
   problem, and no free source uses Bloomberg's ticker conventions anyway, so
   the result would still need retyping. Bloomberg's own search plus manual
   entry covers the case properly. */
let hierarchyLevels = null;

async function loadHierarchyLevels() {
  if (hierarchyLevels) return hierarchyLevels;
  try {
    const data = await get('/api/instruments/hierarchy');
    hierarchyLevels = data.levels || {};
  } catch { hierarchyLevels = {}; }
  [['dl-l1', 'level_1'], ['dl-l2', 'level_2'], ['dl-l3', 'level_3'], ['dl-l4', 'level_4']]
    .forEach(([id, key]) => {
      const el = document.getElementById(id);
      if (el) {
        el.innerHTML = (hierarchyLevels[key] || [])
          .map((v) => `<option value="${escapeHtml(v)}"></option>`).join('');
      }
    });
  return hierarchyLevels;
}

function openAdhoc(ticker = '', name = '', lookupSeed = '') {
  document.getElementById('tr-results').hidden = true;
  const panel = document.getElementById('tr-adhoc');
  panel.classList.remove('hidden');
  document.getElementById('ad-ticker').value = ticker;
  document.getElementById('ad-name').value = name || '';
  ['ad-l1', 'ad-l2', 'ad-l3', 'ad-l4'].forEach((id) => { document.getElementById(id).value = ''; });
  document.getElementById('ad-msg').innerHTML = '';
  document.getElementById('ad-suggest').innerHTML = '';
  document.getElementById('ad-lookup-msg').textContent = '';
  document.getElementById('ad-lookup-results').hidden = true;
  const lookup = document.getElementById('ad-lookup');
  lookup.value = lookupSeed || '';
  loadHierarchyLevels();
  if (lookupSeed) runLookup();
  setTimeout(() => lookup.focus(), 40);
}

/* Bloomberg security search. This is the ONLY place in the app that reaches
   //blp/instruments - trade entry itself never does, so the taxonomy stays the
   single source of truth for anything that can be traded. */
let lookupTimer = null;

async function runLookup() {
  const q = document.getElementById('ad-lookup').value.trim();
  const box = document.getElementById('ad-lookup-results');
  const msg = document.getElementById('ad-lookup-msg');
  if (q.length < 2) { box.hidden = true; msg.textContent = ''; return; }
  msg.innerHTML = '<span class="spinner"></span> Searching Bloomberg…';
  try {
    const data = await get(`/api/instruments/lookup?q=${encodeURIComponent(q)}&limit=15`);
    const rows = data.results || [];
    msg.textContent = data.detail || (rows.length ? '' : 'Bloomberg returned no matches.');
    if (!rows.length) { box.hidden = true; return; }
    box.innerHTML = rows.map((r, i) => `
      <div class="search-item${r.already_in_master ? ' is-disabled' : ''}" data-idx="${i}">
        <span class="si-ticker">${escapeHtml(r.bbg_ticker)}</span>
        <span class="si-name">${escapeHtml(r.instrument_name || '')}</span>
        <span class="si-hier">${r.already_in_master
          ? 'already in your master'
          : (r.suggested ? `suggests ${escapeHtml(r.suggested.level_1)} \u203a ${escapeHtml(r.suggested.level_3)}`
                         : 'needs classification')}</span>
      </div>`).join('');
    box.querySelectorAll('.search-item').forEach((el) => {
      el.addEventListener('click', () => applyLookup(rows[Number(el.dataset.idx)]));
    });
    box.hidden = false;
  } catch (e) {
    msg.innerHTML = `<span class="neg">${escapeHtml(e.message)}</span>`;
    box.hidden = true;
  }
}

/* Fill the form from a Bloomberg hit. The suggestion comes from the closest
   instrument already in YOUR master, never from a Bloomberg taxonomy - and it
   is only ever a prefill. The server still rejects the record if any level is
   left blank or set to a placeholder. */
function applyLookup(hit) {
  if (!hit || hit.already_in_master) {
    toast(`${hit ? hit.bbg_ticker : 'That instrument'} is already in the master — search for it above`, 'warn');
    return;
  }
  document.getElementById('ad-lookup-results').hidden = true;
  document.getElementById('ad-ticker').value = hit.bbg_ticker;
  document.getElementById('ad-name').value = hit.instrument_name || '';
  const s = hit.suggested;
  const note = document.getElementById('ad-suggest');
  if (s) {
    [['ad-l1', 'level_1'], ['ad-l2', 'level_2'], ['ad-l3', 'level_3'], ['ad-l4', 'level_4']]
      .forEach(([id, key]) => { document.getElementById(id).value = s[key] || ''; });
    note.innerHTML = `Prefilled from the ${escapeHtml(s.basis)}. `
      + `<strong>Check every level before saving</strong> — this classification is permanent.`;
  } else {
    note.innerHTML = 'No comparable instrument in your master, so nothing was prefilled. '
      + 'All four levels are required.';
  }
}

async function saveAdhoc() {
  const msg = document.getElementById('ad-msg');
  const btn = document.getElementById('ad-save');
  const val = (id) => document.getElementById(id).value.trim();
  if (!val('ad-ticker')) {
    msg.innerHTML = '<span class="neg">A Bloomberg ticker is required.</span>';
    return;
  }
  const missing = [['ad-l1', 'Level 1'], ['ad-l2', 'Level 2'], ['ad-l3', 'Level 3'], ['ad-l4', 'Level 4']]
    .filter(([id]) => !val(id)).map(([, label]) => label);
  if (missing.length) {
    msg.innerHTML = `<span class="neg">${missing.join(', ')} required. `
      + 'An unclassified instrument drops out of every rollup.</span>';
    return;
  }
  btn.disabled = true;
  msg.innerHTML = '<span class="spinner"></span> Validating…';
  try {
    const created = await post('/api/instruments/adhoc', {
      bbg_ticker: val('ad-ticker'),
      instrument_name: val('ad-name') || null,
      level_1: val('ad-l1'),
      level_2: val('ad-l2'),
      level_3: val('ad-l3'),
      level_4: val('ad-l4'),
    });
    const tag = created.validation_status === 'validated'
      ? '<span class="tag tag-direct">validated</span>'
      : '<span class="tag tag-fallback">unvalidated</span>';
    msg.innerHTML = `${tag} ${escapeHtml((created.messages || []).join(' '))}`;
    toast(`Added ${created.bbg_ticker} to the instrument master`, 'ok');
    hierarchyLevels = null;             // new buckets may now exist
    document.getElementById('tr-adhoc').classList.add('hidden');
    selectInstrument(created);
  } catch (e) {
    msg.innerHTML = `<span class="neg">${escapeHtml(e.message)}</span>`;
  } finally {
    btn.disabled = false;
  }
}

function selectInstrument(hit) {
  selectedInstrument = hit;
  document.getElementById('tr-search').value = `${hit.bbg_ticker} — ${hit.instrument_name}`;
  document.getElementById('tr-results').hidden = true;
  document.getElementById('tr-selected').innerHTML =
    `<span class="mono">${escapeHtml(hit.bbg_ticker)}</span> · ` +
    `${escapeHtml(hit.level_1)} › ${escapeHtml(hit.level_2)} › ${escapeHtml(hit.level_3)} › ${escapeHtml(hit.level_4)}` +
    (hit.primary_exchange ? ` · ${escapeHtml(hit.primary_exchange)}` : '');
  refreshLevel();
}

function onExecChange() {
  const exec = document.getElementById('tr-exec').value;
  const levelInput = document.getElementById('tr-level');
  if (exec === 'Custom') {
    levelInput.disabled = false;
    levelInput.placeholder = 'Required';
    levelInput.focus();
    document.getElementById('tr-level-meta').textContent = 'Manual level — will be tagged as such.';
  } else {
    levelInput.disabled = true;
    levelInput.placeholder = 'Bloomberg will populate';
    refreshLevel();
  }
}

async function refreshLevel() {
  const exec = document.getElementById('tr-exec').value;
  if (exec === 'Custom' || !selectedInstrument) return;
  const meta = document.getElementById('tr-level-meta');
  const spinner = document.getElementById('tr-level-spinner');
  spinner.classList.remove('hidden');
  meta.textContent = 'Resolving…';
  try {
    const res = await post(`/api/portfolios/${encodeURIComponent(PORTFOLIO)}/level-preview`, {
      bbg_ticker: selectedInstrument.bbg_ticker,
      trade_date: document.getElementById('tr-date').value,
      execution_time: exec,
    });
    document.getElementById('tr-level').value = res.level === null ? '' : res.level;

    const liveTag = res.from_live_request
      ? '<span class="tag tag-direct" title="Requested from Bloomberg as part of this lookup">live</span> '
      : (res.live_provider
        ? '<span class="tag tag-na" title="Served from the local price cache — this date is settled history">cached</span> '
        : '<span class="tag tag-fallback" title="No live Bloomberg session; synthetic provider in use">synthetic</span> ');

    if (!res.ok) {
      meta.innerHTML = `<span class="neg">${escapeHtml(res.reason || 'No level available')}</span>`;
    } else if (res.is_stale) {
      meta.innerHTML = `${liveTag}<span class="tag tag-fallback">stale ${res.fallback_days}d</span> ` +
        `${escapeHtml(res.field_used || '')} from ${isoDate(res.observation_date)} — ${escapeHtml(res.reason || '')}`;
    } else {
      meta.innerHTML = `${liveTag}<span class="tag tag-bbg">${escapeHtml(res.field_used || 'bloomberg')}</span> ` +
        `official print ${isoDate(res.observation_date)}`;
    }
  } catch (e) {
    meta.innerHTML = `<span class="neg">${escapeHtml(e.message)}</span>`;
  } finally {
    spinner.classList.add('hidden');
  }
}

async function saveTrade() {
  const err = document.getElementById('tr-error');
  err.classList.add('hidden');
  if (!selectedInstrument) { err.textContent = 'Select an instrument.'; err.classList.remove('hidden'); return; }
  const exec = document.getElementById('tr-exec').value;
  const payload = {
    bbg_ticker: selectedInstrument.bbg_ticker,
    trade_date: document.getElementById('tr-date').value,
    notional_weight_pct: document.getElementById('tr-weight').value,
    execution_time: exec,
    level: exec === 'Custom' ? parseFloat(document.getElementById('tr-level').value) : null,
    notes: document.getElementById('tr-notes').value.trim() || null,
  };
  const btn = document.getElementById('tr-save');
  btn.disabled = true;
  try {
    const created = await post(`/api/portfolios/${encodeURIComponent(PORTFOLIO)}/trades`, payload);
    closeModal('trade-modal');
    toast(`Booked ${pct(created.weight_delta_pct)} ${created.bbg_ticker} @ ${num(created.execution_level, 3)}`, 'ok');
    await load();
  } catch (e) {
    err.textContent = e.message;
    err.classList.remove('hidden');
  } finally {
    btn.disabled = false;
  }
}

/* ==========================================================================
   Snapshots
   ========================================================================== */
async function loadSnapshots() {
  if (!PORTFOLIO) return;
  let snaps = [];
  try { snaps = await get(`/api/portfolios/${encodeURIComponent(PORTFOLIO)}/snapshots`); } catch { return; }
  const sel = document.getElementById('snapshot-select');
  sel.innerHTML = '<option value="">— none selected —</option>' + snaps.map((s) =>
    `<option value="${s.id}">${isoDate(s.snapshot_date)} · ${escapeHtml(s.label || '')}${s.is_current ? ' (current)' : ''}${s.superseded_by_id ? ' [superseded]' : ''}</option>`
  ).join('');
  sel.addEventListener('change', async () => {
    const box = document.getElementById('snapshot-body');
    if (!sel.value) {
      box.innerHTML = '<div class="empty-state">Select a snapshot to compare it against current positioning.</div>';
      return;
    }
    box.innerHTML = '<div class="empty-state"><span class="spinner"></span> Loading…</div>';
    const snap = await get(`/api/snapshots/${sel.value}`);
    const live = new Map(state.view.rows.map((r) => [r.ticker, r.net_weight_pct]));
    const rows = snap.rows.map((r) => {
      const cur = live.get(r.ticker) || 0;
      const diff = cur - r.net_weight_pct;
      return `<tr class="${r.is_funding_offset ? 'offset-row' : ''}">
        <td>${escapeHtml(r.instrument_name)}</td>
        <td class="mono">${escapeHtml(r.ticker)}</td>
        <td>${escapeHtml(r.level_1)}</td>
        <td class="num ${signClass(r.net_weight_pct)}">${pct(r.net_weight_pct)}</td>
        <td class="num ${signClass(cur)}">${pct(cur)}</td>
        <td class="num ${signClass(diff)}">${pct(diff)}</td></tr>`;
    }).join('');
    box.innerHTML = `<div class="table-wrap"><table class="grid"><thead><tr>
      <th>Instrument</th><th>Ticker</th><th>L1</th>
      <th class="num">Target</th><th class="num">Live</th><th class="num">Difference</th>
    </tr></thead><tbody>${rows}</tbody></table></div>
    <div class="panel-body small faint">Target net ${pct(snap.totals.net_pct)} · gross ${pct(snap.totals.gross_pct, 2, false)} ·
      snapshot dated ${isoDate(snap.snapshot_date)}. “Difference” is live minus target.</div>`;
  });
}

/* ==========================================================================
   Controls
   ========================================================================== */
function wireControls() {
  // Single-choice segmented controls.
  [['seg-basis', 'basis', 'basis'], ['seg-density', 'density', 'density'],
   ['seg-window', 'window', 'windowKey']].forEach(([id, attr, key]) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.querySelectorAll('button').forEach((btn) => {
      btn.addEventListener('click', () => {
        el.querySelectorAll('button').forEach((b) => b.setAttribute('aria-pressed', 'false'));
        btn.setAttribute('aria-pressed', 'true');
        state[key] = btn.dataset[attr];
        ui.set(key, state[key]);
        if (key === 'density') { document.body.setAttribute('data-density', state.density); return; }
        if (key === 'windowKey') {
          document.getElementById('custom-window').classList.toggle('hidden', state.windowKey !== 'custom');
          load();
          return;
        }
        renderGrid();
      });
    });
    el.querySelectorAll('button').forEach((b) =>
      b.setAttribute('aria-pressed', String(b.dataset[attr] === state[key])));
  });

  // Group-by is MULTI-select: any combination of L1-L4, always nested in
  // hierarchy order so "L1 + L3" reads top-down the way the taxonomy does.
  const groupSeg = document.getElementById('seg-group');
  groupSeg.querySelectorAll('button').forEach((btn) => {
    btn.addEventListener('click', () => {
      const level = btn.dataset.group;
      if (level === 'none') {
        state.groupBy = [];
      } else if (state.groupBy.includes(level)) {
        state.groupBy = state.groupBy.filter((g) => g !== level);
      } else {
        state.groupBy = GROUP_LEVELS.filter((l) => l === level || state.groupBy.includes(l));
      }
      ui.set('groupBy', state.groupBy);
      paintGroupButtons();
      renderGrid();
    });
  });
  paintGroupButtons();

  const checks = [
    ['opt-offset', 'showOffset', renderGrid],
    ['opt-inactive', 'includeInactive', load],
    ['opt-subtotals', 'showSubtotals', renderGrid],
  ];
  checks.forEach(([id, key, after]) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.checked = state[key];
    el.addEventListener('change', () => {
      state[key] = el.checked;
      ui.set(key, el.checked);
      after();
    });
  });

  document.getElementById('filter-text').addEventListener('input', (e) => {
    state.filter = e.target.value.trim();
    renderGrid();
  });

  ['window-start', 'window-end'].forEach((id) =>
    document.getElementById(id).addEventListener('change', load));

  document.getElementById('toggle-drawer').addEventListener('click', () => {
    document.getElementById('drawer').classList.toggle('collapsed');
  });

  document.getElementById('export-csv').addEventListener('click', exportCsv);

  document.getElementById('columns-btn').addEventListener('click', () => {
    renderColumnChooser();
    openModal('columns-modal');
  });
  document.querySelectorAll('#seg-preset button').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.columns = PRESETS[btn.dataset.preset].slice();
      persistColumns();
    });
  });
  document.getElementById('col-reset').addEventListener('click', () => {
    state.columns = PRESETS.basic.slice();
    persistColumns();
  });

  document.addEventListener('ppt:valuation-changed', load);
  document.body.setAttribute('data-density', state.density || 'compact');
  document.getElementById('custom-window').classList.toggle('hidden', state.windowKey !== 'custom');
  initDatePickers();
}

function paintGroupButtons() {
  const seg = document.getElementById('seg-group');
  seg.querySelectorAll('button').forEach((b) => {
    const level = b.dataset.group;
    const on = level === 'none' ? state.groupBy.length === 0 : state.groupBy.includes(level);
    b.setAttribute('aria-pressed', String(on));
  });
}

function exportCsv() {
  const cols = visibleColumns();
  const rows = visibleRows();
  const header = cols.map((c) => c.label).join(',');
  const lines = rows.map((r) => cols.map((c) => {
    let v = cellValueOf(r, c.key);
    if (c.key === 'exec') v = (r.execution_types || []).join(' ');
    if (v === null || v === undefined) v = '';
    const s = String(v).replace(/"/g, '""');
    return /[,"\n]/.test(s) ? `"${s}"` : s;
  }).join(',')).join('\n');
  const blob = new Blob([`${header}\n${lines}\n`], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `${PORTFOLIO}_positions_${document.getElementById('valuation-date').value}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
}

wireControls();
wireTradeEntry();
load().then(loadSnapshots);
