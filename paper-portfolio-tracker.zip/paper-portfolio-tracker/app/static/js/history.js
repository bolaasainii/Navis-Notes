import {
  get, post, pct, num, isoDate, signClass, escapeHtml, toast,
  openModal, closeModal, wireModal, currentPortfolio, ui, initDatePickers,
} from './core.js';

const PORTFOLIO = currentPortfolio();
let trades = [];
let filter = '';
let showOffset = ui.get('histShowOffset', false);
let voidTarget = null;
let editTarget = null;

wireModal('void-modal');
wireModal('edit-modal');
initDatePickers();

async function load() {
  if (!PORTFOLIO) return;
  const wrap = document.getElementById('hist-wrap');
  wrap.innerHTML = '<div class="empty-state"><span class="spinner"></span> Loading…</div>';
  trades = await get(`/api/portfolios/${encodeURIComponent(PORTFOLIO)}/trades?include_offset=${showOffset}`);
  render();
  loadAudit();
}

function render() {
  const rows = trades.filter((t) => {
    if (!filter) return true;
    const f = filter.toLowerCase();
    return [t.bbg_ticker, t.instrument_name, t.notes, t.execution_type, t.source, t.level_1, t.level_3]
      .filter(Boolean).some((v) => String(v).toLowerCase().includes(f));
  });

  if (!rows.length) {
    document.getElementById('hist-wrap').innerHTML =
      '<div class="empty-state"><strong>No trades</strong>Book one from the Positions tab, or import a history file.</div>';
    return;
  }

  document.getElementById('hist-wrap').innerHTML = `
    <table class="grid"><thead><tr>
      <th class="sticky-1" style="min-width:96px">Date</th>
      <th style="min-width:180px">Instrument</th>
      <th class="mono">Ticker</th>
      <th>L1</th><th>L3</th>
      <th class="num">Weight</th>
      <th>Execution</th>
      <th class="num">Level</th>
      <th>Level source</th>
      <th class="num">Stale</th>
      <th>Origin</th>
      <th style="min-width:180px">Notes</th>
      <th></th>
    </tr></thead><tbody>
      ${rows.map(rowHtml).join('')}
    </tbody></table>`;

  document.querySelectorAll('[data-edit-id]').forEach((btn) =>
    btn.addEventListener('click', () => openEdit(trades.find((t) => t.id === Number(btn.dataset.editId)))));

  document.querySelectorAll('[data-restore-id]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      try {
        await post(`/api/trades/${btn.dataset.restoreId}/restore`, {});
        toast('Trade restored; book recalculated', 'ok');
        await load();
      } catch (e) { toast(e.message, 'err'); btn.disabled = false; }
    }));

  document.querySelectorAll('[data-void-id]').forEach((btn) =>
    btn.addEventListener('click', () => {
      voidTarget = trades.find((t) => t.id === Number(btn.dataset.voidId));
      document.getElementById('void-summary').textContent =
        `${voidTarget.trade_date} · ${voidTarget.bbg_ticker} · ${pct(voidTarget.weight_delta_pct)} @ ${num(voidTarget.execution_level, 3)}`;
      document.getElementById('void-reason').value = '';
      document.getElementById('void-error').classList.add('hidden');
      openModal('void-modal');
    }));
}

function levelSourceTag(t) {
  const map = {
    bloomberg: ['tag-bbg', 'bloomberg'],
    bloomberg_fallback: ['tag-fallback', 'fallback'],
    manual: ['tag-manual', 'manual'],
    imported: ['tag-manual', 'imported'],
    synthetic: ['tag-synthetic', 'synthetic'],
  };
  const [cls, label] = map[t.level_source] || ['tag-na', t.level_source];
  const title = t.price_fallback_reason || `${t.price_field_used || ''} observed ${t.price_observation_date || ''}`;
  // Whether the level was obtained from a Bloomberg request at booking time or
  // from settled cached history. Both are legitimate; the point is that the
  // record says which.
  const live = t.price_from_live_request
    ? ' <span class="tag tag-direct" title="Priced from a Bloomberg request issued when this trade was booked">live</span>'
    : (t.price_provider && t.price_provider !== 'blpapi'
      ? ` <span class="tag tag-fallback" title="Priced by the ${escapeHtml(t.price_provider)} provider">${escapeHtml(t.price_provider)}</span>`
      : '');
  return `<span class="tag ${cls}" title="${escapeHtml(title)}">${escapeHtml(label)}</span>${live}`;
}

function rowHtml(t) {
  const cls = [];
  if (t.is_funding_offset) cls.push('offset-row');
  if (t.is_void) cls.push('inactive-row');
  return `<tr class="${cls.join(' ')}">
    <td class="sticky-1">${isoDate(t.trade_date)}</td>
    <td title="${escapeHtml(t.instrument_name)}">${escapeHtml(t.instrument_name)}${t.is_void ? ' <span class="tag tag-manual">void</span>' : ''}</td>
    <td class="mono">${escapeHtml(t.bbg_ticker)}</td>
    <td>${escapeHtml(t.level_1)}</td>
    <td>${escapeHtml(t.level_3)}</td>
    <td class="num ${signClass(t.weight_delta_pct)}">${pct(t.weight_delta_pct)}</td>
    <td>${escapeHtml(t.execution_type)}</td>
    <td class="num">${num(t.execution_level, 3)}</td>
    <td>${levelSourceTag(t)}</td>
    <td class="num ${t.price_fallback_days ? 'neg' : 'zero'}">${t.price_fallback_days || '–'}</td>
    <td class="small faint">${escapeHtml(t.source)}</td>
    <td class="small faint" title="${escapeHtml(t.notes || '')}">${escapeHtml(t.notes || '')}</td>
    <td class="nowrap">${actionsHtml(t)}</td>
  </tr>`;
}

/* The funding sleeve is derived, never edited by hand. A voided trade can be
   restored but not edited - "should not have been booked" and "was booked
   wrongly" are different claims and the audit log should not merge them. */
function actionsHtml(t) {
  if (t.is_funding_offset) return '';
  if (t.is_void) return `<button class="btn btn-sm" data-restore-id="${t.id}">Restore</button>`;
  return `<button class="btn btn-sm" data-edit-id="${t.id}">Edit</button>
          <button class="btn btn-sm btn-danger" data-void-id="${t.id}">Void</button>`;
}

function openEdit(t) {
  editTarget = t;
  document.getElementById('edit-summary').innerHTML =
    `<span class="mono">${escapeHtml(t.bbg_ticker)}</span> — ${escapeHtml(t.instrument_name)}`
    + `<br>Booked ${isoDate(t.trade_date)} · ${pct(t.weight_delta_pct)} @ ${num(t.execution_level, 3)}`
    + ` (${escapeHtml(t.execution_type)})`;
  document.getElementById('ed-date').value = isoDate(t.trade_date);
  document.getElementById('ed-weight').value = t.weight_delta_pct;
  document.getElementById('ed-exec').value = t.execution_type;
  document.getElementById('ed-level').value = t.execution_type === 'Custom' ? t.execution_level : '';
  document.getElementById('ed-notes').value = t.notes || '';
  document.getElementById('ed-reason').value = '';
  document.getElementById('edit-error').classList.add('hidden');
  syncEditLevel();
  openModal('edit-modal');
}

/* A level is only user-supplied for a Custom execution. For Mkt Open/Close it
   is Bloomberg's to determine, so the field is disabled rather than pre-filled
   with a number the user might think they can override. */
function syncEditLevel() {
  const custom = document.getElementById('ed-exec').value === 'Custom';
  const level = document.getElementById('ed-level');
  level.disabled = !custom;
  level.placeholder = custom ? 'Required for a Custom execution' : 'Re-resolved from Bloomberg';
  if (!custom) level.value = '';
}

document.getElementById('ed-exec').addEventListener('change', syncEditLevel);

document.getElementById('edit-confirm').addEventListener('click', async () => {
  const err = document.getElementById('edit-error');
  const btn = document.getElementById('edit-confirm');
  const v = (id) => document.getElementById(id).value.trim();
  const exec = v('ed-exec');
  if (exec === 'Custom' && !v('ed-level')) {
    err.textContent = 'A Custom execution requires a level.';
    err.classList.remove('hidden');
    return;
  }
  if (!v('ed-weight')) {
    err.textContent = 'A notional weight is required.';
    err.classList.remove('hidden');
    return;
  }
  btn.disabled = true;
  try {
    const res = await post(`/api/trades/${editTarget.id}/edit`, {
      trade_date: v('ed-date') || null,
      notional_weight_pct: v('ed-weight'),
      execution_time: exec,
      level: v('ed-level') ? Number(v('ed-level')) : null,
      notes: v('ed-notes'),
      reason: v('ed-reason') || null,
    });
    closeModal('edit-modal');
    toast((res.messages && res.messages[0]) || 'Trade amended; book recalculated', 'ok');
    await load();
  } catch (e) {
    err.textContent = e.message;
    err.classList.remove('hidden');
  } finally {
    btn.disabled = false;
  }
});

async function loadAudit() {
  const rows = await get(`/api/portfolios/${encodeURIComponent(PORTFOLIO)}/audit?limit=250`);
  document.getElementById('audit-wrap').innerHTML = rows.length ? `
    <table class="grid"><thead><tr>
      <th style="min-width:150px">When</th><th>Category</th><th>Action</th>
      <th class="mono">Ticker</th><th style="min-width:420px">Summary</th><th>Actor</th>
    </tr></thead><tbody>
      ${rows.map((a) => `<tr>
        <td class="small">${escapeHtml(String(a.event_time).replace('T', ' ').slice(0, 19))}</td>
        <td><span class="tag">${escapeHtml(a.category)}</span></td>
        <td class="small">${escapeHtml(a.action)}</td>
        <td class="mono">${escapeHtml(a.bbg_ticker || '')}</td>
        <td class="small">${escapeHtml(a.summary)}</td>
        <td class="small faint">${escapeHtml(a.actor || '')}</td>
      </tr>`).join('')}
    </tbody></table>` : '<div class="empty-state">No audit entries yet.</div>';
}

document.getElementById('void-confirm').addEventListener('click', async () => {
  const reason = document.getElementById('void-reason').value.trim();
  const err = document.getElementById('void-error');
  if (!reason) { err.textContent = 'A reason is required.'; err.classList.remove('hidden'); return; }
  try {
    await post(`/api/trades/${voidTarget.id}/void`, { reason });
    closeModal('void-modal');
    toast('Trade voided; book recalculated', 'ok');
    load();
  } catch (e) {
    err.textContent = e.message;
    err.classList.remove('hidden');
  }
});

const offsetToggle = document.getElementById('opt-show-offset');
offsetToggle.checked = showOffset;
offsetToggle.addEventListener('change', () => {
  showOffset = offsetToggle.checked;
  ui.set('histShowOffset', showOffset);
  load();
});

document.getElementById('hist-filter').addEventListener('input', (e) => {
  filter = e.target.value.trim();
  render();
});

document.getElementById('hist-export').addEventListener('click', () => {
  const header = 'portfolio_id,bbg_ticker,notional_weight_pct,trade_date,execution_time,level,notes';
  const lines = trades.filter((t) => !t.is_funding_offset && !t.is_void).map((t) =>
    [PORTFOLIO, t.bbg_ticker, t.weight_delta_pct, isoDate(t.trade_date), t.execution_type,
      t.execution_type === 'Custom' ? t.execution_level : '', (t.notes || '').replace(/,/g, ';')].join(','));
  const blob = new Blob([`${header}\n${lines.join('\n')}\n`], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `${PORTFOLIO}_trade_history.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
});

load();
