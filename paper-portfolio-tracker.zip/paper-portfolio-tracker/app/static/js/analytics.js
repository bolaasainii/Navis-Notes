import {
  get, pct, num, yrs, isoDate, signClass, escapeHtml, currentPortfolio, exposureBar,
} from './core.js';

const PORTFOLIO = currentPortfolio();
const body = document.body;
let view = null;
let metric = 'net_pct';
let volMode = 'compact';
const collapsed = new Set();

function defaultWindow() {
  const v = document.getElementById('valuation-date').value || body.dataset.today;
  const d = new Date(v + 'T00:00:00');
  return [new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10), v];
}

async function load() {
  if (!PORTFOLIO) return;
  const [ds, de] = defaultWindow();
  const start = document.getElementById('an-start').value || ds;
  const end = document.getElementById('an-end').value || de;
  document.getElementById('an-start').value = start;
  document.getElementById('an-end').value = end;

  const params = new URLSearchParams({
    valuation_date: document.getElementById('valuation-date').value || body.dataset.today,
    window_start: start,
    window_end: end,
    vol_lookback_days: document.getElementById('an-lookback').value || '',
  });
  view = await get(`/api/portfolios/${encodeURIComponent(PORTFOLIO)}/positions?${params}`);
  renderTree();
  renderAssets();
  renderDuration();
  renderVol();
}

const METRIC_FMT = {
  net_pct: (v) => pct(v, 2),
  gross_pct: (v) => pct(v, 2, false),
  long_pct: (v) => pct(v, 2),
  short_pct: (v) => pct(v, 2),
  duration_contribution: (v) => yrs(v, 3),
  standalone_vol_pct: (v) => pct(v, 2, false),
};

/* Canonical asset-class order, mirroring the server and the positions grid. */
const ASSET_CLASS_ORDER = ['Equity', 'Fixed Income', 'FX', 'Cash & Funding'];

function renderTree() {
  const tree = view.hierarchy_rollup;
  const maxAbs = Math.max(...tree.map((b) => Math.abs(b[metric] || 0)), 0.01);
  let html = '';

  const walk = (bucket, depth, path) => {
    const key = `${path}/${bucket.key}`;
    const hasKids = bucket.children && bucket.children.length && depth < 3;
    const open = !collapsed.has(key);
    const v = bucket[metric] || 0;
    html += `<tr data-key="${escapeHtml(key)}" class="${depth === 0 ? 'group-row' : ''}">
      <td style="padding-left:${8 + depth * 16}px">
        ${hasKids ? `<button class="expand-btn">${open ? '▾' : '▸'}</button>` : '<span style="display:inline-block;width:13px"></span>'}
        ${escapeHtml(bucket.label)}
      </td>
      <td class="num faint">${bucket.row_count}</td>
      <td class="num ${signClass(v)}">${METRIC_FMT[metric](v)}</td>
      <td style="width:110px">${exposureBar(v, maxAbs)}</td>
      <td class="num ${signClass(bucket.net_pct)}">${pct(bucket.net_pct, 2)}</td>
      <td class="num">${pct(bucket.gross_pct, 2, false)}</td>
      <td class="num ${signClass(bucket.long_pct)}">${pct(bucket.long_pct, 2)}</td>
      <td class="num ${signClass(bucket.short_pct)}">${pct(bucket.short_pct, 2)}</td>
      <td class="num ${signClass(bucket.duration_contribution)}">${yrs(bucket.duration_contribution, 3)}</td>
      <td class="num">${pct(bucket.standalone_vol_pct, 2, false)}</td>
    </tr>`;
    if (hasKids && open) bucket.children.forEach((c) => walk(c, depth + 1, key));
  };

  tree.forEach((b) => walk(b, 0, ''));

  const t = view.totals;
  const totalRow = `
      <tr class="total-row total-top">
        <td>Total (ex funding)</td><td class="num">${t.row_count}</td>
        <td class="num ${signClass(t.net_pct)}">${METRIC_FMT[metric](
          metric === 'duration_contribution' ? t.duration_contribution
          : metric === 'standalone_vol_pct' ? t.sum_of_standalone_vol_pct
          : t[metric])}</td><td></td>
        <td class="num ${signClass(t.net_pct)}">${pct(t.net_pct, 2)}</td>
        <td class="num">${pct(t.gross_pct, 2, false)}</td>
        <td class="num pos">${pct(t.long_pct, 2)}</td>
        <td class="num neg">${pct(t.short_pct, 2)}</td>
        <td class="num ${signClass(t.duration_contribution)}">${yrs(t.duration_contribution, 3)}</td>
        <td class="num">${pct(t.sum_of_standalone_vol_pct, 2, false)}</td>
      </tr>`;

  // Total leads the table - it is the number read most often.
  document.getElementById('tree-wrap').innerHTML = `
    <table class="grid"><thead><tr>
      <th style="min-width:260px">Bucket</th><th class="num">Rows</th>
      <th class="num">${escapeHtml(metric.replace(/_/g, ' '))}</th><th></th>
      <th class="num">Net</th><th class="num">Gross</th><th class="num">Long</th><th class="num">Short</th>
      <th class="num">Duration</th><th class="num">S/A vol</th>
    </tr></thead><tbody>${totalRow}${html}</tbody></table>`;

  document.querySelectorAll('#tree-wrap tr[data-key]').forEach((tr) =>
    tr.addEventListener('click', () => {
      const k = tr.dataset.key;
      if (collapsed.has(k)) collapsed.delete(k); else collapsed.add(k);
      renderTree();
    }));
}

function renderAssets() {
  const k = view.kpis;
  const t = view.totals;
  // Canonical order, total first.
  const groups = [['Equity', k.equity], ['Fixed Income', k.fixed_income], ['FX', k.fx]];
  document.getElementById('asset-wrap').innerHTML = `
    <table class="grid"><thead><tr>
      <th style="min-width:180px">Asset class</th><th class="num">Rows</th><th class="num">Net</th>
      <th class="num">Gross</th><th class="num">Long</th><th class="num">Short</th><th class="num">Duration</th>
    </tr></thead><tbody>
      <tr class="total-row total-top">
        <td>Total (ex funding)</td>
        <td class="num">${t.row_count}</td>
        <td class="num ${signClass(t.net_pct)}">${pct(t.net_pct, 2)}</td>
        <td class="num">${pct(t.gross_pct, 2, false)}</td>
        <td class="num pos">${pct(t.long_pct, 2)}</td>
        <td class="num neg">${pct(t.short_pct, 2)}</td>
        <td class="num ${signClass(t.duration_contribution)}">${yrs(t.duration_contribution, 3)}</td>
      </tr>
      ${groups.map(([label, g]) => `<tr>
        <td>${label}</td>
        <td class="num">${g.row_count}</td>
        <td class="num ${signClass(g.net_pct)}">${pct(g.net_pct, 2)}</td>
        <td class="num">${pct(g.gross_pct, 2, false)}</td>
        <td class="num pos">${pct(g.long_pct, 2)}</td>
        <td class="num neg">${pct(g.short_pct, 2)}</td>
        <td class="num ${signClass(g.duration_contribution)}">${yrs(g.duration_contribution, 3)}</td>
      </tr>`).join('')}
      <tr class="offset-row"><td>Cash &amp; Funding (sleeve)</td><td class="num">1</td>
        <td class="num ${signClass(k.funding_sleeve_pct)}">${pct(k.funding_sleeve_pct, 2)}</td>
        <td class="num">${pct(Math.abs(k.funding_sleeve_pct), 2, false)}</td><td></td><td></td><td class="faint">n/a</td></tr>
      <tr class="subtotal-row"><td>Book nets to</td><td></td>
        <td class="num ${signClass(k.book_nets_to)}">${pct(k.book_nets_to, 4)}</td>
        <td colspan="4" class="small faint">The funding sleeve is maintained so this is always zero.</td></tr>
    </tbody></table>
    ${leverageNote(k)}`;
}

/* The sleeve weight is leverage; this is what it costs. */
function leverageNote(k) {
  const lev = k.leverage || {};
  if (!lev.financed_pct) return '';
  return `<div class="panel-body small faint">
    <strong>Cost of leverage.</strong> ${escapeHtml(lev.footnote || '')} —
    an annualised run rate of <span class="${signClass(lev.annual_run_rate_pct)}">${pct(lev.annual_run_rate_pct, 3)}</span>.
    Accrued MTD ${pct(lev.accrued_mtd_pct, 3)} · YTD ${pct(lev.accrued_ytd_pct, 3)} ·
    since inception ${pct(lev.accrued_itd_pct, 3)}. This is booked into P&amp;L daily
    and appears as the “Cash &amp; Funding” contributor in the attribution chart.
  </div>`;
}

function renderDuration() {
  const rows = view.rows.filter((r) => r.level_1 === 'Fixed Income');
  document.getElementById('dur-wrap').innerHTML = rows.length ? `
    <table class="grid"><thead><tr>
      <th style="min-width:210px">Instrument</th><th class="mono">Ticker</th><th>L2</th><th>L3</th>
      <th class="num">Weight</th><th class="num">Duration</th><th>Source</th>
      <th class="num">Contribution</th><th style="min-width:280px">Note</th>
    </tr></thead><tbody>
      ${rows.map((r) => {
        const cls = { direct: 'tag-direct', proxy: 'tag-proxy', override: 'tag-manual' }[r.duration_source] || 'tag-na';
        return `<tr>
          <td>${escapeHtml(r.instrument_name)}</td>
          <td class="mono">${escapeHtml(r.ticker)}</td>
          <td>${escapeHtml(r.level_2)}</td>
          <td>${escapeHtml(r.level_3)}</td>
          <td class="num ${signClass(r.net_weight_pct)}">${pct(r.net_weight_pct)}</td>
          <td class="num">${r.duration_years === null ? '–' : num(r.duration_years, 3)}</td>
          <td><span class="tag ${cls}">${escapeHtml(r.duration_source || '')}</span></td>
          <td class="num ${signClass(r.duration_contribution)}">${r.duration_contribution === null ? '–' : yrs(r.duration_contribution, 4)}</td>
          <td class="small faint">${escapeHtml(r.duration_note || '')}</td>
        </tr>`;
      }).join('')}
      <tr class="total-row"><td>Fixed income duration target</td><td colspan="6"></td>
        <td class="num ${signClass(view.totals.duration_contribution)}">${yrs(view.totals.duration_contribution, 4)}</td><td></td></tr>
    </tbody></table>` : '<div class="empty-state">No fixed income exposure in this book.</div>';
}

function renderVol() {
  const rows = view.rows.filter((r) => !r.is_funding_offset)
    .sort((a, b) => (b.standalone_vol_pct || 0) - (a.standalone_vol_pct || 0));
  const advanced = volMode === 'advanced';
  const w = view.windows;

  document.getElementById('vol-wrap').innerHTML = rows.length ? `
    <table class="grid"><thead><tr>
      <th style="min-width:210px">Instrument</th><th class="mono">Ticker</th><th>L1</th>
      <th class="num">Weight</th><th class="num">Instrument vol</th><th class="num">Standalone</th>
      ${advanced ? '<th class="num">Obs</th><th style="min-width:300px">Note</th>' : ''}
    </tr></thead><tbody>
      ${rows.map((r) => `<tr>
        <td>${escapeHtml(r.instrument_name)}</td>
        <td class="mono">${escapeHtml(r.ticker)}</td>
        <td>${escapeHtml(r.level_1)}</td>
        <td class="num ${signClass(r.net_weight_pct)}">${pct(r.net_weight_pct)}</td>
        <td class="num">${pct(r.instrument_vol_pct, 2, false)}</td>
        <td class="num">${pct(r.standalone_vol_pct, 3, false)}</td>
        ${advanced ? `<td class="num ${r.vol_observations < 20 ? 'neg' : ''}">${r.vol_observations}</td>
          <td class="small faint">${escapeHtml(r.vol_note || '')}</td>` : ''}
      </tr>`).join('')}
      <tr class="total-row"><td>Sum of standalone (undiversified)</td><td></td><td></td><td></td><td></td>
        <td class="num">${pct(view.totals.sum_of_standalone_vol_pct, 3, false)}</td>
        ${advanced ? '<td></td><td></td>' : ''}</tr>
    </tbody></table>
    <div class="panel-body small faint">
      Annualised realised volatility of daily log returns over
      ${isoDate(w.positioning_start)} → ${isoDate(w.positioning_end)} (lookback ${w.vol_lookback_days} days).
      Non-trading days are excluded rather than filled, so instruments on a non-US calendar are not
      biased downwards. The total is a sum of standalone contributions and therefore an
      <strong>upper bound</strong> on portfolio volatility, not an estimate of it.
    </div>` : '<div class="empty-state">No positions to measure.</div>';
}

document.querySelectorAll('#seg-metric button').forEach((b) =>
  b.addEventListener('click', () => {
    document.querySelectorAll('#seg-metric button').forEach((x) => x.setAttribute('aria-pressed', 'false'));
    b.setAttribute('aria-pressed', 'true');
    metric = b.dataset.metric;
    renderTree();
  }));

document.querySelectorAll('#seg-vol-mode button').forEach((b) =>
  b.addEventListener('click', () => {
    document.querySelectorAll('#seg-vol-mode button').forEach((x) => x.setAttribute('aria-pressed', 'false'));
    b.setAttribute('aria-pressed', 'true');
    volMode = b.dataset.mode;
    renderVol();
  }));

document.getElementById('expand-all').addEventListener('click', () => {
  collapsed.clear();
  renderTree();
});

document.getElementById('an-apply').addEventListener('click', load);
document.addEventListener('ppt:valuation-changed', load);

load();
