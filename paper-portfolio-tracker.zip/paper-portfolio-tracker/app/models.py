"""
SQLAlchemy ORM model - the durable record of the book.

Design principles enforced here:

  * Imports never destroy history. An import writes new `trades` or
    `portfolio_snapshot_rows` and a lineage record in `imported_files`; it
    supersedes rather than deletes.
  * Trade events and target snapshots are different things and live in
    different tables. A trade is a dated *change* in notional weight; a
    snapshot is a dated *statement of intent* about the whole book.
  * Anything Bloomberg-derived is cached with the field and the observation
    date that produced it, so a number can always be explained.
  * Anything a human overrode is tagged as such, permanently.
"""

from __future__ import annotations

import enum
from datetime import date, datetime

from sqlalchemy import (
    Boolean,
    Date,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------
class ExecutionType(str, enum.Enum):
    MKT_CLOSE = "Mkt Close"
    MKT_OPEN = "Mkt Open"
    CUSTOM = "Custom"


class LevelSource(str, enum.Enum):
    """Where an execution level actually came from."""

    BLOOMBERG = "bloomberg"            # exact print on the requested date
    BLOOMBERG_FALLBACK = "bloomberg_fallback"  # last prior print (holiday etc.)
    MANUAL = "manual"                  # user-entered Custom level
    IMPORTED = "imported"              # level supplied in an import file
    SYNTHETIC = "synthetic"            # funding sleeve - no market price


class TradeSource(str, enum.Enum):
    MANUAL_ENTRY = "manual_entry"
    IMPORT_TRADE_HISTORY = "import_trade_history"
    SNAPSHOT_DERIVED = "snapshot_derived"
    FUNDING_OFFSET = "funding_offset"


class ImportMode(str, enum.Enum):
    TRADE_HISTORY = "trade_history"
    TARGET_SNAPSHOT = "target_snapshot"


class ImportStatus(str, enum.Enum):
    UPLOADED = "uploaded"
    VALIDATED = "validated"
    FAILED_VALIDATION = "failed_validation"
    COMMITTED = "committed"
    SUPERSEDED = "superseded"
    ROLLED_BACK = "rolled_back"


class RowStatus(str, enum.Enum):
    PENDING = "pending"
    VALID = "valid"
    WARNING = "warning"
    ERROR = "error"
    COMMITTED = "committed"
    SKIPPED = "skipped"


class PortfolioStatus(str, enum.Enum):
    ACTIVE = "active"
    ARCHIVED = "archived"


class DurationSource(str, enum.Enum):
    DIRECT = "direct"        # observed Bloomberg reference field
    PROXY = "proxy"          # static proxy table
    OVERRIDE = "override"    # human override, logged
    NOT_APPLICABLE = "n/a"   # yield-quoted or non-fixed-income
    UNAVAILABLE = "unavailable"


# ---------------------------------------------------------------------------
# Instrument master
# ---------------------------------------------------------------------------
class InstrumentMaster(Base):
    """
    Canonical instrument taxonomy, seeded from bloomberg_futures_hierarchy.

    The natural key is the FULL Bloomberg ticker including the yellow key
    ("NO1 Index" vs "NO1 Curncy" are different instruments - Nikkei 225 mini
    and the Norwegian krone respectively - and both appear in the seed file).
    """

    __tablename__ = "instruments_master"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    bbg_ticker: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    bbg_code: Mapped[str] = mapped_column(String(64), index=True)
    yellow_key: Mapped[str] = mapped_column(String(16), index=True)

    level_1: Mapped[str] = mapped_column(String(64), index=True)
    level_2: Mapped[str] = mapped_column(String(96), index=True)
    level_3: Mapped[str] = mapped_column(String(96), index=True)
    level_4: Mapped[str] = mapped_column(String(96), index=True)
    instrument_name: Mapped[str] = mapped_column(String(160), index=True)

    primary_exchange: Mapped[str | None] = mapped_column(String(64))
    notes: Mapped[str | None] = mapped_column(Text)

    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)

    # Populated from Bloomberg on first reference; cached here for search.
    validated_at: Mapped[datetime | None] = mapped_column(DateTime)
    validation_status: Mapped[str | None] = mapped_column(String(32))

    source_file: Mapped[str | None] = mapped_column(String(512))
    source_row_number: Mapped[int | None] = mapped_column(Integer)
    master_version: Mapped[int] = mapped_column(Integer, default=1, index=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )

    __table_args__ = (
        Index("ix_instr_hierarchy", "level_1", "level_2", "level_3", "level_4"),
    )

    @property
    def search_blob(self) -> str:
        return " ".join(
            filter(
                None,
                [
                    self.bbg_ticker,
                    self.bbg_code,
                    self.instrument_name,
                    self.level_1,
                    self.level_2,
                    self.level_3,
                    self.level_4,
                    self.primary_exchange,
                ],
            )
        ).lower()


class InstrumentMasterVersion(Base):
    """One row per ingestion of an instrument-master file. Never deleted."""

    __tablename__ = "instrument_master_versions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    version: Mapped[int] = mapped_column(Integer, unique=True, index=True)
    source_filename: Mapped[str] = mapped_column(String(512))
    source_sha256: Mapped[str] = mapped_column(String(64))
    row_count: Mapped[int] = mapped_column(Integer)
    added_count: Mapped[int] = mapped_column(Integer, default=0)
    updated_count: Mapped[int] = mapped_column(Integer, default=0)
    deactivated_count: Mapped[int] = mapped_column(Integer, default=0)
    column_mapping_json: Mapped[str | None] = mapped_column(Text)
    loaded_by: Mapped[str | None] = mapped_column(String(128))
    loaded_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    notes: Mapped[str | None] = mapped_column(Text)


# ---------------------------------------------------------------------------
# Portfolios
# ---------------------------------------------------------------------------
class Portfolio(Base):
    __tablename__ = "portfolios"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    portfolio_id: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(200))
    description: Mapped[str | None] = mapped_column(Text)
    owner: Mapped[str | None] = mapped_column(String(128))
    status: Mapped[PortfolioStatus] = mapped_column(
        Enum(PortfolioStatus), default=PortfolioStatus.ACTIVE, index=True
    )
    base_currency: Mapped[str] = mapped_column(String(8), default="USD")
    inception_date: Mapped[date | None] = mapped_column(Date)

    # Funding sleeve configuration overrides (null => use global settings)
    funding_benchmark: Mapped[str | None] = mapped_column(String(32))
    funding_spread_bps: Mapped[float | None] = mapped_column(Float)

    cloned_from_id: Mapped[int | None] = mapped_column(ForeignKey("portfolios.id"))
    archived_at: Mapped[datetime | None] = mapped_column(DateTime)
    notes: Mapped[str | None] = mapped_column(Text)

    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )

    trades: Mapped[list["Trade"]] = relationship(
        back_populates="portfolio", cascade="all, delete-orphan"
    )
    snapshots: Mapped[list["PortfolioSnapshot"]] = relationship(
        back_populates="portfolio", cascade="all, delete-orphan"
    )


# ---------------------------------------------------------------------------
# Trades and lots
# ---------------------------------------------------------------------------
class Trade(Base):
    """
    A dated CHANGE in target notional weight.

    `weight_delta_pct` is signed and expressed in percent: 4.0 means +4.00%.
    A position is the running sum of its trades. Trims are negative, a full
    exit is the negative of the running weight, a reversal simply crosses
    through zero and the lot engine handles it.
    """

    __tablename__ = "trades"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    portfolio_pk: Mapped[int] = mapped_column(
        ForeignKey("portfolios.id", ondelete="CASCADE"), index=True
    )
    instrument_id: Mapped[int | None] = mapped_column(
        ForeignKey("instruments_master.id"), index=True
    )
    bbg_ticker: Mapped[str] = mapped_column(String(64), index=True)

    trade_date: Mapped[date] = mapped_column(Date, index=True)
    weight_delta_pct: Mapped[float] = mapped_column(Float)

    execution_type: Mapped[ExecutionType] = mapped_column(Enum(ExecutionType))
    execution_level: Mapped[float | None] = mapped_column(Float)
    level_source: Mapped[LevelSource] = mapped_column(Enum(LevelSource))

    # --- audit trail on the price -----------------------------------------
    price_field_used: Mapped[str | None] = mapped_column(String(32))
    price_observation_date: Mapped[date | None] = mapped_column(Date)
    price_fallback_days: Mapped[int] = mapped_column(Integer, default=0)
    price_fallback_reason: Mapped[str | None] = mapped_column(String(256))
    # True when the execution level came from a Bloomberg request issued at the
    # moment the trade was booked, rather than from the local price cache.
    # Trades dated inside the live window always force a fresh request; older
    # trades are priced from settled cached history, which is correct.
    price_from_live_request: Mapped[bool] = mapped_column(Boolean, default=False)
    price_provider: Mapped[str | None] = mapped_column(String(24))

    source: Mapped[TradeSource] = mapped_column(Enum(TradeSource), index=True)
    imported_file_id: Mapped[int | None] = mapped_column(
        ForeignKey("imported_files.id"), index=True
    )
    import_row_id: Mapped[int | None] = mapped_column(ForeignKey("import_rows.id"))
    snapshot_id: Mapped[int | None] = mapped_column(ForeignKey("portfolio_snapshots.id"))

    is_funding_offset: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    is_void: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    void_reason: Mapped[str | None] = mapped_column(String(256))

    notes: Mapped[str | None] = mapped_column(Text)
    entered_by: Mapped[str | None] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    # Set when a trade has been amended after booking. The full before/after
    # diff lives in the audit log; these two columns exist so the UI can flag an
    # edited row without joining to it.
    edited_at: Mapped[datetime | None] = mapped_column(DateTime)
    edited_by: Mapped[str | None] = mapped_column(String(128))

    portfolio: Mapped[Portfolio] = relationship(back_populates="trades")
    instrument: Mapped[InstrumentMaster | None] = relationship()

    __table_args__ = (
        Index("ix_trade_book_date", "portfolio_pk", "trade_date"),
        Index("ix_trade_book_instr", "portfolio_pk", "bbg_ticker", "trade_date"),
    )


class TradeLot(Base):
    """
    FIFO lot history. Rebuilt deterministically from `trades` by the position
    engine, but persisted so the UI can show lot detail without recomputation
    and so historical realised P&L is auditable.
    """

    __tablename__ = "trade_lots"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    portfolio_pk: Mapped[int] = mapped_column(
        ForeignKey("portfolios.id", ondelete="CASCADE"), index=True
    )
    bbg_ticker: Mapped[str] = mapped_column(String(64), index=True)

    open_trade_id: Mapped[int] = mapped_column(ForeignKey("trades.id"))
    open_date: Mapped[date] = mapped_column(Date, index=True)
    open_level: Mapped[float] = mapped_column(Float)
    open_weight_pct: Mapped[float] = mapped_column(Float)      # signed, original size
    remaining_weight_pct: Mapped[float] = mapped_column(Float)  # signed, still open

    close_trade_id: Mapped[int | None] = mapped_column(ForeignKey("trades.id"))
    close_date: Mapped[date | None] = mapped_column(Date)
    close_level: Mapped[float | None] = mapped_column(Float)
    closed_weight_pct: Mapped[float] = mapped_column(Float, default=0.0)
    realised_pnl_pct: Mapped[float] = mapped_column(Float, default=0.0)

    is_open: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    computed_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


# ---------------------------------------------------------------------------
# Target snapshots
# ---------------------------------------------------------------------------
class PortfolioSnapshot(Base):
    """A dated statement of intended positioning for the whole book."""

    __tablename__ = "portfolio_snapshots"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    portfolio_pk: Mapped[int] = mapped_column(
        ForeignKey("portfolios.id", ondelete="CASCADE"), index=True
    )
    snapshot_date: Mapped[date] = mapped_column(Date, index=True)
    label: Mapped[str | None] = mapped_column(String(160))
    imported_file_id: Mapped[int | None] = mapped_column(ForeignKey("imported_files.id"))

    is_current: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    superseded_by_id: Mapped[int | None] = mapped_column(
        ForeignKey("portfolio_snapshots.id")
    )
    materialised_as_trades: Mapped[bool] = mapped_column(Boolean, default=False)

    notes: Mapped[str | None] = mapped_column(Text)
    created_by: Mapped[str | None] = mapped_column(String(128))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    portfolio: Mapped[Portfolio] = relationship(back_populates="snapshots")
    rows: Mapped[list["PortfolioSnapshotRow"]] = relationship(
        back_populates="snapshot", cascade="all, delete-orphan"
    )

    # Deliberately NOT unique on (portfolio, date, label): re-importing a target
    # book for a date that already has one must create a NEW row and mark the
    # old one superseded, not fail or overwrite. Uniqueness of the *live* view
    # is expressed by `is_current` plus the `superseded_by_id` chain.
    __table_args__ = (
        Index("ix_snapshot_lookup", "portfolio_pk", "snapshot_date", "is_current"),
    )


class PortfolioSnapshotRow(Base):
    """One intended position within a snapshot. Weight is ABSOLUTE, not a delta."""

    __tablename__ = "portfolio_snapshot_rows"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    snapshot_id: Mapped[int] = mapped_column(
        ForeignKey("portfolio_snapshots.id", ondelete="CASCADE"), index=True
    )
    instrument_id: Mapped[int | None] = mapped_column(ForeignKey("instruments_master.id"))
    bbg_ticker: Mapped[str] = mapped_column(String(64), index=True)
    target_weight_pct: Mapped[float] = mapped_column(Float)

    execution_type: Mapped[ExecutionType] = mapped_column(
        Enum(ExecutionType), default=ExecutionType.MKT_CLOSE
    )
    reference_level: Mapped[float | None] = mapped_column(Float)
    level_source: Mapped[LevelSource] = mapped_column(
        Enum(LevelSource), default=LevelSource.BLOOMBERG
    )
    price_observation_date: Mapped[date | None] = mapped_column(Date)
    is_funding_offset: Mapped[bool] = mapped_column(Boolean, default=False)
    notes: Mapped[str | None] = mapped_column(Text)

    snapshot: Mapped[PortfolioSnapshot] = relationship(back_populates="rows")
    instrument: Mapped[InstrumentMaster | None] = relationship()


# ---------------------------------------------------------------------------
# Imports
# ---------------------------------------------------------------------------
class ImportedFile(Base):
    __tablename__ = "imported_files"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    portfolio_pk: Mapped[int | None] = mapped_column(ForeignKey("portfolios.id"), index=True)
    mode: Mapped[ImportMode] = mapped_column(Enum(ImportMode), index=True)
    status: Mapped[ImportStatus] = mapped_column(
        Enum(ImportStatus), default=ImportStatus.UPLOADED, index=True
    )

    original_filename: Mapped[str] = mapped_column(String(512))
    # REPOINT SHARED DRIVE LATER - archive location resolves from
    # settings.paths.import_archive; only the relative name is stored so the
    # archive can be relocated without rewriting rows.
    archived_relpath: Mapped[str | None] = mapped_column(String(512))
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    byte_size: Mapped[int] = mapped_column(Integer, default=0)

    row_count: Mapped[int] = mapped_column(Integer, default=0)
    valid_count: Mapped[int] = mapped_column(Integer, default=0)
    warning_count: Mapped[int] = mapped_column(Integer, default=0)
    error_count: Mapped[int] = mapped_column(Integer, default=0)
    committed_count: Mapped[int] = mapped_column(Integer, default=0)

    # Target-snapshot imports may replace the prior snapshot for the same date;
    # trade-history imports always append. Recorded explicitly so the UI can
    # show what a given import actually did.
    replace_behaviour: Mapped[str] = mapped_column(String(32), default="append")
    superseded_snapshot_id: Mapped[int | None] = mapped_column(Integer)

    uploaded_by: Mapped[str | None] = mapped_column(String(128))
    uploaded_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    committed_at: Mapped[datetime | None] = mapped_column(DateTime)
    message: Mapped[str | None] = mapped_column(Text)

    rows: Mapped[list["ImportRow"]] = relationship(
        back_populates="file", cascade="all, delete-orphan"
    )


class ImportRow(Base):
    """Every row of every uploaded file, exactly as parsed. Never mutated after commit."""

    __tablename__ = "import_rows"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    imported_file_id: Mapped[int] = mapped_column(
        ForeignKey("imported_files.id", ondelete="CASCADE"), index=True
    )
    row_number: Mapped[int] = mapped_column(Integer)
    raw_json: Mapped[str] = mapped_column(Text)

    status: Mapped[RowStatus] = mapped_column(Enum(RowStatus), default=RowStatus.PENDING)
    messages_json: Mapped[str | None] = mapped_column(Text)

    parsed_portfolio_id: Mapped[str | None] = mapped_column(String(64))
    parsed_ticker: Mapped[str | None] = mapped_column(String(64))
    resolved_ticker: Mapped[str | None] = mapped_column(String(64))
    parsed_weight_pct: Mapped[float | None] = mapped_column(Float)
    parsed_trade_date: Mapped[date | None] = mapped_column(Date)
    parsed_execution_type: Mapped[str | None] = mapped_column(String(32))
    parsed_level: Mapped[float | None] = mapped_column(Float)
    parsed_notes: Mapped[str | None] = mapped_column(Text)

    created_trade_id: Mapped[int | None] = mapped_column(Integer)
    created_snapshot_row_id: Mapped[int | None] = mapped_column(Integer)

    file: Mapped[ImportedFile] = relationship(back_populates="rows")


# ---------------------------------------------------------------------------
# Bloomberg caches
# ---------------------------------------------------------------------------
class InstrumentReferenceCache(Base):
    """
    Point-in-time reference data (duration, multiplier, currency, ...).

    Scoped by `provider`: live Bloomberg values and offline synthetic values
    coexist rather than overwriting each other, so the Live/Offline toggle is
    instant and non-destructive. Manual overrides use provider='manual' and are
    honoured in BOTH modes.
    """

    __tablename__ = "instrument_reference_cache"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    bbg_ticker: Mapped[str] = mapped_column(String(64), index=True)
    field: Mapped[str] = mapped_column(String(48), index=True)
    as_of_date: Mapped[date] = mapped_column(Date, index=True)
    value_num: Mapped[float | None] = mapped_column(Float)
    value_str: Mapped[str | None] = mapped_column(String(256))
    provider: Mapped[str] = mapped_column(String(24), default="blpapi", index=True)
    fetched_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    __table_args__ = (
        UniqueConstraint(
            "bbg_ticker", "field", "as_of_date", "provider", name="uq_ref_cache"
        ),
    )


class AppState(Base):
    """
    Small persisted key/value store for runtime state that must survive a
    restart - currently just the Live/Offline data mode.

    Deliberately not in settings.yaml: the toggle is an operator action taken
    in the UI, not a deployment setting, and writing it back to a config file
    from a web request would be a poor idea in a locked-down environment.
    """

    __tablename__ = "app_state"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str] = mapped_column(String(256))
    updated_by: Mapped[str | None] = mapped_column(String(128))
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )


class PricingHistoryCache(Base):
    """
    Daily OHLC/settle cache. One row per ticker per observation date PER
    PROVIDER.

    Scoping by provider is what makes the Live/Offline toggle safe. Without it,
    a synthetic price cached during offline work would satisfy the
    cache-coverage check in live mode and a live book would silently be marked
    off simulated data. With it, each mode reads only its own prints and
    switching is instant and reversible.
    """

    __tablename__ = "pricing_history_cache"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    bbg_ticker: Mapped[str] = mapped_column(String(64), index=True)
    observation_date: Mapped[date] = mapped_column(Date, index=True)
    px_open: Mapped[float | None] = mapped_column(Float)
    px_high: Mapped[float | None] = mapped_column(Float)
    px_low: Mapped[float | None] = mapped_column(Float)
    px_last: Mapped[float | None] = mapped_column(Float)
    px_settle: Mapped[float | None] = mapped_column(Float)
    is_actual_print: Mapped[bool] = mapped_column(Boolean, default=True)
    provider: Mapped[str] = mapped_column(String(24), default="blpapi", index=True)
    fetched_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    __table_args__ = (
        UniqueConstraint(
            "bbg_ticker", "observation_date", "provider", name="uq_price_cache"
        ),
        Index("ix_price_lookup", "bbg_ticker", "provider", "observation_date"),
    )


# ---------------------------------------------------------------------------
# Funding
# ---------------------------------------------------------------------------
class FundingBenchmark(Base):
    """Effective-dated funding curve. Overlapping rows resolve by latest date."""

    __tablename__ = "funding_benchmarks"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    benchmark: Mapped[str] = mapped_column(String(32), index=True)
    effective_date: Mapped[date] = mapped_column(Date, index=True)
    rate_pct: Mapped[float] = mapped_column(Float)
    source: Mapped[str] = mapped_column(String(32), default="config")
    note: Mapped[str | None] = mapped_column(String(256))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    __table_args__ = (
        UniqueConstraint("benchmark", "effective_date", name="uq_funding_effective"),
    )


# ---------------------------------------------------------------------------
# Calculated / derived state
# ---------------------------------------------------------------------------
class CalculatedPosition(Base):
    """
    Materialised position state for a portfolio as of a valuation date.
    Fully recomputable from `trades`; cached for grid rendering speed.
    """

    __tablename__ = "calculated_positions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    portfolio_pk: Mapped[int] = mapped_column(
        ForeignKey("portfolios.id", ondelete="CASCADE"), index=True
    )
    valuation_date: Mapped[date] = mapped_column(Date, index=True)
    bbg_ticker: Mapped[str] = mapped_column(String(64), index=True)
    instrument_id: Mapped[int | None] = mapped_column(ForeignKey("instruments_master.id"))

    net_weight_pct: Mapped[float] = mapped_column(Float, default=0.0)
    avg_open_level: Mapped[float | None] = mapped_column(Float)
    latest_level: Mapped[float | None] = mapped_column(Float)
    latest_level_date: Mapped[date | None] = mapped_column(Date)

    unrealised_pnl_pct: Mapped[float] = mapped_column(Float, default=0.0)
    realised_pnl_pct: Mapped[float] = mapped_column(Float, default=0.0)

    duration_years: Mapped[float | None] = mapped_column(Float)
    duration_contribution: Mapped[float | None] = mapped_column(Float)
    duration_source: Mapped[DurationSource | None] = mapped_column(Enum(DurationSource))

    standalone_vol_pct: Mapped[float | None] = mapped_column(Float)
    vol_observations: Mapped[int | None] = mapped_column(Integer)

    is_funding_offset: Mapped[bool] = mapped_column(Boolean, default=False)
    computed_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    __table_args__ = (
        UniqueConstraint(
            "portfolio_pk", "valuation_date", "bbg_ticker", name="uq_calc_position"
        ),
    )


class PnlSnapshot(Base):
    """Daily P&L contribution, per instrument. The authoritative P&L series."""

    __tablename__ = "pnl_snapshots"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    portfolio_pk: Mapped[int] = mapped_column(
        ForeignKey("portfolios.id", ondelete="CASCADE"), index=True
    )
    pnl_date: Mapped[date] = mapped_column(Date, index=True)
    bbg_ticker: Mapped[str] = mapped_column(String(64), index=True)

    opening_weight_pct: Mapped[float] = mapped_column(Float, default=0.0)
    closing_weight_pct: Mapped[float] = mapped_column(Float, default=0.0)
    prior_level: Mapped[float | None] = mapped_column(Float)
    close_level: Mapped[float | None] = mapped_column(Float)

    carry_pnl_pct: Mapped[float] = mapped_column(Float, default=0.0)   # held from prior close
    trade_pnl_pct: Mapped[float] = mapped_column(Float, default=0.0)   # intraday from exec level
    funding_pnl_pct: Mapped[float] = mapped_column(Float, default=0.0)  # cash sleeve accrual
    total_pnl_pct: Mapped[float] = mapped_column(Float, default=0.0)

    is_funding_offset: Mapped[bool] = mapped_column(Boolean, default=False)
    price_is_stale: Mapped[bool] = mapped_column(Boolean, default=False)
    computed_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    __table_args__ = (
        UniqueConstraint("portfolio_pk", "pnl_date", "bbg_ticker", name="uq_pnl_snapshot"),
        Index("ix_pnl_range", "portfolio_pk", "pnl_date"),
    )


class AnalyticsSnapshot(Base):
    """Cached aggregate analytics for a (portfolio, window, grouping) triple."""

    __tablename__ = "analytics_snapshots"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    portfolio_pk: Mapped[int] = mapped_column(
        ForeignKey("portfolios.id", ondelete="CASCADE"), index=True
    )
    valuation_date: Mapped[date] = mapped_column(Date, index=True)
    window_start: Mapped[date | None] = mapped_column(Date)
    window_end: Mapped[date | None] = mapped_column(Date)
    analytic: Mapped[str] = mapped_column(String(48), index=True)
    grouping: Mapped[str | None] = mapped_column(String(48))
    payload_json: Mapped[str] = mapped_column(Text)
    computed_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


# ---------------------------------------------------------------------------
# Audit
# ---------------------------------------------------------------------------
class AuditLog(Base):
    """
    Append-only. Every price fallback, duration proxy, manual override, import
    commit and configuration change lands here.
    """

    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    event_time: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), index=True
    )
    category: Mapped[str] = mapped_column(String(48), index=True)
    action: Mapped[str] = mapped_column(String(96), index=True)
    portfolio_pk: Mapped[int | None] = mapped_column(Integer, index=True)
    entity_type: Mapped[str | None] = mapped_column(String(48))
    entity_id: Mapped[int | None] = mapped_column(Integer)
    bbg_ticker: Mapped[str | None] = mapped_column(String(64), index=True)
    actor: Mapped[str | None] = mapped_column(String(128))
    summary: Mapped[str] = mapped_column(String(512))
    detail_json: Mapped[str | None] = mapped_column(Text)
