"""Append-only audit logging. Cheap to call; call it liberally."""

from __future__ import annotations

import json
import logging
from typing import Any, Mapping, Optional

from sqlalchemy.orm import Session

from app.models import AuditLog

logger = logging.getLogger(__name__)


def record(
    db: Session,
    *,
    category: str,
    action: str,
    summary: str,
    portfolio_pk: Optional[int] = None,
    entity_type: Optional[str] = None,
    entity_id: Optional[int] = None,
    bbg_ticker: Optional[str] = None,
    actor: Optional[str] = None,
    detail: Optional[Mapping[str, Any]] = None,
    flush: bool = False,
) -> AuditLog:
    entry = AuditLog(
        category=category,
        action=action,
        summary=summary[:512],
        portfolio_pk=portfolio_pk,
        entity_type=entity_type,
        entity_id=entity_id,
        bbg_ticker=bbg_ticker,
        actor=actor or "system",
        detail_json=json.dumps(detail, default=str) if detail else None,
    )
    db.add(entry)
    if flush:
        db.flush()
    return entry


def recent(db: Session, *, portfolio_pk: int | None = None, limit: int = 200):
    q = db.query(AuditLog).order_by(AuditLog.event_time.desc(), AuditLog.id.desc())
    if portfolio_pk is not None:
        q = q.filter(AuditLog.portfolio_pk == portfolio_pk)
    return q.limit(limit).all()
