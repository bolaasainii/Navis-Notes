"""
Position state: the FIFO lot engine and the funding-sleeve maintainer.

Weight convention
-----------------
Everything is a signed notional weight in percent of portfolio NAV. `4.0`
means +4.00%. A trade carries a *delta*; a position is the running sum of its
deltas. That single convention handles the whole trade taxonomy without
special cases:

    add      -> another delta with the same sign
    trim     -> a delta with the opposite sign, smaller than the position
    exit     -> a delta with the opposite sign, equal to the position
    reversal -> a delta with the opposite sign, larger than the position

Lot accounting
--------------
Lots are FIFO. A same-sign delta opens a lot. An opposite-sign delta consumes
open lots oldest-first, realising

    realised_pct = closed_signed_weight * (close_level / open_level - 1)

and any residual after all lots are consumed opens a fresh lot on the other
side - which is exactly what a reversal is.

Lots are derived data: `rebuild_lots` recomputes them deterministically from
`trades`. They are persisted so the UI can show lot detail cheaply and so a
historical realised number can be pointed at a specific opening trade.
"""

from __future__ import annotations

import logging
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Deque, Dict, Iterable, List, Optional, Sequence, Tuple

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.config import settings
from app.models import (
    ExecutionType,
    InstrumentMaster,
    LevelSource,
    Portfolio,
    Trade,
    TradeLot,
    TradeSource,
)
from app.services import audit

logger = logging.getLogger(__name__)

WEIGHT_EPSILON = 1e-9


# ---------------------------------------------------------------------------
# Trade access
# ---------------------------------------------------------------------------
def all_trades(
    db: Session,
    portfolio: Portfolio,
    *,
    through: Optional[date] = None,
    include_offset: bool = True,
    include_void: bool = False,
) -> List[Trade]:
    stmt = select(Trade).where(Trade.portfolio_pk == portfolio.id)
    if through is not None:
        stmt = stmt.where(Trade.trade_date <= through)
    if not include_offset:
        stmt = stmt.where(Trade.is_funding_offset.is_(False))
    if not include_void:
        stmt = stmt.where(Trade.is_void.is_(False))
    return list(db.scalars(stmt.order_by(Trade.trade_date.asc(), Trade.id.asc())))


def market_trades(db: Session, portfolio: Portfolio, *, through: Optional[date] = None) -> List[Trade]:
    return all_trades(db, portfolio, through=through, include_offset=False)


# ---------------------------------------------------------------------------
# Funding sleeve
# ---------------------------------------------------------------------------
def rebuild_funding_offset(
    db: Session, portfolio: Portfolio, *, actor: Optional[str] = None
) -> int:
    """
    Regenerate the `USD_CASH_OFFSET` trade series so the book nets to 0% on
    every date on which market weights changed.

    Implementation: on each distinct trade date the offset delta is simply the
    negative of the net market delta booked that date. Cumulatively that keeps
    offset_weight == -market_weight at all times, which is the invariant tested
    in tests/test_funding.py.

    Existing offset rows are deleted and rewritten. They are entirely
    system-generated - no user input is ever destroyed by this - and the
    regeneration is recorded in the audit log.
    """
    offset_ticker = settings.funding.offset_ticker

    db.execute(
        delete(Trade).where(
            Trade.portfolio_pk == portfolio.id, Trade.is_funding_offset.is_(True)
        )
    )

    deltas: Dict[date, float] = defaultdict(float)
    for t in market_trades(db, portfolio):
        deltas[t.trade_date] += t.weight_delta_pct

    instrument = db.scalars(
        select(InstrumentMaster).where(InstrumentMaster.bbg_ticker == offset_ticker)
    ).first()

    created = 0
    for trade_date in sorted(deltas):
        delta = deltas[trade_date]
        if abs(delta) < WEIGHT_EPSILON:
            continue
        db.add(
            Trade(
                portfolio_pk=portfolio.id,
                instrument_id=instrument.id if instrument else None,
                bbg_ticker=offset_ticker,
                trade_date=trade_date,
                weight_delta_pct=-delta,
                execution_type=ExecutionType.CUSTOM,
                execution_level=100.0,
                level_source=LevelSource.SYNTHETIC,
                source=TradeSource.FUNDING_OFFSET,
                is_funding_offset=True,
                notes="Auto-generated balancing sleeve - do not edit",
                entered_by="system",
            )
        )
        created += 1

    db.flush()
    audit.record(
        db,
        category="funding",
        action="rebuild_offset",
        summary=f"Rebuilt funding sleeve: {created} balancing row(s)",
        portfolio_pk=portfolio.id,
        bbg_ticker=offset_ticker,
        actor=actor,
    )
    return created


# ---------------------------------------------------------------------------
# Lot engine
# ---------------------------------------------------------------------------
@dataclass
class _OpenLot:
    trade_id: int
    open_date: date
    open_level: float
    original_weight: float   # signed
    remaining_weight: float  # signed
    closed_weight: float = 0.0
    realised: float = 0.0
    close_trade_id: Optional[int] = None
    close_date: Optional[date] = None
    close_level: Optional[float] = None


@dataclass
class LotBook:
    """Result of running the lot engine for one instrument."""

    ticker: str
    lots: List[_OpenLot] = field(default_factory=list)
    realised_pnl_pct: float = 0.0

    @property
    def net_weight_pct(self) -> float:
        return sum(l.remaining_weight for l in self.lots)

    @property
    def open_lots(self) -> List[_OpenLot]:
        return [l for l in self.lots if abs(l.remaining_weight) > WEIGHT_EPSILON]

    @property
    def average_open_level(self) -> Optional[float]:
        """Weight-averaged open level across still-open lots."""
        open_lots = self.open_lots
        total = sum(abs(l.remaining_weight) for l in open_lots)
        if total < WEIGHT_EPSILON:
            return None
        return sum(l.open_level * abs(l.remaining_weight) for l in open_lots) / total


def run_lot_engine(trades: Sequence[Trade]) -> Dict[str, LotBook]:
    """
    Pure function: trades in, lot books out. No database access, so it is
    trivially unit-testable and can be reused for what-if analysis.
    """
    by_ticker: Dict[str, List[Trade]] = defaultdict(list)
    for t in trades:
        by_ticker[t.bbg_ticker].append(t)

    books: Dict[str, LotBook] = {}
    for ticker, ticker_trades in by_ticker.items():
        book = LotBook(ticker=ticker)
        queue: Deque[_OpenLot] = deque()

        for trade in sorted(ticker_trades, key=lambda x: (x.trade_date, x.id or 0)):
            delta = float(trade.weight_delta_pct or 0.0)
            level = trade.execution_level
            if abs(delta) < WEIGHT_EPSILON:
                continue
            if level is None:
                logger.warning(
                    "Trade %s on %s has no execution level; skipped by the lot engine",
                    trade.id,
                    trade.bbg_ticker,
                )
                continue

            # Close against opposing lots first.
            while (
                queue
                and abs(delta) > WEIGHT_EPSILON
                and _sign(queue[0].remaining_weight) != _sign(delta)
            ):
                lot = queue[0]
                lot_sign = _sign(lot.remaining_weight)
                closable = min(abs(lot.remaining_weight), abs(delta))
                closed_signed = closable * lot_sign

                # Realised P&L on the slice of this lot being closed. The sign
                # falls out of the lot's own sign: a short lot (negative
                # weight) closed at a higher level realises a loss.
                realised = closed_signed * (level / lot.open_level - 1.0)

                lot.realised += realised
                lot.closed_weight += closable
                lot.remaining_weight -= closed_signed
                lot.close_trade_id = trade.id
                lot.close_date = trade.trade_date
                lot.close_level = level
                book.realised_pnl_pct += realised

                # `delta` and `closed_signed` always have opposite signs here,
                # so adding moves delta toward zero by exactly `closable`.
                delta += closed_signed

                if abs(lot.remaining_weight) < WEIGHT_EPSILON:
                    lot.remaining_weight = 0.0
                    queue.popleft()

            if abs(delta) > WEIGHT_EPSILON:
                lot = _OpenLot(
                    trade_id=trade.id or 0,
                    open_date=trade.trade_date,
                    open_level=level,
                    original_weight=delta,
                    remaining_weight=delta,
                )
                queue.append(lot)
                book.lots.append(lot)

        books[ticker] = book
    return books


def _sign(x: float) -> float:
    return 1.0 if x >= 0 else -1.0


def rebuild_lots(db: Session, portfolio: Portfolio, *, actor: Optional[str] = None) -> int:
    """Recompute and persist lot history for a portfolio."""
    db.execute(delete(TradeLot).where(TradeLot.portfolio_pk == portfolio.id))

    trades = all_trades(db, portfolio, include_offset=False)
    books = run_lot_engine(trades)

    count = 0
    for ticker, book in books.items():
        for lot in book.lots:
            db.add(
                TradeLot(
                    portfolio_pk=portfolio.id,
                    bbg_ticker=ticker,
                    open_trade_id=lot.trade_id,
                    open_date=lot.open_date,
                    open_level=lot.open_level,
                    open_weight_pct=lot.original_weight,
                    remaining_weight_pct=lot.remaining_weight,
                    close_trade_id=lot.close_trade_id,
                    close_date=lot.close_date,
                    close_level=lot.close_level,
                    closed_weight_pct=lot.closed_weight,
                    realised_pnl_pct=lot.realised,
                    is_open=abs(lot.remaining_weight) > WEIGHT_EPSILON,
                )
            )
            count += 1
    db.flush()
    return count


# ---------------------------------------------------------------------------
# Position queries
# ---------------------------------------------------------------------------
def net_weights_as_of(
    db: Session,
    portfolio: Portfolio,
    as_of: date,
    *,
    include_offset: bool = True,
) -> Dict[str, float]:
    """Net signed weight per ticker as of a date."""
    weights: Dict[str, float] = defaultdict(float)
    for t in all_trades(db, portfolio, through=as_of, include_offset=include_offset):
        weights[t.bbg_ticker] += t.weight_delta_pct
    return {k: v for k, v in weights.items() if abs(v) > WEIGHT_EPSILON}


def weight_timeline(
    db: Session, portfolio: Portfolio, *, include_offset: bool = True
) -> Dict[str, Dict[date, float]]:
    """{ticker: {date: net weight AFTER that date's trades}} - drives the P&L engine."""
    per_ticker_deltas: Dict[str, Dict[date, float]] = defaultdict(lambda: defaultdict(float))
    for t in all_trades(db, portfolio, include_offset=include_offset):
        per_ticker_deltas[t.bbg_ticker][t.trade_date] += t.weight_delta_pct

    out: Dict[str, Dict[date, float]] = {}
    for ticker, deltas in per_ticker_deltas.items():
        running = 0.0
        series: Dict[date, float] = {}
        for d in sorted(deltas):
            running += deltas[d]
            series[d] = running
        out[ticker] = series
    return out


def active_tickers_between(
    db: Session,
    portfolio: Portfolio,
    start: date,
    end: date,
    *,
    include_offset: bool = False,
) -> List[str]:
    """
    Tickers that carried a non-zero weight at any point inside [start, end].

    This is what drives "standalone vol for the positions active during
    August" - the positioning window, which is deliberately independent of the
    performance window used for P&L.
    """
    timeline = weight_timeline(db, portfolio, include_offset=include_offset)
    active: List[str] = []
    for ticker, series in timeline.items():
        dates = sorted(series)
        # Weight entering the window.
        entering = 0.0
        for d in dates:
            if d < start:
                entering = series[d]
            else:
                break
        if abs(entering) > WEIGHT_EPSILON:
            active.append(ticker)
            continue
        if any(start <= d <= end and abs(series[d]) > WEIGHT_EPSILON for d in dates):
            active.append(ticker)
    return sorted(active)


@dataclass
class TargetLeg:
    """
    One period during which a single target weight was in force.

    A "leg" starts either at the window start (the weight carried into it) or
    on the date a trade changed the target, and runs until the next change or
    the end of the window. This is the shape the Positions grid expands into:
    not a list of trades, but a list of *what the target actually was, and
    when*.
    """

    effective_from: date
    effective_to: Optional[date]      # inclusive; None => still in force at window end
    target_pct: float                 # the target AFTER this change
    delta_pct: float                  # the change itself (0.0 for the carried-in leg)
    level: Optional[float] = None
    level_source: Optional[str] = None
    execution_type: Optional[str] = None
    fallback_days: int = 0
    is_opening: bool = False          # carried into the window rather than traded in it
    is_closing_flat: bool = False     # this leg took the position to zero
    notes: Optional[str] = None

    def as_dict(self) -> dict:
        return {
            "effective_from": self.effective_from,
            "effective_to": self.effective_to,
            "target_pct": self.target_pct,
            "delta_pct": self.delta_pct,
            "level": self.level,
            "level_source": self.level_source,
            "execution_type": self.execution_type,
            "fallback_days": self.fallback_days,
            "is_opening": self.is_opening,
            "is_closing_flat": self.is_closing_flat,
            "notes": self.notes,
        }


def target_history(
    db: Session,
    portfolio: Portfolio,
    start: date,
    end: date,
    *,
    include_offset: bool = False,
) -> Dict[str, List[TargetLeg]]:
    """
    Per-instrument target timeline inside [start, end].

    Includes instruments that were CLOSED during the window - a position opened
    in July and closed in August is part of the quarter's positioning even
    though it is flat today, and leaving it out would misrepresent the period.

    The first leg of each series is the weight carried INTO the window, so the
    history always explains the whole window rather than starting at the first
    trade inside it.
    """
    trades = all_trades(db, portfolio, through=end, include_offset=include_offset)
    by_ticker: Dict[str, List[Trade]] = defaultdict(list)
    for t in trades:
        by_ticker[t.bbg_ticker].append(t)

    out: Dict[str, List[TargetLeg]] = {}
    for ticker, ticker_trades in by_ticker.items():
        ticker_trades.sort(key=lambda x: (x.trade_date, x.id or 0))

        # Weight entering the window.
        opening = sum(
            t.weight_delta_pct for t in ticker_trades if t.trade_date < start
        )
        in_window = [t for t in ticker_trades if start <= t.trade_date <= end]

        if abs(opening) < WEIGHT_EPSILON and not in_window:
            continue  # never on during the window

        legs: List[TargetLeg] = []
        running = opening
        if abs(opening) > WEIGHT_EPSILON:
            legs.append(
                TargetLeg(
                    effective_from=start,
                    effective_to=None,
                    target_pct=opening,
                    delta_pct=0.0,
                    is_opening=True,
                )
            )

        # Collapse same-day trades: a target only changes once per date.
        by_day: Dict[date, List[Trade]] = defaultdict(list)
        for t in in_window:
            by_day[t.trade_date].append(t)

        for day in sorted(by_day):
            day_trades = by_day[day]
            delta = sum(t.weight_delta_pct for t in day_trades)
            running += delta
            last = day_trades[-1]
            if legs:
                legs[-1].effective_to = day - timedelta(days=1)
            legs.append(
                TargetLeg(
                    effective_from=day,
                    effective_to=None,
                    target_pct=running,
                    delta_pct=delta,
                    level=last.execution_level,
                    level_source=last.level_source.value if last.level_source else None,
                    execution_type=last.execution_type.value if last.execution_type else None,
                    fallback_days=last.price_fallback_days or 0,
                    is_closing_flat=abs(running) < WEIGHT_EPSILON,
                    notes=next((t.notes for t in reversed(day_trades) if t.notes), None),
                )
            )

        if legs:
            legs[-1].effective_to = None if abs(running) > WEIGHT_EPSILON else legs[-1].effective_from
        out[ticker] = legs

    return out


def first_trade_date(db: Session, portfolio: Portfolio) -> Optional[date]:
    row = db.execute(
        select(Trade.trade_date)
        .where(Trade.portfolio_pk == portfolio.id, Trade.is_void.is_(False))
        .order_by(Trade.trade_date.asc())
        .limit(1)
    ).first()
    return row[0] if row else None


def last_trade_date(db: Session, portfolio: Portfolio) -> Optional[date]:
    row = db.execute(
        select(Trade.trade_date)
        .where(Trade.portfolio_pk == portfolio.id, Trade.is_void.is_(False))
        .order_by(Trade.trade_date.desc())
        .limit(1)
    ).first()
    return row[0] if row else None
