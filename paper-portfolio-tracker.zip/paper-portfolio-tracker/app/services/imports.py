"""
CSV / XLSX import system.

Two modes, deliberately distinct in both the UI and the data model:

TRADE HISTORY  -> dated trade EVENTS. Each row is a signed change in notional
                  weight on a date. Used to backfill prior activity, rebuild
                  lot history and populate historical P&L. Always APPENDS.

TARGET SNAPSHOT-> a target BOOK as of a date. Each row is an absolute intended
                  weight. Used to establish and monitor intended positioning.
                  A second snapshot for the same date SUPERSEDES the first;
                  the original is retained and marked, never deleted.

Upload is a two-phase operation. Phase one parses, validates and stores every
row exactly as it appeared, returning a preview. Phase two commits. Nothing is
written to the book until the user confirms, and the staged rows remain as
permanent lineage afterwards.

Validation rules (per specification)
------------------------------------
    portfolio_id        required
    bbg_ticker          required, resolved against the instrument master
    notional_weight_pct required, numeric, '4' means 4.00%
    trade_date          required, ISO (YYYY-MM-DD)
    execution_time      required, one of: Mkt Close | Mkt Open | Custom
    level               required ONLY when execution_time == Custom;
                        may be blank otherwise, in which case Bloomberg fills it
    notes               optional
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import logging
import re
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import settings
from app.models import (
    ExecutionType,
    ImportedFile,
    ImportMode,
    ImportRow,
    ImportStatus,
    InstrumentMaster,
    LevelSource,
    Portfolio,
    PortfolioSnapshot,
    PortfolioSnapshotRow,
    RowStatus,
    Trade,
    TradeSource,
)
from app.services import audit, instruments, portfolios, pricing, trades

logger = logging.getLogger(__name__)

CANONICAL_COLUMNS = (
    "portfolio_id",
    "bbg_ticker",
    "notional_weight_pct",
    "trade_date",
    "execution_time",
    "level",
    "notes",
)

COLUMN_ALIASES: Dict[str, Sequence[str]] = {
    "portfolio_id": ("portfolio_id", "portfolio id", "portfolio", "book", "book_id"),
    "bbg_ticker": (
        "bbg_ticker",
        "bloomberg ticker",
        "bloomberg code",
        "bloomberg formula",
        "ticker",
        "security",
    ),
    "notional_weight_pct": (
        "notional_weight_pct",
        "notional weight pct",
        "notional weight %",
        "notional weight",
        "weight_pct",
        "weight %",
        "weight",
        "target_weight_pct",
        "target weight",
    ),
    "trade_date": ("trade_date", "trade date", "date", "as_of_date", "as of date"),
    "execution_time": (
        "execution_time",
        "execution time",
        "execution_type",
        "execution type",
        "execution",
    ),
    "level": ("level", "execution_level", "execution level", "price", "px"),
    "notes": ("notes", "note", "comment", "comments"),
}

EXECUTION_LOOKUP = {
    "mkt close": ExecutionType.MKT_CLOSE,
    "market close": ExecutionType.MKT_CLOSE,
    "close": ExecutionType.MKT_CLOSE,
    "mkt open": ExecutionType.MKT_OPEN,
    "market open": ExecutionType.MKT_OPEN,
    "open": ExecutionType.MKT_OPEN,
    "custom": ExecutionType.CUSTOM,
    "manual": ExecutionType.CUSTOM,
}

_SEPARATORS = re.compile(r"[_\-]+")
_NORM = re.compile(r"[^a-z0-9%/ ]+")
_SPACES = re.compile(r"\s+")


def _normalise(h: str) -> str:
    """
    Fold a header (or an alias) to a comparable form.

    Underscores and hyphens become spaces FIRST, so `portfolio_id`,
    `Portfolio ID` and `portfolio-id` all normalise to `portfolio id`.
    """
    s = _SEPARATORS.sub(" ", (h or "").strip().lower())
    s = _NORM.sub("", s)
    return _SPACES.sub(" ", s).strip()


def _map_columns(headers: Sequence[str]) -> Dict[str, str]:
    normalised = {_normalise(h): h for h in headers}
    mapping: Dict[str, str] = {}
    for canonical, aliases in COLUMN_ALIASES.items():
        for alias in aliases:
            key = _normalise(alias)
            if key in normalised:
                mapping[canonical] = normalised[key]
                break
    return mapping


def _parse_rows(content: bytes, filename: str) -> Tuple[List[dict], List[str]]:
    if filename.lower().endswith((".xlsx", ".xlsm", ".xltx")):
        from openpyxl import load_workbook

        wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
        ws = wb[wb.sheetnames[0]]
        rows_iter = ws.iter_rows(values_only=True)
        try:
            header_row = next(rows_iter)
        except StopIteration:
            return [], []
        headers = [str(h).strip() if h is not None else "" for h in header_row]
        out: List[dict] = []
        for values in rows_iter:
            if values is None or all(v is None or str(v).strip() == "" for v in values):
                continue
            record = {}
            for i, h in enumerate(headers):
                v = values[i] if i < len(values) else None
                if isinstance(v, datetime):
                    v = v.date().isoformat()
                elif isinstance(v, date):
                    v = v.isoformat()
                record[h] = "" if v is None else str(v)
            out.append(record)
        return out, headers

    text = content.decode("utf-8-sig", errors="replace")
    reader = csv.DictReader(io.StringIO(text))
    headers = list(reader.fieldnames or [])
    rows = [r for r in reader if any((v or "").strip() for v in r.values())]
    return rows, headers


# ---------------------------------------------------------------------------
# Row validation
# ---------------------------------------------------------------------------
@dataclass
class ParsedRow:
    row_number: int
    raw: dict
    status: RowStatus = RowStatus.PENDING
    messages: List[str] = field(default_factory=list)

    portfolio_id: Optional[str] = None
    ticker_raw: Optional[str] = None
    resolved_ticker: Optional[str] = None
    instrument_id: Optional[int] = None
    weight_pct: Optional[float] = None
    trade_date: Optional[date] = None
    execution_type: Optional[ExecutionType] = None
    level: Optional[float] = None
    level_source: Optional[LevelSource] = None
    price_field: Optional[str] = None
    price_obs_date: Optional[date] = None
    fallback_days: int = 0
    notes: Optional[str] = None

    def error(self, msg: str) -> None:
        self.messages.append(msg)
        self.status = RowStatus.ERROR

    def warn(self, msg: str) -> None:
        self.messages.append(msg)
        if self.status != RowStatus.ERROR:
            self.status = RowStatus.WARNING

    def as_preview(self) -> dict:
        return {
            "row_number": self.row_number,
            "status": self.status.value,
            "messages": self.messages,
            "portfolio_id": self.portfolio_id,
            "bbg_ticker": self.resolved_ticker or self.ticker_raw,
            "notional_weight_pct": self.weight_pct,
            "trade_date": self.trade_date,
            "execution_time": self.execution_type.value if self.execution_type else None,
            "level": self.level,
            "level_source": self.level_source.value if self.level_source else None,
            "fallback_days": self.fallback_days,
            "notes": self.notes,
        }


def _parse_date(value: str) -> Optional[date]:
    v = (value or "").strip()
    if not v:
        return None
    v = v.replace("/", "-")
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%m-%d-%Y", "%Y%m%d"):
        try:
            return datetime.strptime(v[:10] if fmt != "%Y%m%d" else v[:8], fmt).date()
        except ValueError:
            continue
    return None


def validate_rows(
    db: Session,
    raw_rows: Sequence[dict],
    mapping: Dict[str, str],
    *,
    mode: ImportMode,
    expected_portfolio_id: Optional[str] = None,
    resolve_levels: bool = True,
) -> List[ParsedRow]:
    parsed: List[ParsedRow] = []
    seen_keys: set = set()

    for idx, raw in enumerate(raw_rows, start=2):
        row = ParsedRow(row_number=idx, raw=raw)

        def cell(field_name: str) -> str:
            header = mapping.get(field_name)
            return (raw.get(header) or "").strip() if header else ""

        # --- portfolio_id --------------------------------------------------
        row.portfolio_id = cell("portfolio_id") or None
        if not row.portfolio_id:
            row.error("portfolio_id is required")
        elif expected_portfolio_id and row.portfolio_id != expected_portfolio_id:
            row.error(
                f"portfolio_id {row.portfolio_id!r} does not match the selected "
                f"portfolio {expected_portfolio_id!r}"
            )
        elif portfolios.get(db, row.portfolio_id) is None:
            row.error(f"portfolio {row.portfolio_id!r} does not exist")

        # --- bbg_ticker ----------------------------------------------------
        row.ticker_raw = cell("bbg_ticker") or None
        if not row.ticker_raw:
            row.error("bbg_ticker is required")
        else:
            inst, messages = instruments.resolve_ticker(db, row.ticker_raw)
            if inst is None:
                row.error(messages[0] if messages else f"{row.ticker_raw!r} not found")
            else:
                row.resolved_ticker = inst.bbg_ticker
                row.instrument_id = inst.id
                for m in messages:
                    row.warn(m)
                if not inst.is_active:
                    row.warn(f"{inst.bbg_ticker} is marked inactive in the instrument master")

        # --- notional_weight_pct -------------------------------------------
        weight_raw = cell("notional_weight_pct")
        if not weight_raw:
            row.error("notional_weight_pct is required")
        else:
            try:
                row.weight_pct = trades.parse_weight(weight_raw)
            except trades.TradeError as exc:
                row.error(str(exc))

        # --- trade_date -----------------------------------------------------
        date_raw = cell("trade_date")
        if not date_raw:
            row.error("trade_date is required")
        else:
            parsed_date = _parse_date(date_raw)
            if parsed_date is None:
                row.error(f"trade_date {date_raw!r} is not a valid ISO date (YYYY-MM-DD)")
            elif parsed_date > date.today():
                row.error(f"trade_date {parsed_date.isoformat()} is in the future")
            else:
                row.trade_date = parsed_date

        # --- execution_time -------------------------------------------------
        exec_raw = cell("execution_time")
        if not exec_raw:
            row.error(
                "execution_time is required and must be one of: Mkt Close, Mkt Open, Custom"
            )
        else:
            match = EXECUTION_LOOKUP.get(exec_raw.strip().lower())
            if match is None:
                row.error(
                    f"execution_time {exec_raw!r} is not valid - use Mkt Close, Mkt Open or Custom"
                )
            else:
                row.execution_type = match

        # --- level ----------------------------------------------------------
        level_raw = cell("level")
        level_value: Optional[float] = None
        if level_raw:
            try:
                level_value = float(level_raw.replace(",", ""))
            except ValueError:
                row.error(f"level {level_raw!r} is not numeric")

        if row.execution_type == ExecutionType.CUSTOM and level_value is None:
            row.error("level is required when execution_time is Custom")
        if (
            row.execution_type in (ExecutionType.MKT_CLOSE, ExecutionType.MKT_OPEN)
            and level_value is not None
        ):
            row.warn(
                "level supplied for a market execution - Bloomberg's official level "
                "will be used instead and this value is retained for reference only"
            )

        row.notes = cell("notes") or None

        # --- duplicate detection --------------------------------------------
        if row.status != RowStatus.ERROR:
            key = (row.portfolio_id, row.resolved_ticker, row.trade_date, row.weight_pct)
            if key in seen_keys:
                row.warn("duplicate of an earlier row in this file")
            seen_keys.add(key)

        # --- level resolution ------------------------------------------------
        if row.status != RowStatus.ERROR and resolve_levels and row.resolved_ticker:
            resolved = pricing.resolve_execution_level(
                db,
                ticker=row.resolved_ticker,
                trade_date=row.trade_date,
                execution_type=row.execution_type,
                custom_level=level_value,
                imported=True,
            )
            if not resolved.ok:
                row.error(resolved.reason or "could not resolve an execution level")
            else:
                row.level = resolved.level
                row.level_source = resolved.source
                row.price_field = resolved.field_used
                row.price_obs_date = resolved.observation_date
                row.fallback_days = resolved.fallback_days
                if resolved.is_stale:
                    row.warn(resolved.reason or "stale price used")

        if row.status == RowStatus.PENDING:
            row.status = RowStatus.VALID

        parsed.append(row)

    if mode == ImportMode.TARGET_SNAPSHOT:
        _validate_snapshot_semantics(parsed)

    return parsed


def _validate_snapshot_semantics(parsed: Sequence[ParsedRow]) -> None:
    """
    A target snapshot states absolute weights, so the same instrument must not
    appear twice for the same date. In trade-history mode repeats are entirely
    normal (adds and trims), which is why this check is mode-specific.
    """
    seen: Dict[Tuple[Optional[str], Optional[date]], int] = {}
    for row in parsed:
        if row.status == RowStatus.ERROR or not row.resolved_ticker:
            continue
        key = (row.resolved_ticker, row.trade_date)
        if key in seen:
            row.error(
                f"{row.resolved_ticker} appears more than once for "
                f"{row.trade_date}. A target snapshot states one absolute weight "
                f"per instrument (see row {seen[key]})."
            )
        else:
            seen[key] = row.row_number


# ---------------------------------------------------------------------------
# Staging
# ---------------------------------------------------------------------------
def stage_upload(
    db: Session,
    *,
    content: bytes,
    filename: str,
    mode: ImportMode,
    portfolio: Optional[Portfolio] = None,
    actor: Optional[str] = None,
) -> Tuple[ImportedFile, List[ParsedRow]]:
    """Phase one: parse, validate, persist lineage, return a preview."""
    raw_rows, headers = _parse_rows(content, filename)
    mapping = _map_columns(headers)

    missing = [
        c
        for c in ("portfolio_id", "bbg_ticker", "notional_weight_pct", "trade_date", "execution_time")
        if c not in mapping
    ]

    digest = hashlib.sha256(content).hexdigest()
    record = ImportedFile(
        portfolio_pk=portfolio.id if portfolio else None,
        mode=mode,
        status=ImportStatus.UPLOADED,
        original_filename=filename,
        sha256=digest,
        byte_size=len(content),
        row_count=len(raw_rows),
        replace_behaviour="append" if mode == ImportMode.TRADE_HISTORY else "supersede",
        uploaded_by=actor,
    )
    db.add(record)
    db.flush()

    # REPOINT SHARED DRIVE LATER - the archive directory resolves from
    # settings.paths.import_archive; only the relative name is stored on the
    # row so the archive can be relocated without a data migration.
    archive_name = f"{record.id:06d}_{digest[:8]}_{Path(filename).name}"
    try:
        archive_path = settings.paths.import_archive / archive_name
        archive_path.parent.mkdir(parents=True, exist_ok=True)
        archive_path.write_bytes(content)
        record.archived_relpath = archive_name
    except OSError as exc:  # pragma: no cover - shared drive unavailable
        logger.warning("Could not archive import file: %s", exc)
        record.message = f"File could not be archived: {exc}"

    if missing:
        record.status = ImportStatus.FAILED_VALIDATION
        record.error_count = len(raw_rows)
        record.message = (
            "Missing required column(s): "
            + ", ".join(missing)
            + f". Headers found: {headers}. Download the template for the expected layout."
        )
        db.flush()
        return record, []

    parsed = validate_rows(
        db,
        raw_rows,
        mapping,
        mode=mode,
        expected_portfolio_id=portfolio.portfolio_id if portfolio else None,
    )

    for row in parsed:
        db.add(
            ImportRow(
                imported_file_id=record.id,
                row_number=row.row_number,
                raw_json=json.dumps(row.raw, default=str),
                status=row.status,
                messages_json=json.dumps(row.messages) if row.messages else None,
                parsed_portfolio_id=row.portfolio_id,
                parsed_ticker=row.ticker_raw,
                resolved_ticker=row.resolved_ticker,
                parsed_weight_pct=row.weight_pct,
                parsed_trade_date=row.trade_date,
                parsed_execution_type=row.execution_type.value if row.execution_type else None,
                parsed_level=row.level,
                parsed_notes=row.notes,
            )
        )

    record.valid_count = sum(1 for r in parsed if r.status == RowStatus.VALID)
    record.warning_count = sum(1 for r in parsed if r.status == RowStatus.WARNING)
    record.error_count = sum(1 for r in parsed if r.status == RowStatus.ERROR)
    record.status = (
        ImportStatus.FAILED_VALIDATION if record.error_count else ImportStatus.VALIDATED
    )
    db.flush()

    audit.record(
        db,
        category="import",
        action="stage",
        summary=(
            f"Staged {mode.value} import {filename}: {record.valid_count} valid, "
            f"{record.warning_count} warning, {record.error_count} error"
        ),
        portfolio_pk=portfolio.id if portfolio else None,
        entity_type="imported_file",
        entity_id=record.id,
        actor=actor,
        detail={"sha256": digest, "column_mapping": mapping},
    )
    return record, parsed


# ---------------------------------------------------------------------------
# Commit
# ---------------------------------------------------------------------------
def commit(
    db: Session,
    record: ImportedFile,
    *,
    skip_error_rows: bool = True,
    snapshot_label: Optional[str] = None,
    make_current: bool = True,
    actor: Optional[str] = None,
) -> dict:
    """Phase two: write the staged rows into the book."""
    if record.status == ImportStatus.COMMITTED:
        raise ValueError("This import has already been committed")
    if record.status == ImportStatus.FAILED_VALIDATION and not skip_error_rows:
        raise ValueError("This import failed validation; fix the file or skip error rows")

    rows = list(
        db.scalars(
            select(ImportRow)
            .where(ImportRow.imported_file_id == record.id)
            .order_by(ImportRow.row_number)
        )
    )
    usable = [r for r in rows if r.status in (RowStatus.VALID, RowStatus.WARNING)]
    if not usable:
        raise ValueError("There are no valid rows to commit")

    if record.mode == ImportMode.TRADE_HISTORY:
        result = _commit_trade_history(db, record, usable, actor=actor)
    else:
        result = _commit_target_snapshot(
            db, record, usable, label=snapshot_label, make_current=make_current, actor=actor
        )

    record.status = ImportStatus.COMMITTED
    record.committed_at = datetime.utcnow()
    record.committed_count = result["committed"]
    db.flush()

    audit.record(
        db,
        category="import",
        action="commit",
        summary=(
            f"Committed {record.mode.value} import {record.original_filename}: "
            f"{result['committed']} row(s), behaviour={record.replace_behaviour}"
        ),
        portfolio_pk=record.portfolio_pk,
        entity_type="imported_file",
        entity_id=record.id,
        actor=actor,
        detail=result,
    )
    return result


def _commit_trade_history(
    db: Session, record: ImportedFile, rows: Sequence[ImportRow], *, actor: Optional[str]
) -> dict:
    affected: Dict[int, Portfolio] = {}
    committed = 0

    for row in rows:
        portfolio = portfolios.get(db, row.parsed_portfolio_id or "")
        if portfolio is None:
            continue
        instrument = db.scalars(
            select(InstrumentMaster).where(
                InstrumentMaster.bbg_ticker == (row.resolved_ticker or "")
            )
        ).first()

        exec_type = EXECUTION_LOOKUP.get(
            (row.parsed_execution_type or "").lower(), ExecutionType.MKT_CLOSE
        )
        resolved = pricing.resolve_execution_level(
            db,
            ticker=row.resolved_ticker,
            trade_date=row.parsed_trade_date,
            execution_type=exec_type,
            custom_level=row.parsed_level if exec_type == ExecutionType.CUSTOM else None,
            imported=True,
        )
        level = resolved.level if resolved.ok else row.parsed_level
        if level is None:
            continue

        trade = Trade(
            portfolio_pk=portfolio.id,
            instrument_id=instrument.id if instrument else None,
            bbg_ticker=row.resolved_ticker,
            trade_date=row.parsed_trade_date,
            weight_delta_pct=row.parsed_weight_pct,
            execution_type=exec_type,
            execution_level=level,
            level_source=resolved.source if resolved.ok else LevelSource.IMPORTED,
            price_field_used=resolved.field_used,
            price_observation_date=resolved.observation_date,
            price_fallback_days=resolved.fallback_days,
            price_fallback_reason=resolved.reason,
            price_from_live_request=resolved.from_live_request,
            price_provider=resolved.provider,
            source=TradeSource.IMPORT_TRADE_HISTORY,
            imported_file_id=record.id,
            import_row_id=row.id,
            notes=row.parsed_notes,
            entered_by=actor,
        )
        db.add(trade)
        db.flush()
        row.created_trade_id = trade.id
        row.status = RowStatus.COMMITTED
        affected[portfolio.id] = portfolio
        committed += 1

    for portfolio in affected.values():
        trades.recalculate(db, portfolio, actor=actor)

    return {
        "mode": ImportMode.TRADE_HISTORY.value,
        "committed": committed,
        "portfolios": [p.portfolio_id for p in affected.values()],
        "behaviour": "append",
    }


def _commit_target_snapshot(
    db: Session,
    record: ImportedFile,
    rows: Sequence[ImportRow],
    *,
    label: Optional[str],
    make_current: bool,
    actor: Optional[str],
) -> dict:
    by_key: Dict[Tuple[str, date], List[ImportRow]] = {}
    for row in rows:
        key = (row.parsed_portfolio_id or "", row.parsed_trade_date)
        by_key.setdefault(key, []).append(row)

    created: List[int] = []
    superseded: List[int] = []
    committed = 0

    for (portfolio_id, snapshot_date), group in sorted(by_key.items(), key=lambda kv: kv[0][1]):
        portfolio = portfolios.get(db, portfolio_id)
        if portfolio is None:
            continue

        prior = db.scalars(
            select(PortfolioSnapshot).where(
                PortfolioSnapshot.portfolio_pk == portfolio.id,
                PortfolioSnapshot.snapshot_date == snapshot_date,
                PortfolioSnapshot.label == label,
            )
        ).first()

        snapshot = PortfolioSnapshot(
            portfolio_pk=portfolio.id,
            snapshot_date=snapshot_date,
            label=label or f"Import {record.id}",
            imported_file_id=record.id,
            created_by=actor,
        )
        db.add(snapshot)
        db.flush()

        if prior is not None:
            # Supersede, never delete. The prior snapshot stays queryable and
            # points at the one that replaced it.
            prior.superseded_by_id = snapshot.id
            prior.is_current = False
            superseded.append(prior.id)
            record.superseded_snapshot_id = prior.id

        total_weight = 0.0
        for row in group:
            instrument = db.scalars(
                select(InstrumentMaster).where(
                    InstrumentMaster.bbg_ticker == (row.resolved_ticker or "")
                )
            ).first()
            db.add(
                PortfolioSnapshotRow(
                    snapshot_id=snapshot.id,
                    instrument_id=instrument.id if instrument else None,
                    bbg_ticker=row.resolved_ticker,
                    target_weight_pct=row.parsed_weight_pct or 0.0,
                    execution_type=EXECUTION_LOOKUP.get(
                        (row.parsed_execution_type or "").lower(), ExecutionType.MKT_CLOSE
                    ),
                    reference_level=row.parsed_level,
                    level_source=LevelSource.IMPORTED,
                    price_observation_date=row.parsed_trade_date,
                    notes=row.parsed_notes,
                )
            )
            total_weight += row.parsed_weight_pct or 0.0
            row.created_snapshot_row_id = snapshot.id
            row.status = RowStatus.COMMITTED
            committed += 1

        # The funding sleeve is added to the snapshot too, so an intended book
        # displays as netting to zero exactly like the live one.
        offset_instrument = db.scalars(
            select(InstrumentMaster).where(
                InstrumentMaster.bbg_ticker == settings.funding.offset_ticker
            )
        ).first()
        db.add(
            PortfolioSnapshotRow(
                snapshot_id=snapshot.id,
                instrument_id=offset_instrument.id if offset_instrument else None,
                bbg_ticker=settings.funding.offset_ticker,
                target_weight_pct=-total_weight,
                execution_type=ExecutionType.CUSTOM,
                reference_level=100.0,
                level_source=LevelSource.SYNTHETIC,
                is_funding_offset=True,
                notes="Auto-generated balancing sleeve",
            )
        )

        if make_current:
            for other in db.scalars(
                select(PortfolioSnapshot).where(
                    PortfolioSnapshot.portfolio_pk == portfolio.id,
                    PortfolioSnapshot.id != snapshot.id,
                )
            ):
                other.is_current = False
            snapshot.is_current = True

        created.append(snapshot.id)

    db.flush()
    return {
        "mode": ImportMode.TARGET_SNAPSHOT.value,
        "committed": committed,
        "snapshots_created": created,
        "snapshots_superseded": superseded,
        "behaviour": "supersede",
    }


# ---------------------------------------------------------------------------
# Templates
# ---------------------------------------------------------------------------
TEMPLATE_HEADER = list(CANONICAL_COLUMNS)

TRADE_HISTORY_SAMPLE = [
    ["Navi-S1", "ES1 Index", "4", "2026-06-01", "Mkt Close", "", "Initial US large cap long"],
    ["Navi-S1", "RX1 Comdty", "-3", "2026-06-01", "Mkt Close", "", "Short Bunds"],
    ["Navi-S1", "TY1 Comdty", "2.5", "2026-06-01", "Mkt Open", "", "Long US 10y at the open"],
    ["Navi-S1", "EC1 Curncy", "1.5", "2026-06-02", "Mkt Close", "", "Long EUR"],
    ["Navi-S1", "NK1 Index", "2", "2026-06-03", "Custom", "38250.0", "Filled away from the close"],
    ["Navi-S1", "ES1 Index", "1", "2026-06-15", "Mkt Close", "", "Add to the US long"],
    ["Navi-S1", "RX1 Comdty", "1", "2026-06-22", "Mkt Close", "", "Trim the Bund short"],
    ["Navi-S1", "NK1 Index", "-2", "2026-07-06", "Mkt Close", "", "Exit Japan"],
]

TARGET_SNAPSHOT_SAMPLE = [
    ["Navi-S1", "ES1 Index", "5", "2026-08-01", "Mkt Close", "", "Target US large cap"],
    ["Navi-S1", "RTY1 Index", "-2", "2026-08-01", "Mkt Close", "", "Short small cap"],
    ["Navi-S1", "TY1 Comdty", "3", "2026-08-01", "Mkt Close", "", "Duration long"],
    ["Navi-S1", "RX1 Comdty", "-2", "2026-08-01", "Mkt Close", "", "Short Bunds"],
    ["Navi-S1", "EC1 Curncy", "1.5", "2026-08-01", "Mkt Close", "", "Long EUR"],
    ["Navi-S1", "JY1 Curncy", "-1", "2026-08-01", "Mkt Close", "", "Short JPY"],
]


def template_csv(mode: ImportMode, *, with_sample: bool = False) -> str:
    buf = io.StringIO()
    writer = csv.writer(buf, lineterminator="\n")
    writer.writerow(TEMPLATE_HEADER)
    if with_sample:
        sample = (
            TRADE_HISTORY_SAMPLE
            if mode == ImportMode.TRADE_HISTORY
            else TARGET_SNAPSHOT_SAMPLE
        )
        writer.writerows(sample)
    return buf.getvalue()


def write_template_files() -> List[Path]:
    """
    Materialise the templates and samples on disk so they can be handed round
    by email as well as downloaded from the UI.

    REPOINT SHARED DRIVE LATER - destinations come from
    settings.paths.templates_path and settings.paths.samples_path.
    """
    written: List[Path] = []
    targets = [
        (settings.paths.templates_path / "trade_history_template.csv", ImportMode.TRADE_HISTORY, False),
        (settings.paths.templates_path / "target_snapshot_template.csv", ImportMode.TARGET_SNAPSHOT, False),
        (settings.paths.samples_path / "trade_history_sample.csv", ImportMode.TRADE_HISTORY, True),
        (settings.paths.samples_path / "target_snapshot_sample.csv", ImportMode.TARGET_SNAPSHOT, True),
    ]
    for path, mode, sample in targets:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(template_csv(mode, with_sample=sample), encoding="utf-8")
        written.append(path)
    return written


def import_history(
    db: Session, *, portfolio: Optional[Portfolio] = None, limit: int = 100
) -> List[ImportedFile]:
    stmt = select(ImportedFile).order_by(ImportedFile.uploaded_at.desc(), ImportedFile.id.desc())
    if portfolio is not None:
        stmt = stmt.where(ImportedFile.portfolio_pk == portfolio.id)
    return list(db.scalars(stmt.limit(limit)))
