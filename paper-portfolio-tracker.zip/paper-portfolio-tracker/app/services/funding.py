"""
Funding / leverage sleeve.

The rule
--------
A paper book expressed in notional weights must net to 0%. Every market
position is financed: a +100% long book is 100% borrowed, a -20% net short
book leaves +20% of cash on deposit. The application therefore maintains a
synthetic sleeve, `USD_CASH_OFFSET`, whose weight is always

    offset_weight = -(sum of all market instrument weights)

Users never enter it. It is recomputed whenever positions change.

What it is NOT
--------------
It is not a market instrument. It has no price, no duration, no beta and no
standalone volatility, and it is excluded from every hierarchy aggregate
(it sits under "Cash & Funding", outside Equity / Fixed Income / FX). Treating
it like a Treasury future or an equity index would double-count risk.

What it earns
-------------
    offset_weight > 0  (net cash on deposit)  -> earns  benchmark + positive_spread
    offset_weight < 0  (net borrowing)        -> pays   benchmark + negative_spread

Accrual is simple interest on the daily weight, day-counted per
`funding.day_count` (ACT/360 by default, matching SOFR convention):

    daily_pnl_pct = offset_weight_pct * rate_pct / 100 * days / basis

Benchmark rates are effective-dated. The seed curve lives in
config/funding_benchmarks.yaml; once loaded, the `funding_benchmarks` table is
authoritative and is editable from Settings. Where a live Bloomberg rate is
available for the benchmark ticker it takes precedence, and the source used is
recorded per accrual.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date
from typing import Dict, List, Optional, Sequence

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_funding_curve_seed, parse_iso_date, settings
from app.models import FundingBenchmark, Portfolio
from app.services import audit

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class FundingTerms:
    benchmark: str
    base_rate_pct: float
    spread_bps: float
    effective_date: Optional[date]
    source: str

    @property
    def all_in_rate_pct(self) -> float:
        return self.base_rate_pct + self.spread_bps / 100.0


def seed_curve(db: Session, *, force: bool = False) -> int:
    """Load config/funding_benchmarks.yaml into the table. Idempotent."""
    cfg = get_funding_curve_seed()
    benchmark = cfg.get("benchmark", settings.funding.positive_cash_benchmark)
    rows = cfg.get("curve") or []

    existing = {
        (r.benchmark, r.effective_date)
        for r in db.scalars(select(FundingBenchmark).where(FundingBenchmark.benchmark == benchmark))
    }
    added = 0
    for row in rows:
        eff = parse_iso_date(row["effective_date"])
        if (benchmark, eff) in existing and not force:
            continue
        if (benchmark, eff) in existing:
            continue
        db.add(
            FundingBenchmark(
                benchmark=benchmark,
                effective_date=eff,
                rate_pct=float(row["rate_pct"]),
                source="config",
                note=row.get("note"),
            )
        )
        added += 1
    if added:
        db.flush()
        audit.record(
            db,
            category="funding",
            action="seed_curve",
            summary=f"Seeded {added} {benchmark} benchmark point(s) from config",
        )
    return added


def rate_on(db: Session, benchmark: str, on: date) -> Optional[FundingBenchmark]:
    """Effective-dated lookup: latest point with effective_date <= `on`."""
    return db.scalars(
        select(FundingBenchmark)
        .where(
            FundingBenchmark.benchmark == benchmark,
            FundingBenchmark.effective_date <= on,
        )
        .order_by(FundingBenchmark.effective_date.desc())
        .limit(1)
    ).first()


def terms_for(
    db: Session, portfolio: Optional[Portfolio], on: date, *, weight_pct: float
) -> FundingTerms:
    """
    Resolve the applicable funding terms for a given day and sleeve sign.

    Portfolio-level overrides (funding_benchmark / funding_spread_bps) win over
    the global defaults in settings.yaml.
    """
    cfg = settings.funding
    is_cash = weight_pct >= 0
    benchmark = (
        (portfolio.funding_benchmark if portfolio else None)
        or (cfg.positive_cash_benchmark if is_cash else cfg.negative_cash_benchmark)
    )
    if is_cash:
        spread = cfg.positive_cash_spread_bps
    else:
        spread = (
            portfolio.funding_spread_bps
            if portfolio and portfolio.funding_spread_bps is not None
            else cfg.negative_cash_spread_bps
        )

    point = rate_on(db, benchmark, on)
    if point is None:
        logger.warning("No %s benchmark point on or before %s; assuming 0%%", benchmark, on)
        return FundingTerms(benchmark, 0.0, spread, None, "missing")
    return FundingTerms(benchmark, point.rate_pct, spread, point.effective_date, point.source)


def accrual_pct(
    db: Session,
    *,
    portfolio: Optional[Portfolio],
    weight_pct: float,
    from_date: date,
    to_date: date,
) -> tuple[float, FundingTerms]:
    """
    Interest accrued on the sleeve between two dates, in portfolio percent.

    Note the sign convention: `weight_pct` is the sleeve weight. Positive
    (cash on deposit) earns, negative (borrowing) pays. Because the rate is
    always positive, multiplying weight by rate produces the correct sign
    automatically - a -100% sleeve at 4% costs 4% a year.
    """
    days = (to_date - from_date).days
    if days <= 0 or weight_pct == 0.0:
        return 0.0, terms_for(db, portfolio, to_date, weight_pct=weight_pct)
    terms = terms_for(db, portfolio, from_date, weight_pct=weight_pct)
    basis = settings.funding.day_count_basis
    # For a short (negative) sleeve the spread should widen the cost, so it is
    # applied with the sign of the position rather than added blindly.
    rate = terms.base_rate_pct + (terms.spread_bps / 100.0) * (1.0 if weight_pct < 0 else 1.0)
    pnl = (weight_pct / 100.0) * (rate / 100.0) * (days / basis) * 100.0
    return pnl, terms


def curve(db: Session, benchmark: Optional[str] = None) -> List[FundingBenchmark]:
    stmt = select(FundingBenchmark).order_by(
        FundingBenchmark.benchmark, FundingBenchmark.effective_date
    )
    if benchmark:
        stmt = stmt.where(FundingBenchmark.benchmark == benchmark)
    return list(db.scalars(stmt))


def upsert_point(
    db: Session,
    *,
    benchmark: str,
    effective_date: date,
    rate_pct: float,
    note: Optional[str] = None,
    actor: Optional[str] = None,
) -> FundingBenchmark:
    existing = db.scalars(
        select(FundingBenchmark).where(
            FundingBenchmark.benchmark == benchmark,
            FundingBenchmark.effective_date == effective_date,
        )
    ).first()
    if existing:
        before = existing.rate_pct
        existing.rate_pct = rate_pct
        existing.note = note
        existing.source = "manual"
        audit.record(
            db,
            category="funding",
            action="update_rate",
            summary=f"{benchmark} @ {effective_date}: {before}% -> {rate_pct}%",
            actor=actor,
        )
        db.flush()
        return existing
    point = FundingBenchmark(
        benchmark=benchmark,
        effective_date=effective_date,
        rate_pct=rate_pct,
        source="manual",
        note=note,
    )
    db.add(point)
    audit.record(
        db,
        category="funding",
        action="add_rate",
        summary=f"{benchmark} @ {effective_date} = {rate_pct}%",
        actor=actor,
    )
    db.flush()
    return point
