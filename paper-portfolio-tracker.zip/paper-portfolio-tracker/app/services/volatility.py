"""
Standalone volatility analytics.

What this measures
------------------
For each active row, the realised volatility of the INSTRUMENT over the
selected positioning / target-analysis window, and the position's standalone
risk contribution:

    instrument_vol   = stdev( daily log returns ) * sqrt(252)     [annualised]
    standalone_vol   = |notional weight| * instrument_vol

`standalone_vol` is what the position would contribute to portfolio volatility
if it were the only position - hence "standalone". Summing it across rows gives
an UNDIVERSIFIED total, which is deliberately labelled as such: it is an upper
bound on portfolio vol (attained only at perfect correlation), not an estimate
of it. Producing a true portfolio vol requires a covariance matrix, which is a
different and much heavier piece of machinery; the sum-of-standalone number is
the honest, cheap answer and is what desks use for a quick sizing sanity check.

Positioning window vs performance window
----------------------------------------
Volatility is computed over the POSITIONING window - "the positions active
during August, measured over August" - while the P&L panels continue to show
QTD and YTD. The two windows never share state. If the positioning window is
shorter than `min_observations`, the window is extended backwards to reach a
statistically usable sample and the extension is reported, rather than
returning a number computed from nine data points as though it were reliable.

Data hygiene
------------
Returns are computed from ACTUAL prints only (the pricing cache never stores
carried-forward values - see app/services/pricing.py). Filling non-trading days
with the previous close would inject zero-return days and bias realised vol
downwards, badly so for instruments with a different holiday calendar from the
US.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Dict, List, Optional, Sequence, Tuple

from sqlalchemy.orm import Session

from app.config import settings
from app.services import pricing

logger = logging.getLogger(__name__)


@dataclass
class VolResult:
    ticker: str
    instrument_vol_pct: Optional[float]      # annualised (or daily) in percent
    observations: int
    window_start: Optional[date]
    window_end: Optional[date]
    annualised: bool = True
    extended: bool = False
    note: Optional[str] = None

    @property
    def reliable(self) -> bool:
        return (
            self.instrument_vol_pct is not None
            and self.observations >= settings.analytics.volatility.min_observations
        )

    def standalone(self, weight_pct: float) -> Optional[float]:
        if self.instrument_vol_pct is None:
            return None
        return abs(weight_pct) / 100.0 * self.instrument_vol_pct


def _stdev(values: Sequence[float]) -> Optional[float]:
    n = len(values)
    if n < 2:
        return None
    mean = sum(values) / n
    var = sum((v - mean) ** 2 for v in values) / (n - 1)  # sample stdev
    return math.sqrt(var)


def compute(
    db: Session,
    ticker: str,
    *,
    window_start: date,
    window_end: date,
    annualise: Optional[bool] = None,
    min_observations: Optional[int] = None,
    allow_extension: bool = True,
) -> VolResult:
    """Realised volatility of one instrument over a window."""
    cfg = settings.analytics.volatility
    annualise = cfg.default_mode == "annualised" if annualise is None else annualise
    min_obs = cfg.min_observations if min_observations is None else min_observations

    if ticker == settings.funding.offset_ticker:
        return VolResult(
            ticker,
            None,
            0,
            window_start,
            window_end,
            annualised=annualise,
            note="Funding sleeve carries no market risk",
        )

    effective_start = window_start
    extended = False

    series = pricing.close_series(db, ticker, effective_start - timedelta(days=5), window_end)
    if allow_extension and len(series) < min_obs + 1:
        # Reach back far enough to collect a usable sample. Calendar days
        # rather than trading days, with slack for weekends and holidays.
        needed_days = int((min_obs + 5) * 1.55) + 10
        effective_start = window_end - timedelta(days=needed_days)
        pricing.ensure_prices(db, [ticker], effective_start, window_end)
        series = pricing.close_series(db, ticker, effective_start, window_end)
        extended = effective_start < window_start

    if len(series) < 2:
        return VolResult(
            ticker,
            None,
            len(series),
            effective_start,
            window_end,
            annualised=annualise,
            extended=extended,
            note="Not enough price history to compute a return series",
        )

    returns: List[float] = []
    for (d0, p0), (d1, p1) in zip(series, series[1:]):
        if p0 and p1 and p0 > 0 and p1 > 0:
            returns.append(math.log(p1 / p0))

    sd = _stdev(returns)
    if sd is None:
        return VolResult(
            ticker,
            None,
            len(returns),
            effective_start,
            window_end,
            annualised=annualise,
            extended=extended,
            note="Return series too short",
        )

    vol = sd * (math.sqrt(cfg.annualisation_factor) if annualise else 1.0) * 100.0

    note = None
    if extended:
        note = (
            f"Positioning window held only a few prints; the sample was extended back to "
            f"{effective_start.isoformat()} to reach {min_obs} observations."
        )
    elif len(returns) < min_obs:
        note = (
            f"Only {len(returns)} observations (minimum {min_obs}) - treat this "
            "number as indicative."
        )

    return VolResult(
        ticker,
        vol,
        len(returns),
        effective_start,
        window_end,
        annualised=annualise,
        extended=extended,
        note=note,
    )


def compute_many(
    db: Session,
    tickers: Sequence[str],
    *,
    window_start: date,
    window_end: date,
    annualise: Optional[bool] = None,
    lookback_days: Optional[int] = None,
) -> Dict[str, VolResult]:
    """
    Volatility for a set of instruments over the same window.

    `lookback_days` overrides the window start with a rolling lookback, which
    is what the "Lookback" control in the analytics drawer sets.
    """
    if lookback_days:
        window_start = window_end - timedelta(days=int(lookback_days * 1.5))

    tickers = [t for t in dict.fromkeys(tickers) if t]
    if tickers:
        pricing.ensure_prices(db, tickers, window_start - timedelta(days=30), window_end)

    return {
        t: compute(db, t, window_start=window_start, window_end=window_end, annualise=annualise)
        for t in tickers
    }


def undiversified_total(
    weights: Dict[str, float], vols: Dict[str, VolResult]
) -> Dict[str, float]:
    """
    Sum of standalone contributions plus the simple diversification-free
    aggregate. Returned as a dict so the UI can label it honestly.
    """
    total = 0.0
    covered = 0
    uncovered: List[str] = []
    for ticker, weight in weights.items():
        result = vols.get(ticker)
        contribution = result.standalone(weight) if result else None
        if contribution is None:
            if abs(weight) > 1e-9 and ticker != settings.funding.offset_ticker:
                uncovered.append(ticker)
            continue
        total += contribution
        covered += 1
    return {
        "sum_of_standalone_vol_pct": total,
        "rows_covered": covered,
        "rows_uncovered": len(uncovered),
        "uncovered_tickers": uncovered,  # type: ignore[dict-item]
    }
