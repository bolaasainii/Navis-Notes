"""
Live / Offline data mode: persistence, switching and book diagnostics.

The mode itself lives in `app/bloomberg/__init__.py`. This module is the thin
layer that persists the operator's choice, audits it, and answers the question
the UI actually needs to ask: *given what is in this book, is switching modes
going to produce a number anyone should trust?*

The important subtlety
----------------------
Switching modes is safe for PRICES - the caches are scoped by provider, so each
mode reads only its own data. It is NOT automatically safe for a BOOK, because
a trade's execution level is a historical fact recorded at booking time and is
never rewritten. A book whose trades were priced offline, viewed in live mode,
would compare synthetic entry levels against real marks. That is meaningless,
so it is detected and warned about rather than silently rendered.
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.bloomberg import DataMode, current_mode, set_mode, status
from app.models import AppState, Portfolio, Trade
from app.services import audit

logger = logging.getLogger(__name__)

STATE_KEY = "data_mode"


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------
def read_persisted(db: Session) -> Optional[str]:
    row = db.get(AppState, STATE_KEY)
    return row.value if row else None


def persist(db: Session, mode: str, *, actor: Optional[str] = None) -> None:
    row = db.get(AppState, STATE_KEY)
    if row is None:
        db.add(AppState(key=STATE_KEY, value=mode, updated_by=actor))
    else:
        row.value = mode
        row.updated_by = actor
    db.flush()


def switch(db: Session, mode: str, *, actor: Optional[str] = None) -> dict:
    """
    Change data mode, persist it, and audit it.

    Refuses to go live if no Terminal is reachable, returning the reason rather
    than raising - the UI shows it next to the toggle.
    """
    before = current_mode().value
    result = set_mode(mode)

    if result["ok"]:
        persist(db, result["mode"], actor=actor)
        audit.record(
            db,
            category="data_mode",
            action="switch",
            summary=f"Data mode changed from {before} to {result['mode']}",
            actor=actor,
            detail={"from": before, "to": result["mode"]},
        )
    else:
        audit.record(
            db,
            category="data_mode",
            action="switch_refused",
            summary=f"Switch to {mode} refused: {result['reason']}",
            actor=actor,
            detail=result,
        )

    payload = status()
    payload.update(
        {
            "switch_ok": result["ok"],
            "switch_reason": result["reason"],
            "previous_mode": before,
        }
    )
    return payload


def initialise_from_db(db: Session) -> dict:
    """Called once at startup, after the database exists."""
    from app.bloomberg import initialise

    preferred = read_persisted(db)
    payload = initialise(preferred)
    # Keep the stored value honest: if the persisted preference could not be
    # honoured (Terminal gone), record what we actually landed on.
    if preferred != payload["mode"]:
        persist(db, payload["mode"], actor="startup")
        if preferred:
            logger.warning(
                "Persisted data mode %r could not be honoured; running %s. %s",
                preferred,
                payload["mode"],
                payload.get("live_unavailable_reason") or "",
            )
    return payload


# ---------------------------------------------------------------------------
# Book diagnostics
# ---------------------------------------------------------------------------
def book_provider_mix(db: Session, portfolio: Optional[Portfolio] = None) -> Dict[str, object]:
    """
    Which providers priced the trades in this book (or across all books)?

    Used to warn when a book is being viewed in a mode different from the one
    its trades were booked in.
    """
    stmt = select(Trade.price_provider, func.count(Trade.id)).where(
        Trade.is_funding_offset.is_(False), Trade.is_void.is_(False)
    )
    if portfolio is not None:
        stmt = stmt.where(Trade.portfolio_pk == portfolio.id)
    counts = {
        (provider or "unknown"): count
        for provider, count in db.execute(stmt.group_by(Trade.price_provider))
    }

    active = status()["provider"]
    foreign = {p: c for p, c in counts.items() if p not in (active, "unknown")}
    return {
        "active_provider": active,
        "mode": current_mode().value,
        "counts_by_provider": counts,
        "trades_priced_elsewhere": sum(foreign.values()),
        "foreign_providers": sorted(foreign),
        "mixed": bool(foreign) and bool(counts.get(active)),
        "warning": _mix_warning(active, counts, foreign),
    }


def _mix_warning(active: str, counts: Dict[str, int], foreign: Dict[str, int]) -> Optional[str]:
    if not foreign:
        return None
    total_foreign = sum(foreign.values())
    other = ", ".join(sorted(foreign))
    if not counts.get(active):
        return (
            f"Every trade in this book was priced by '{other}', but the application is "
            f"currently in '{active}' mode. Entry levels and current marks come from "
            "different sources, so the P&L shown is not meaningful. Switch back, or "
            "start a fresh book for this mode."
        )
    return (
        f"{total_foreign} trade(s) in this book were priced by '{other}' while the "
        f"application is in '{active}' mode. Those entry levels are historical fact and "
        "are never rewritten, so their P&L mixes sources. They are tagged in Trade History."
    )
