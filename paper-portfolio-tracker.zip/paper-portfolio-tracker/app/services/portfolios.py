"""Portfolio lifecycle: create, clone, archive, browse."""

from __future__ import annotations

import logging
from datetime import date, datetime
from typing import List, Optional

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models import (
    Portfolio,
    PortfolioSnapshot,
    PortfolioSnapshotRow,
    PortfolioStatus,
    Trade,
)
from app.services import audit, positions

logger = logging.getLogger(__name__)


class PortfolioError(ValueError):
    pass


def list_portfolios(db: Session, *, include_archived: bool = False) -> List[Portfolio]:
    stmt = select(Portfolio)
    if not include_archived:
        stmt = stmt.where(Portfolio.status == PortfolioStatus.ACTIVE)
    return list(db.scalars(stmt.order_by(Portfolio.portfolio_id.asc())))


def get(db: Session, portfolio_id: str) -> Optional[Portfolio]:
    return db.scalars(select(Portfolio).where(Portfolio.portfolio_id == portfolio_id)).first()


def require(db: Session, portfolio_id: str) -> Portfolio:
    p = get(db, portfolio_id)
    if p is None:
        raise PortfolioError(f"Portfolio {portfolio_id!r} does not exist")
    return p


def create(
    db: Session,
    *,
    portfolio_id: str,
    name: str,
    description: Optional[str] = None,
    owner: Optional[str] = None,
    inception_date: Optional[date] = None,
    base_currency: str = "USD",
    funding_benchmark: Optional[str] = None,
    funding_spread_bps: Optional[float] = None,
    notes: Optional[str] = None,
    actor: Optional[str] = None,
) -> Portfolio:
    portfolio_id = (portfolio_id or "").strip()
    if not portfolio_id:
        raise PortfolioError("A portfolio ID is required, e.g. 'Navi-S1'")
    if get(db, portfolio_id) is not None:
        raise PortfolioError(f"Portfolio ID {portfolio_id!r} is already in use")
    if not (name or "").strip():
        raise PortfolioError("A portfolio name is required")

    p = Portfolio(
        portfolio_id=portfolio_id,
        name=name.strip(),
        description=description,
        owner=owner or actor,
        inception_date=inception_date,
        base_currency=base_currency,
        funding_benchmark=funding_benchmark,
        funding_spread_bps=funding_spread_bps,
        notes=notes,
        status=PortfolioStatus.ACTIVE,
    )
    db.add(p)
    db.flush()
    audit.record(
        db,
        category="portfolio",
        action="create",
        summary=f"Created portfolio {portfolio_id} - {name}",
        portfolio_pk=p.id,
        entity_type="portfolio",
        entity_id=p.id,
        actor=actor,
    )
    return p


def clone(
    db: Session,
    source: Portfolio,
    *,
    new_portfolio_id: str,
    new_name: Optional[str] = None,
    copy_trades: bool = True,
    copy_snapshots: bool = True,
    actor: Optional[str] = None,
) -> Portfolio:
    """
    Duplicate a book. Trade history is copied verbatim, preserving execution
    levels and their provenance, so the clone reproduces the original's P&L
    exactly rather than re-pricing against today's data.
    """
    if get(db, new_portfolio_id) is not None:
        raise PortfolioError(f"Portfolio ID {new_portfolio_id!r} is already in use")

    target = Portfolio(
        portfolio_id=new_portfolio_id.strip(),
        name=(new_name or f"{source.name} (copy)").strip(),
        description=source.description,
        owner=actor or source.owner,
        inception_date=source.inception_date,
        base_currency=source.base_currency,
        funding_benchmark=source.funding_benchmark,
        funding_spread_bps=source.funding_spread_bps,
        notes=source.notes,
        cloned_from_id=source.id,
        status=PortfolioStatus.ACTIVE,
    )
    db.add(target)
    db.flush()

    copied_trades = 0
    if copy_trades:
        for t in db.scalars(select(Trade).where(Trade.portfolio_pk == source.id)):
            db.add(
                Trade(
                    portfolio_pk=target.id,
                    instrument_id=t.instrument_id,
                    bbg_ticker=t.bbg_ticker,
                    trade_date=t.trade_date,
                    weight_delta_pct=t.weight_delta_pct,
                    execution_type=t.execution_type,
                    execution_level=t.execution_level,
                    level_source=t.level_source,
                    price_field_used=t.price_field_used,
                    price_observation_date=t.price_observation_date,
                    price_fallback_days=t.price_fallback_days,
                    price_fallback_reason=t.price_fallback_reason,
                    price_from_live_request=t.price_from_live_request,
                    price_provider=t.price_provider,
                    source=t.source,
                    is_funding_offset=t.is_funding_offset,
                    is_void=t.is_void,
                    notes=t.notes,
                    entered_by=actor or t.entered_by,
                )
            )
            copied_trades += 1

    copied_snapshots = 0
    if copy_snapshots:
        for s in db.scalars(
            select(PortfolioSnapshot).where(PortfolioSnapshot.portfolio_pk == source.id)
        ):
            new_snap = PortfolioSnapshot(
                portfolio_pk=target.id,
                snapshot_date=s.snapshot_date,
                label=s.label,
                is_current=s.is_current,
                notes=s.notes,
                created_by=actor,
            )
            db.add(new_snap)
            db.flush()
            for r in s.rows:
                db.add(
                    PortfolioSnapshotRow(
                        snapshot_id=new_snap.id,
                        instrument_id=r.instrument_id,
                        bbg_ticker=r.bbg_ticker,
                        target_weight_pct=r.target_weight_pct,
                        execution_type=r.execution_type,
                        reference_level=r.reference_level,
                        level_source=r.level_source,
                        price_observation_date=r.price_observation_date,
                        is_funding_offset=r.is_funding_offset,
                        notes=r.notes,
                    )
                )
            copied_snapshots += 1

    db.flush()
    if copy_trades:
        positions.rebuild_lots(db, target, actor=actor)

    audit.record(
        db,
        category="portfolio",
        action="clone",
        summary=(
            f"Cloned {source.portfolio_id} -> {target.portfolio_id} "
            f"({copied_trades} trades, {copied_snapshots} snapshots)"
        ),
        portfolio_pk=target.id,
        entity_type="portfolio",
        entity_id=target.id,
        actor=actor,
    )
    return target


def archive(db: Session, portfolio: Portfolio, *, actor: Optional[str] = None) -> Portfolio:
    """Archive without deleting anything. History stays fully intact and queryable."""
    portfolio.status = PortfolioStatus.ARCHIVED
    portfolio.archived_at = datetime.utcnow()
    db.flush()
    audit.record(
        db,
        category="portfolio",
        action="archive",
        summary=f"Archived portfolio {portfolio.portfolio_id}",
        portfolio_pk=portfolio.id,
        actor=actor,
    )
    return portfolio


def unarchive(db: Session, portfolio: Portfolio, *, actor: Optional[str] = None) -> Portfolio:
    portfolio.status = PortfolioStatus.ACTIVE
    portfolio.archived_at = None
    db.flush()
    audit.record(
        db,
        category="portfolio",
        action="unarchive",
        summary=f"Reactivated portfolio {portfolio.portfolio_id}",
        portfolio_pk=portfolio.id,
        actor=actor,
    )
    return portfolio


def summary(db: Session, portfolio: Portfolio) -> dict:
    trade_count = db.scalar(
        select(func.count(Trade.id)).where(
            Trade.portfolio_pk == portfolio.id, Trade.is_funding_offset.is_(False)
        )
    )
    snapshot_count = db.scalar(
        select(func.count(PortfolioSnapshot.id)).where(
            PortfolioSnapshot.portfolio_pk == portfolio.id
        )
    )
    return {
        "portfolio_id": portfolio.portfolio_id,
        "name": portfolio.name,
        "status": portfolio.status.value,
        "owner": portfolio.owner,
        "description": portfolio.description,
        "base_currency": portfolio.base_currency,
        "inception_date": portfolio.inception_date,
        "first_trade_date": positions.first_trade_date(db, portfolio),
        "last_trade_date": positions.last_trade_date(db, portfolio),
        "trade_count": trade_count or 0,
        "snapshot_count": snapshot_count or 0,
        "cloned_from_id": portfolio.cloned_from_id,
        "notes": portfolio.notes,
    }
