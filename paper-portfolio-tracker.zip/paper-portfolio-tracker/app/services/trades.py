"""
Trade entry and the recalculation cascade.

Saving a trade is not just an INSERT. The documented behaviour is:

    1. resolve the execution level (Bloomberg or manual) and record its provenance
    2. write the dated trade event
    3. rebuild the funding sleeve so the book still nets to 0%
    4. rebuild FIFO lot history
    5. recompute the daily P&L series from the trade date forward
    6. write an audit entry

`save_trade` does all six in one transaction so the book is never observable
in a half-updated state.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date, datetime
from typing import List, Optional

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import (
    ExecutionType,
    InstrumentMaster,
    LevelSource,
    Portfolio,
    Trade,
    TradeSource,
)
from app.bloomberg import get_provider
from app.services import audit, instruments, pnl, positions, pricing

logger = logging.getLogger(__name__)


class TradeError(ValueError):
    pass


@dataclass
class TradeRequest:
    portfolio_id: str
    bbg_ticker: str
    trade_date: date
    weight_pct: float
    execution_type: ExecutionType
    custom_level: Optional[float] = None
    notes: Optional[str] = None
    actor: Optional[str] = None


def parse_weight(raw: str | float | int) -> float:
    """
    Interpret a user-entered notional weight.

    Per the specification, `4` means 4.00%. A trailing '%' is tolerated, as are
    commas and a leading '+'. Negative values are valid and mean a short.
    """
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        raise TradeError("A notional weight is required")
    if isinstance(raw, (int, float)):
        return float(raw)
    cleaned = str(raw).strip().replace(",", "").replace("%", "").lstrip("+")
    try:
        return float(cleaned)
    except ValueError as exc:
        raise TradeError(f"{raw!r} is not a valid notional weight") from exc


def preview_level(
    db: Session,
    *,
    bbg_ticker: str,
    trade_date: date,
    execution_type: ExecutionType,
    custom_level: Optional[float] = None,
) -> dict:
    """
    Resolve the level for the trade-entry form without writing anything.

    This is what populates the level box next to the execution-type dropdown
    the moment a user picks an instrument and a date.
    """
    resolved = pricing.resolve_execution_level(
        db,
        ticker=bbg_ticker,
        trade_date=trade_date,
        execution_type=execution_type,
        custom_level=custom_level,
    )
    return {
        "level": resolved.level,
        "source": resolved.source.value,
        "field_used": resolved.field_used,
        "observation_date": resolved.observation_date,
        "fallback_days": resolved.fallback_days,
        "is_stale": resolved.is_stale,
        "editable": execution_type == ExecutionType.CUSTOM,
        "reason": resolved.reason,
        "ok": resolved.ok,
        # Was this level obtained from Bloomberg just now, or served from the
        # local cache? Shown next to the level box so the user always knows.
        "from_live_request": resolved.from_live_request,
        "provider": resolved.provider,
        "live_provider": get_provider().is_live,
    }


def save_trade(
    db: Session,
    request: TradeRequest,
    *,
    recompute: bool = True,
) -> Trade:
    """Create one manually-entered trade and run the full recalculation cascade."""
    from app.services import portfolios  # local import avoids a cycle

    portfolio = portfolios.require(db, request.portfolio_id)

    instrument, messages = instruments.resolve_ticker(db, request.bbg_ticker)
    if instrument is None:
        raise TradeError(
            f"Could not resolve instrument {request.bbg_ticker!r}: "
            + "; ".join(messages or ["not found"])
        )

    if abs(request.weight_pct) < 1e-9:
        raise TradeError("A trade must have a non-zero notional weight")

    if request.execution_type == ExecutionType.CUSTOM and request.custom_level is None:
        raise TradeError("A Custom execution requires a level")

    resolved = pricing.resolve_execution_level(
        db,
        ticker=instrument.bbg_ticker,
        trade_date=request.trade_date,
        execution_type=request.execution_type,
        custom_level=request.custom_level,
    )
    if not resolved.ok:
        raise TradeError(
            resolved.reason
            or f"Could not determine an execution level for {instrument.bbg_ticker}"
        )

    pricing.log_fallback(
        db,
        resolved,
        ticker=instrument.bbg_ticker,
        trade_date=request.trade_date,
        portfolio_pk=portfolio.id,
        actor=request.actor,
    )

    trade = Trade(
        portfolio_pk=portfolio.id,
        instrument_id=instrument.id,
        bbg_ticker=instrument.bbg_ticker,
        trade_date=request.trade_date,
        weight_delta_pct=request.weight_pct,
        execution_type=request.execution_type,
        execution_level=resolved.level,
        level_source=resolved.source,
        price_field_used=resolved.field_used,
        price_observation_date=resolved.observation_date,
        price_fallback_days=resolved.fallback_days,
        price_fallback_reason=resolved.reason,
        price_from_live_request=resolved.from_live_request,
        price_provider=resolved.provider,
        source=TradeSource.MANUAL_ENTRY,
        notes=request.notes,
        entered_by=request.actor,
    )
    db.add(trade)
    db.flush()

    audit.record(
        db,
        category="trade",
        action="create",
        summary=(
            f"{request.weight_pct:+.2f}% {instrument.bbg_ticker} on "
            f"{request.trade_date.isoformat()} @ {resolved.level} "
            f"({request.execution_type.value}, {resolved.source.value})"
        ),
        portfolio_pk=portfolio.id,
        entity_type="trade",
        entity_id=trade.id,
        bbg_ticker=instrument.bbg_ticker,
        actor=request.actor,
        detail={
            "weight_pct": request.weight_pct,
            "execution_type": request.execution_type.value,
            "level": resolved.level,
            "level_source": resolved.source.value,
            "field_used": resolved.field_used,
            "observation_date": resolved.observation_date,
            "fallback_days": resolved.fallback_days,
            "from_live_request": resolved.from_live_request,
            "price_provider": resolved.provider,
            "resolution_messages": messages,
        },
    )

    if recompute:
        recalculate(db, portfolio, actor=request.actor)

    return trade


@dataclass
class TradeEdit:
    """
    Fields that may be amended on an existing trade.

    `None` means "leave alone", which is why weight and date are Optional even
    though they are mandatory on the trade itself.
    """

    trade_date: Optional[date] = None
    weight_pct: Optional[float] = None
    execution_type: Optional[ExecutionType] = None
    custom_level: Optional[float] = None
    notes: Optional[str] = None
    reason: Optional[str] = None
    actor: Optional[str] = None


def edit_trade(
    db: Session, trade: Trade, edit: TradeEdit, *, recompute: bool = True
) -> tuple[Trade, List[str]]:
    """
    Amend an existing trade in place and rerun the full cascade.

    Why an edit rather than void-and-rebook: voiding loses the thread. The trade
    keeps its id, so anything referencing it - the audit trail, an import batch,
    a snapshot comparison - still resolves, and the change is recorded as a
    before/after diff rather than as an unexplained disappearance followed by an
    unexplained appearance.

    What gets re-derived
    --------------------
    Changing the date or the execution type invalidates the execution level, so
    it is re-resolved through exactly the same path `save_trade` uses - same
    fallback rules, same provider, same audit of what was used. An execution
    level is never carried across a date change: that would silently assert a
    price was observed on a day it was not.

    A voided trade cannot be edited. Un-void it first; the two actions stay
    distinct so the audit trail reads honestly.
    """
    from app.services import portfolios  # local import avoids a cycle

    if trade.is_void:
        raise TradeError(
            "This trade is voided. Restore it before editing, so the audit trail "
            "shows the void and the amendment as separate decisions."
        )

    portfolio = db.get(Portfolio, trade.portfolio_pk)
    if portfolio is None:
        raise TradeError("The trade's portfolio no longer exists")

    before = {
        "trade_date": trade.trade_date.isoformat(),
        "weight_delta_pct": trade.weight_delta_pct,
        "execution_type": trade.execution_type.value,
        "execution_level": trade.execution_level,
        "level_source": trade.level_source.value if trade.level_source else None,
        "notes": trade.notes,
    }

    new_date = edit.trade_date or trade.trade_date
    new_weight = trade.weight_delta_pct if edit.weight_pct is None else float(edit.weight_pct)
    new_exec = edit.execution_type or trade.execution_type

    messages: List[str] = []

    if abs(new_weight) < 1e-9:
        raise TradeError(
            "A trade must have a non-zero notional weight. To remove a position, "
            "book an offsetting trade or void this one."
        )
    # A level is only demanded when the trade is BECOMING Custom. If it already
    # was Custom, the level the user typed is still the best answer - there is no
    # Bloomberg price to fall back to, that is what Custom means - so it carries
    # over, and the caller is told it did rather than being made to retype it.
    if (
        new_exec == ExecutionType.CUSTOM
        and edit.custom_level is None
        and trade.execution_type != ExecutionType.CUSTOM
    ):
        raise TradeError(
            "Switching to a Custom execution requires a level, because there is no "
            "official print to resolve."
        )

    reprice = (
        new_date != trade.trade_date
        or new_exec != trade.execution_type
        or edit.custom_level is not None
    )

    if reprice:
        custom = edit.custom_level
        if new_exec == ExecutionType.CUSTOM and custom is None:
            custom = trade.execution_level
            if new_date != trade.trade_date:
                messages.append(
                    f"Kept the custom level {custom} you had entered. It was supplied for "
                    f"{trade.trade_date.isoformat()} — re-check it against "
                    f"{new_date.isoformat()} if the market moved."
                )
        resolved = pricing.resolve_execution_level(
            db,
            ticker=trade.bbg_ticker,
            trade_date=new_date,
            execution_type=new_exec,
            custom_level=custom,
        )
        if not resolved.ok:
            raise TradeError(
                resolved.reason
                or f"Could not determine an execution level for {trade.bbg_ticker} on {new_date}"
            )
        pricing.log_fallback(
            db,
            resolved,
            ticker=trade.bbg_ticker,
            trade_date=new_date,
            portfolio_pk=portfolio.id,
            actor=edit.actor,
        )
        trade.execution_level = resolved.level
        trade.level_source = resolved.source
        trade.price_field_used = resolved.field_used
        trade.price_observation_date = resolved.observation_date
        trade.price_fallback_days = resolved.fallback_days
        trade.price_fallback_reason = resolved.reason
        trade.price_from_live_request = resolved.from_live_request
        trade.price_provider = resolved.provider
        if resolved.fallback_days:
            messages.append(
                f"{new_date.isoformat()} had no print; used the official close from "
                f"{resolved.observation_date} ({resolved.fallback_days}d earlier)."
            )

    trade.trade_date = new_date
    trade.weight_delta_pct = new_weight
    trade.execution_type = new_exec
    if edit.notes is not None:
        trade.notes = edit.notes
    trade.edited_at = datetime.utcnow()
    trade.edited_by = edit.actor
    db.flush()

    after = {
        "trade_date": trade.trade_date.isoformat(),
        "weight_delta_pct": trade.weight_delta_pct,
        "execution_type": trade.execution_type.value,
        "execution_level": trade.execution_level,
        "level_source": trade.level_source.value if trade.level_source else None,
        "notes": trade.notes,
    }
    changed = {k: {"from": before[k], "to": after[k]} for k in before if before[k] != after[k]}

    audit.record(
        db,
        category="trade",
        action="edit",
        summary=(
            f"Edited trade {trade.id} ({trade.bbg_ticker}): "
            + (", ".join(f"{k} {v['from']} -> {v['to']}" for k, v in changed.items()) or "no change")
            + (f" [{edit.reason}]" if edit.reason else "")
        ),
        portfolio_pk=trade.portfolio_pk,
        entity_type="trade",
        entity_id=trade.id,
        bbg_ticker=trade.bbg_ticker,
        actor=edit.actor,
        detail={"changed": changed, "reason": edit.reason, "repriced": reprice},
    )

    if recompute:
        recalculate(db, portfolio, actor=edit.actor)

    return trade, messages


def void_trade(
    db: Session, trade: Trade, *, reason: str, actor: Optional[str] = None
) -> Trade:
    """
    Void rather than delete.

    The row stays in the table with `is_void=True` so the audit trail is
    complete; every calculation ignores voided trades.
    """
    from app.services import portfolios  # local import avoids a cycle

    trade.is_void = True
    trade.void_reason = reason
    db.flush()

    portfolio = db.get(Portfolio, trade.portfolio_pk)
    audit.record(
        db,
        category="trade",
        action="void",
        summary=f"Voided trade {trade.id} ({trade.bbg_ticker}): {reason}",
        portfolio_pk=trade.portfolio_pk,
        entity_type="trade",
        entity_id=trade.id,
        bbg_ticker=trade.bbg_ticker,
        actor=actor,
    )
    if portfolio:
        recalculate(db, portfolio, actor=actor)
    return trade



def restore_trade(db: Session, trade: Trade, *, actor: Optional[str] = None) -> Trade:
    """
    Reverse a void.

    Deliberately a separate action from `edit_trade`: "this trade should not
    have been voided" and "this trade's details were wrong" are different
    claims, and the audit log should not conflate them.
    """
    from app.services import portfolios  # local import avoids a cycle

    previous = trade.void_reason
    trade.is_void = False
    trade.void_reason = None
    db.flush()

    audit.record(
        db,
        category="trade",
        action="restore",
        summary=f"Restored trade {trade.id} ({trade.bbg_ticker}), previously voided: {previous}",
        portfolio_pk=trade.portfolio_pk,
        entity_type="trade",
        entity_id=trade.id,
        bbg_ticker=trade.bbg_ticker,
        actor=actor,
        detail={"previous_void_reason": previous},
    )

    portfolio = db.get(Portfolio, trade.portfolio_pk)
    if portfolio is not None:
        recalculate(db, portfolio, actor=actor)
    return trade

def recalculate(db: Session, portfolio: Portfolio, *, actor: Optional[str] = None) -> None:
    """Steps 3-5 of the cascade. Safe and cheap to re-run at any time."""
    positions.rebuild_funding_offset(db, portfolio, actor=actor)
    positions.rebuild_lots(db, portfolio, actor=actor)
    pnl.compute_daily_pnl(db, portfolio)


def history(
    db: Session,
    portfolio: Portfolio,
    *,
    include_offset: bool = False,
    include_void: bool = True,
    limit: Optional[int] = None,
) -> List[Trade]:
    stmt = select(Trade).where(Trade.portfolio_pk == portfolio.id)
    if not include_offset:
        stmt = stmt.where(Trade.is_funding_offset.is_(False))
    if not include_void:
        stmt = stmt.where(Trade.is_void.is_(False))
    stmt = stmt.order_by(Trade.trade_date.desc(), Trade.id.desc())
    if limit:
        stmt = stmt.limit(limit)
    return list(db.scalars(stmt))
