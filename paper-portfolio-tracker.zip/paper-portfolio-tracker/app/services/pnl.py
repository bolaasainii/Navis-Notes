"""
P&L engine.

Methodology
-----------
Total return from entry level, computed as a chained DAILY contribution series
in portfolio percent. For instrument i on calendar day d:

    carry_pnl(i,d) = W_open(i,d) * ( P(i,d) / P(i,d-1) - 1 )
    trade_pnl(i,d) = SUM over trades on d of  dW * ( P(i,d) / L - 1 )
    total(i,d)     = carry_pnl + trade_pnl

where
    W_open(i,d) = net weight carried into day d (all trades strictly before d)
    P(i,d)      = official close on d, or the last prior official print
    L           = the trade's execution level

Why this shape
--------------
It makes every execution type fall out correctly with no special cases:

  * `Mkt Close` -> L == P(i,d), so trade_pnl is exactly zero on the trade date.
    A trade done on the close contributes nothing that day. Correct.
  * `Mkt Open`  -> L == the open, so the position earns open-to-close on day
    one. Correct.
  * `Custom`    -> the position earns custom-level-to-close on day one, which
    is precisely what a manually marked fill should do.

It also handles adds, trims, exits and reversals with no branching, because a
trade is only ever a delta applied against that day's close.

Chaining daily contributions rather than differencing a mark-to-market gives
period P&L that is additive across instruments and across time, which is what
makes MTD/QTD/YTD reconcile with the sum of their daily parts.

Realised vs unrealised
----------------------
The daily series is the authoritative total. The FIFO lot engine
(app/services/positions.py) independently produces the realised/unrealised
split for reporting. `reconcile()` checks the two agree; tests/test_pnl.py
asserts it.

Funding
-------
The `USD_CASH_OFFSET` sleeve has no price, so it takes no carry or trade P&L.
It accrues interest every CALENDAR day (financing does not stop at the
weekend), booked into `funding_pnl_pct`.

Positioning window vs performance window
----------------------------------------
These are different things and the API keeps them apart. `period_summary()`
takes a performance window and answers "what did the book earn?".
`app/services/exposure.py` and `app/services/volatility.py` take a positioning
window and answer "what was the book holding, and how risky was it?". A user
looking at August targets still sees QTD and YTD P&L.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.config import settings
from app.models import Portfolio, PnlSnapshot, Trade
from app.services import funding, positions, pricing

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Period helpers
# ---------------------------------------------------------------------------
def month_start(d: date) -> date:
    return d.replace(day=1)


def quarter_start(d: date) -> date:
    return date(d.year, 3 * ((d.month - 1) // 3) + 1, 1)


def year_start(d: date) -> date:
    return date(d.year, 1, 1)


PERIOD_KEYS = ("today", "mtd", "qtd", "ytd", "itd")


def period_bounds(
    as_of: date, inception: Optional[date]
) -> Dict[str, Tuple[Optional[date], date]]:
    """
    Inclusive (start, end) for each standard period.

    Note MTD/QTD/YTD start on the FIRST day of the period, not the day after.
    Because the daily series only produces P&L on days a price actually moved,
    including the first calendar day of the month is harmless and avoids the
    off-by-one that bites when the 1st is a trading day.
    """
    return {
        "today": (as_of, as_of),
        "mtd": (month_start(as_of), as_of),
        "qtd": (quarter_start(as_of), as_of),
        "ytd": (year_start(as_of), as_of),
        "itd": (inception, as_of),
    }


# ---------------------------------------------------------------------------
# Computation
# ---------------------------------------------------------------------------
@dataclass
class DailyRow:
    pnl_date: date
    ticker: str
    opening_weight: float
    closing_weight: float
    prior_level: Optional[float]
    close_level: Optional[float]
    carry: float = 0.0
    trade: float = 0.0
    funding_: float = 0.0
    is_offset: bool = False
    price_stale: bool = False

    @property
    def total(self) -> float:
        return self.carry + self.trade + self.funding_


def compute_daily_pnl(
    db: Session,
    portfolio: Portfolio,
    *,
    start: Optional[date] = None,
    end: Optional[date] = None,
    persist: bool = True,
) -> List[DailyRow]:
    """
    Build the daily contribution series for a portfolio.

    Iterates every CALENDAR day. On a day with no new print the carried price
    is unchanged, so market P&L is naturally zero and only funding accrues -
    which is exactly the desired behaviour over weekends and holidays.
    """
    inception = positions.first_trade_date(db, portfolio)
    if inception is None:
        return []

    start = start or inception
    end = end or date.today()
    if end < start:
        return []

    trades = positions.all_trades(db, portfolio, through=end)
    if not trades:
        return []

    offset_ticker = settings.funding.offset_ticker
    market_tickers = sorted({t.bbg_ticker for t in trades if t.bbg_ticker != offset_ticker})

    # Warm the price cache once for the whole window.
    pricing.ensure_prices(db, market_tickers, inception - timedelta(days=30), end)

    # trades_by_day[date][ticker] -> list of (delta, level)
    trades_by_day: Dict[date, Dict[str, List[Tuple[float, Optional[float]]]]] = defaultdict(
        lambda: defaultdict(list)
    )
    for t in trades:
        trades_by_day[t.trade_date][t.bbg_ticker].append(
            (float(t.weight_delta_pct or 0.0), t.execution_level)
        )

    # Pre-load the full price history into memory: one pass per ticker beats
    # a per-day query, and the dataset is small.
    price_map: Dict[str, List[Tuple[date, float]]] = {
        ticker: pricing.close_series(db, ticker, inception - timedelta(days=30), end)
        for ticker in market_tickers
    }

    def price_at(ticker: str, on: date) -> Tuple[Optional[float], bool]:
        """(level, is_stale) using the last print at or before `on`."""
        series = price_map.get(ticker) or []
        chosen: Optional[Tuple[date, float]] = None
        for obs_date, px in series:
            if obs_date <= on:
                chosen = (obs_date, px)
            else:
                break
        if chosen is None:
            return None, True
        return chosen[1], chosen[0] != on

    rows: List[DailyRow] = []
    running_weight: Dict[str, float] = defaultdict(float)

    day = inception
    while day <= end:
        touched = set(running_weight) | set(trades_by_day.get(day, {}))
        prev_day = day - timedelta(days=1)

        for ticker in sorted(touched):
            opening = running_weight.get(ticker, 0.0)
            day_trades = trades_by_day.get(day, {}).get(ticker, [])
            delta_sum = sum(d for d, _ in day_trades)
            closing = opening + delta_sum

            if abs(opening) < 1e-12 and abs(closing) < 1e-12 and not day_trades:
                continue

            row = DailyRow(
                pnl_date=day,
                ticker=ticker,
                opening_weight=opening,
                closing_weight=closing,
                prior_level=None,
                close_level=None,
                is_offset=(ticker == offset_ticker),
            )

            if ticker == offset_ticker:
                # Financing accrues on the weight carried into the day, every
                # calendar day. A same-day change in the sleeve starts
                # accruing tomorrow, matching how a cash balance actually works.
                accrual, terms = funding.accrual_pct(
                    db,
                    portfolio=portfolio,
                    weight_pct=opening,
                    from_date=prev_day,
                    to_date=day,
                )
                row.funding_ = accrual
            else:
                close_px, stale = price_at(ticker, day)
                prior_px, _ = price_at(ticker, prev_day)
                row.close_level = close_px
                row.prior_level = prior_px
                row.price_stale = stale

                if close_px is not None and prior_px not in (None, 0):
                    row.carry = opening * (close_px / prior_px - 1.0)
                if close_px is not None:
                    for delta, level in day_trades:
                        if level in (None, 0):
                            continue
                        row.trade += delta * (close_px / level - 1.0)

            running_weight[ticker] = closing
            rows.append(row)

        day += timedelta(days=1)

    if persist:
        db.execute(
            delete(PnlSnapshot).where(
                PnlSnapshot.portfolio_pk == portfolio.id,
                PnlSnapshot.pnl_date >= start,
                PnlSnapshot.pnl_date <= end,
            )
        )
        for r in rows:
            if r.pnl_date < start:
                continue
            db.add(
                PnlSnapshot(
                    portfolio_pk=portfolio.id,
                    pnl_date=r.pnl_date,
                    bbg_ticker=r.ticker,
                    opening_weight_pct=r.opening_weight,
                    closing_weight_pct=r.closing_weight,
                    prior_level=r.prior_level,
                    close_level=r.close_level,
                    carry_pnl_pct=r.carry,
                    trade_pnl_pct=r.trade,
                    funding_pnl_pct=r.funding_,
                    total_pnl_pct=r.total,
                    is_funding_offset=r.is_offset,
                    price_is_stale=r.price_stale,
                )
            )
        db.flush()

    return [r for r in rows if r.pnl_date >= start]


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------
def _stored_rows(
    db: Session,
    portfolio: Portfolio,
    start: Optional[date],
    end: date,
    *,
    include_offset: bool = True,
) -> List[PnlSnapshot]:
    stmt = select(PnlSnapshot).where(
        PnlSnapshot.portfolio_pk == portfolio.id, PnlSnapshot.pnl_date <= end
    )
    if start is not None:
        stmt = stmt.where(PnlSnapshot.pnl_date >= start)
    if not include_offset:
        stmt = stmt.where(PnlSnapshot.is_funding_offset.is_(False))
    return list(db.scalars(stmt.order_by(PnlSnapshot.pnl_date.asc())))


def period_total(
    db: Session,
    portfolio: Portfolio,
    start: Optional[date],
    end: date,
    *,
    include_offset: bool = True,
) -> float:
    return sum(r.total_pnl_pct for r in _stored_rows(db, portfolio, start, end, include_offset=include_offset))


def period_summary(
    db: Session,
    portfolio: Portfolio,
    as_of: date,
    *,
    include_offset: bool = True,
    custom: Optional[Tuple[date, date]] = None,
) -> Dict[str, float]:
    """Standard period headline numbers, in portfolio percent."""
    inception = positions.first_trade_date(db, portfolio)
    bounds = period_bounds(as_of, inception)
    out: Dict[str, float] = {}
    for key, (start, end) in bounds.items():
        out[key] = period_total(db, portfolio, start, end, include_offset=include_offset)
    if custom:
        out["custom"] = period_total(db, portfolio, custom[0], custom[1], include_offset=include_offset)
    return out


def per_instrument_summary(
    db: Session,
    portfolio: Portfolio,
    as_of: date,
    *,
    custom: Optional[Tuple[date, date]] = None,
) -> Dict[str, Dict[str, float]]:
    """{ticker: {period: pnl_pct}} - feeds the P&L columns of the main grid."""
    inception = positions.first_trade_date(db, portfolio)
    bounds = dict(period_bounds(as_of, inception))
    if custom:
        bounds["custom"] = custom

    all_rows = _stored_rows(db, portfolio, None, as_of)
    out: Dict[str, Dict[str, float]] = defaultdict(lambda: defaultdict(float))
    for row in all_rows:
        for key, (start, end) in bounds.items():
            if start is not None and row.pnl_date < start:
                continue
            if row.pnl_date > end:
                continue
            out[row.bbg_ticker][key] += row.total_pnl_pct
    return {k: dict(v) for k, v in out.items()}


def ticker_daily_totals(
    db: Session, portfolio: Portfolio, start: Optional[date], end: date
) -> Dict[str, Dict[date, float]]:
    """{ticker: {date: total contribution}} - the raw material for leg P&L."""
    out: Dict[str, Dict[date, float]] = defaultdict(dict)
    for r in _stored_rows(db, portfolio, start, end):
        out[r.bbg_ticker][r.pnl_date] = out[r.bbg_ticker].get(r.pnl_date, 0.0) + r.total_pnl_pct
    return out


def leg_total(
    daily: Dict[date, float], start: date, end: Optional[date]
) -> float:
    """
    P&L a position earned while one target was in force.

    `end` is inclusive; None means "still in force at the end of the window",
    in which case everything from `start` onward counts. Legs partition the
    window, so summing leg P&L across an instrument's legs reproduces its
    window contribution exactly.
    """
    return sum(
        v for d, v in daily.items() if d >= start and (end is None or d <= end)
    )


def funding_total(
    db: Session, portfolio: Portfolio, start: Optional[date], end: date
) -> float:
    """Funding accrual booked over a window - the realised cost of leverage."""
    return sum(
        r.funding_pnl_pct for r in _stored_rows(db, portfolio, start, end)
    )


def attribution_by_component(
    db: Session, portfolio: Portfolio, start: Optional[date], end: date
) -> Dict[str, float]:
    """Split a period's P&L into carry, trade-day and funding components."""
    rows = _stored_rows(db, portfolio, start, end)
    return {
        "carry": sum(r.carry_pnl_pct for r in rows),
        "trade": sum(r.trade_pnl_pct for r in rows),
        "funding": sum(r.funding_pnl_pct for r in rows),
        "total": sum(r.total_pnl_pct for r in rows),
    }


def equity_curve(
    db: Session, portfolio: Portfolio, start: Optional[date], end: date
) -> List[Tuple[date, float]]:
    """Cumulative P&L in percent, by date. Used by the analytics panel."""
    rows = _stored_rows(db, portfolio, start, end)
    by_day: Dict[date, float] = defaultdict(float)
    for r in rows:
        by_day[r.pnl_date] += r.total_pnl_pct
    curve: List[Tuple[date, float]] = []
    running = 0.0
    for d in sorted(by_day):
        running += by_day[d]
        curve.append((d, running))
    return curve


def realised_unrealised(
    db: Session, portfolio: Portfolio, as_of: date
) -> Dict[str, float]:
    """
    From-entry decomposition produced by the FIFO lot engine.

        realised   = SUM over closed lot slices of  w * (close_level/open_level - 1)
        unrealised = SUM over open lots of          w * (mark/open_level - 1)

    This answers "how much is this position up since I put it on?", which is a
    different question from "what did the book earn in August?". See
    `reconcile()` for how the two relate.
    """
    trades = positions.all_trades(db, portfolio, through=as_of, include_offset=False)
    books = positions.run_lot_engine(trades)

    realised = sum(b.realised_pnl_pct for b in books.values())
    unrealised = 0.0
    missing: List[str] = []
    for ticker, book in books.items():
        level, _ = pricing.latest_level(db, ticker, as_of)
        if level is None:
            if book.open_lots:
                missing.append(ticker)
            continue
        for lot in book.open_lots:
            unrealised += lot.remaining_weight * (level / lot.open_level - 1.0)

    return {
        "realised": realised,
        "unrealised": unrealised,
        "total": realised + unrealised,
        "unpriced_tickers": missing,  # type: ignore[dict-item]
    }


def reconcile(db: Session, portfolio: Portfolio, as_of: date) -> Dict[str, object]:
    """
    Cross-check the two P&L measures and explain any gap.

    These are NOT the same number by construction, and the difference is not an
    error:

      * The daily contribution series is a TARGET-WEIGHT measure. It assumes the
        stated notional weight is maintained each day, so it sums
        `w * (P_d/P_(d-1) - 1)` across days. This is the standard convention for
        a paper book expressed in weights, and it is what makes MTD/QTD/YTD
        additive across instruments and across time.

      * Realised + unrealised is a FROM-ENTRY measure on a fixed notional:
        `w * (P_n/P_0 - 1)`.

    A sum of daily simple returns does not equal the simple return over the
    whole period whenever the price compounds - so the residual is the
    compounding / implied-rebalancing effect. It is second-order for normal
    holding periods and it grows with holding period and volatility.

    What WOULD be an error is an unpriced ticker, which is reported separately
    and surfaced in the UI rather than silently absorbed into the residual.
    """
    market_total = period_total(db, portfolio, None, as_of, include_offset=False)
    lots = realised_unrealised(db, portfolio, as_of)
    unpriced = lots.pop("unpriced_tickers", [])

    return {
        "daily_series_total": market_total,
        "realised": lots["realised"],
        "unrealised": lots["unrealised"],
        "lot_total": lots["total"],
        "compounding_residual": market_total - lots["total"],
        "unpriced_tickers": unpriced,
        "clean": not unpriced,
    }


# ---------------------------------------------------------------------------
# Attribution curves
# ---------------------------------------------------------------------------
def _bucket_size(start: date, end: date) -> str:
    """
    Choose a time bucket so the attribution chart stays legible.

    A year of daily bars is 250 stacked columns a few pixels wide - unreadable.
    Bucketing is presentation only: the underlying series is always daily and
    the totals are identical whichever bucket is chosen.
    """
    span = (end - start).days
    if span <= 75:
        return "daily"
    if span <= 400:
        return "weekly"
    return "monthly"


def _bucket_key(d: date, bucket: str) -> date:
    if bucket == "weekly":
        return d + timedelta(days=6 - d.weekday())   # week ending Sunday
    if bucket == "monthly":
        if d.month == 12:
            return date(d.year, 12, 31)
        return date(d.year, d.month + 1, 1) - timedelta(days=1)
    return d


def contribution_curves(
    db: Session,
    portfolio: Portfolio,
    *,
    start: Optional[date],
    end: date,
    group_by: str = "level_1",
    top_n: int = 8,
) -> Dict[str, object]:
    """
    Cumulative P&L decomposed into contributors, for the attribution chart.

    Returns one cumulative series per group plus the cumulative total. The
    series sum EXACTLY to the total at every point, by construction - each is a
    running sum of the same daily rows, partitioned. That is what lets the
    chart stack the contributions and overlay the total line on one axis
    without the two disagreeing.

    Everything is rebased to zero at the window start, so MTD/QTD/YTD/ITD all
    read as "what this period earned", not "where the book stands".

    `group_by`:
        level_1 / level_2 / level_3  - hierarchy bucket (few series, the default)
        ticker                       - per instrument, top N by absolute
                                       contribution, remainder folded into
                                       "Other" so the palette is never cycled
    """
    inception = positions.first_trade_date(db, portfolio)
    start = start or inception
    if start is None:
        return {"buckets": [], "series": [], "total": [], "group_by": group_by}

    rows = _stored_rows(db, portfolio, start, end)
    if not rows:
        return {"buckets": [], "series": [], "total": [], "group_by": group_by}

    # Shared with positioning_table() so the chart and the table under it
    # always agree on keys, order and therefore colour.
    resolve, keys, _ = _grouping(db, rows, group_by, top_n)

    bucket = _bucket_size(start, end)
    per_bucket: Dict[date, Dict[str, float]] = defaultdict(lambda: defaultdict(float))
    for r in rows:
        per_bucket[_bucket_key(r.pnl_date, bucket)][resolve(r.bbg_ticker)] += r.total_pnl_pct

    buckets = sorted(per_bucket)

    running = {k: 0.0 for k in keys}
    series = {k: [] for k in keys}
    total: List[float] = []
    cumulative = 0.0
    for b in buckets:
        for k in keys:
            running[k] += per_bucket[b].get(k, 0.0)
            series[k].append(round(running[k], 8))
        cumulative += sum(per_bucket[b].values())
        total.append(round(cumulative, 8))

    return {
        "group_by": group_by,
        "bucket": bucket,
        "start": start,
        "end": end,
        "buckets": buckets,
        "series": [
            {"key": k, "label": k, "cumulative": series[k], "total": series[k][-1] if series[k] else 0.0}
            for k in keys
        ],
        "total": total,
    }


def _grouping(
    db: Session,
    rows: Sequence[PnlSnapshot],
    group_by: str,
    top_n: int,
):
    """
    Shared grouping used by BOTH the attribution chart and the positioning
    table, so a bar and its rows always carry the same key, the same order and
    therefore the same colour. Returns (resolve_fn, ordered_keys, label_of).
    """
    from app.models import InstrumentMaster
    from app.services.exposure import asset_class_sort_key

    hierarchy: Dict[str, Dict[str, str]] = {}
    for inst in db.scalars(select(InstrumentMaster)):
        hierarchy[inst.bbg_ticker] = {
            "level_1": inst.level_1,
            "level_2": inst.level_2,
            "level_3": inst.level_3,
            "ticker": inst.bbg_ticker,
            "name": inst.instrument_name,
        }

    totals: Dict[str, float] = defaultdict(float)
    for r in rows:
        totals[r.bbg_ticker] += r.total_pnl_pct

    if group_by == "ticker":
        keep = {t for t, _ in sorted(totals.items(), key=lambda kv: -abs(kv[1]))[:top_n]}
        label_of = {t: (hierarchy.get(t, {}).get("name") or t) for t in keep}

        def resolve(ticker: str) -> str:
            return label_of.get(ticker, "Other")
    else:
        def resolve(ticker: str) -> str:
            meta = hierarchy.get(ticker)
            return (meta.get(group_by) if meta else None) or "Unclassified"

    keys = sorted({resolve(t) for t in totals})
    magnitude: Dict[str, float] = defaultdict(float)
    for t, v in totals.items():
        magnitude[resolve(t)] += abs(v)

    if group_by == "level_1":
        keys.sort(key=lambda k: (k == "Other", asset_class_sort_key(k)))
    else:
        keys.sort(key=lambda k: (k == "Other", -magnitude[k], k))

    return resolve, keys, hierarchy


def positioning_table(
    db: Session,
    portfolio: Portfolio,
    *,
    start: Optional[date],
    end: date,
    group_by: str = "level_1",
    top_n: int = 8,
) -> Dict[str, object]:
    """
    What the book was holding over the period that produced the P&L above it.

    Grouped and ORDERED identically to `contribution_curves`, so the UI can
    colour row groups by series index and match the chart exactly. For each
    instrument it reports the target entering the period, the target leaving
    it, and the contribution earned in between - including positions that were
    closed inside the window, which are part of the period's positioning even
    though they are flat now.
    """
    inception = positions.first_trade_date(db, portfolio)
    start = start or inception
    if start is None:
        return {"group_by": group_by, "series": [], "start": None, "end": end}

    rows = _stored_rows(db, portfolio, start, end)
    if not rows:
        return {"group_by": group_by, "series": [], "start": start, "end": end}

    resolve, keys, hierarchy = _grouping(db, rows, group_by, top_n)
    legs_by_ticker = positions.target_history(
        db, portfolio, start, end, include_offset=True
    )
    contribution: Dict[str, float] = defaultdict(float)
    for r in rows:
        contribution[r.bbg_ticker] += r.total_pnl_pct

    buckets: Dict[str, List[dict]] = defaultdict(list)
    for ticker, legs in legs_by_ticker.items():
        meta = hierarchy.get(ticker, {})
        opening = legs[0].target_pct if legs and legs[0].is_opening else 0.0
        closing = legs[-1].target_pct if legs else 0.0
        buckets[resolve(ticker)].append(
            {
                "ticker": ticker,
                "name": meta.get("name") or ticker,
                "level_1": meta.get("level_1") or "Unclassified",
                "level_2": meta.get("level_2") or "Unclassified",
                "start_target_pct": opening,
                "end_target_pct": closing,
                "changes": max(len(legs) - (1 if legs and legs[0].is_opening else 0), 0),
                "first_on": legs[0].effective_from if legs else None,
                "last_on": legs[-1].effective_from if legs else None,
                "closed_in_window": abs(closing) < positions.WEIGHT_EPSILON,
                "contribution_pct": contribution.get(ticker, 0.0),
            }
        )

    series = []
    for key in keys:
        members = sorted(buckets.get(key, []), key=lambda r: -abs(r["contribution_pct"]))
        series.append(
            {
                "key": key,
                "label": key,
                "rows": members,
                "start_target_pct": sum(m["start_target_pct"] for m in members),
                "end_target_pct": sum(m["end_target_pct"] for m in members),
                "contribution_pct": sum(m["contribution_pct"] for m in members),
            }
        )

    return {
        "group_by": group_by,
        "start": start,
        "end": end,
        "series": series,
        "total_contribution_pct": sum(s["contribution_pct"] for s in series),
    }


def positioning_series(
    db: Session,
    portfolio: Portfolio,
    *,
    start: Optional[date],
    end: date,
    group_by: str = "level_1",
    top_n: int = 8,
) -> Dict[str, object]:
    """
    Target weight held through the period, bucketed and grouped to match the
    cumulative P&L chart exactly.

    This is the positioning that PRODUCED the P&L above it, so it has to share
    the attribution chart's x-axis and its colours. Both call `_bucket_size` and
    `_grouping`, so the bucket boundaries, the series keys and their order are
    identical by construction rather than by coincidence.

    A weight is a LEVEL, not a flow - so each bucket reports the target in force
    at the END of that bucket, which is the same convention the cumulative P&L
    line uses. Longs are positive and shorts negative; the UI stacks them either
    side of zero. The funding sleeve is included, because a book that nets to
    zero only reads correctly when the financing leg is visible.
    """
    inception = positions.first_trade_date(db, portfolio)
    start = start or inception
    if start is None:
        return {"group_by": group_by, "buckets": [], "series": [], "start": None, "end": end}

    rows = _stored_rows(db, portfolio, start, end)
    if not rows:
        return {"group_by": group_by, "buckets": [], "series": [], "start": start, "end": end}

    resolve, keys, _hierarchy = _grouping(db, rows, group_by, top_n)
    bucket = _bucket_size(start, end)

    # Bucket LABELS must be byte-identical to contribution_curves, or the two
    # charts stack over different x-axes. So the key is computed exactly as it
    # is there - unclamped - and only the date the weight is SAMPLED on is
    # clamped to the window end. Otherwise the final weekly or monthly column
    # would report a target from a date the period has not reached.
    bucket_ends = sorted({_bucket_key(r.pnl_date, bucket) for r in rows})
    if not bucket_ends:
        return {"group_by": group_by, "buckets": [], "series": [], "start": start, "end": end}
    sample_on = [min(b, end) for b in bucket_ends]

    legs_by_ticker = positions.target_history(db, portfolio, start, end, include_offset=True)

    # Step function per instrument: the target in force on any given day.
    per_key: Dict[str, List[float]] = {k: [0.0] * len(bucket_ends) for k in keys}
    for ticker, legs in legs_by_ticker.items():
        key = resolve(ticker)
        if key not in per_key:
            per_key[key] = [0.0] * len(bucket_ends)
        for i, when in enumerate(sample_on):
            weight = 0.0
            for leg in legs:
                if leg.effective_from <= when and (
                    leg.effective_to is None or leg.effective_to >= when
                ):
                    weight = leg.target_pct
            per_key[key][i] += weight

    series = [
        {
            "key": k,
            "label": k,
            "weights": [round(v, 8) for v in per_key.get(k, [0.0] * len(bucket_ends))],
            "end_weight_pct": round(per_key.get(k, [0.0])[-1], 8),
        }
        for k in keys
    ]
    gross = [
        round(sum(abs(s["weights"][i]) for s in series), 8) for i in range(len(bucket_ends))
    ]
    net = [round(sum(s["weights"][i] for s in series), 8) for i in range(len(bucket_ends))]

    return {
        "group_by": group_by,
        "bucket": bucket,
        "start": start,
        "end": end,
        "buckets": bucket_ends,
        "series": series,
        "gross_pct": gross,
        "net_pct": net,
    }


def latest_pnl_date(db: Session, portfolio: Portfolio) -> Optional[date]:
    row = db.execute(
        select(PnlSnapshot.pnl_date)
        .where(PnlSnapshot.portfolio_pk == portfolio.id)
        .order_by(PnlSnapshot.pnl_date.desc())
        .limit(1)
    ).first()
    return row[0] if row else None
