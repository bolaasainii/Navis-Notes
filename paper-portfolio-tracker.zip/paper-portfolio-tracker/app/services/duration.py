"""
Fixed-income duration targeting.

Definition used
---------------
    duration contribution (years) = notional weight (as a fraction)
                                    x modified duration (years)

so a +10% position in TY1 at 6.5y duration contributes 0.65 years to the
book's duration target. Contributions are additive, which is the whole point:
the fixed-income duration target is the sum of its parts.

Sourcing hierarchy, in order
----------------------------
1. OVERRIDE   - a human override recorded against the instrument. Always wins,
                always tagged, always logged with who and when.
2. DIRECT     - a Bloomberg reference field, tried in the order configured in
                settings.analytics.duration.field_priority. `FUT_EQV_DUR_NOTL`
                first because for a bond future it is the futures-equivalent
                duration of the notional, which is what a weight-based book
                actually wants; `DUR_ADJ_MID` / `DUR_MID` follow for
                instruments that publish a plain modified duration.
3. PROXY      - the static table in config/duration_proxies.yaml, matched by
                exact ticker, then Level 3, then Level 2. Tagged "proxy" so it
                is visibly distinct in the UI.
4. N/A        - yield-quoted contracts (the CME Treasury *yield* futures,
                Level 3 "US Treasury Yield") quote a rate, not a price. A
                notional-weight duration is not meaningful for them, so they
                are excluded from the duration target and flagged rather than
                being silently assigned zero.
5. UNAVAILABLE- nothing found. Excluded from the target and reported.

Non-fixed-income instruments return N/A with no flag: an equity index future
has no duration and that is not a data gap.

Every resolution is cached in `instrument_reference_cache` keyed by
(ticker, field, as_of_date) so the number behind a duration target can always
be traced back to a field and an observation date.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Dict, Iterable, List, Optional, Sequence

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.bloomberg import get_provider
from app.bloomberg.base import BloombergUnavailable
from app.config import get_duration_proxies, settings
from app.models import DurationSource, InstrumentMaster, InstrumentReferenceCache
from app.services import audit

logger = logging.getLogger(__name__)

FIXED_INCOME_LEVEL1 = "Fixed Income"
OVERRIDE_FIELD = "DURATION_OVERRIDE"


@dataclass
class DurationResult:
    years: Optional[float]
    source: DurationSource
    field_used: Optional[str] = None
    as_of: Optional[date] = None
    note: Optional[str] = None

    @property
    def is_usable(self) -> bool:
        return self.years is not None and self.source != DurationSource.NOT_APPLICABLE


def is_fixed_income(instrument: Optional[InstrumentMaster]) -> bool:
    return bool(instrument and instrument.level_1 == FIXED_INCOME_LEVEL1)


def _is_yield_quoted(instrument: InstrumentMaster) -> bool:
    proxies = get_duration_proxies()
    yield_levels = set((proxies.get("defaults") or {}).get("yield_quoted_level3") or [])
    return instrument.level_3 in yield_levels


def _proxy_lookup(instrument: InstrumentMaster) -> Optional[tuple[float, str]]:
    proxies = get_duration_proxies()
    by_ticker = proxies.get("by_ticker") or {}
    if instrument.bbg_ticker in by_ticker:
        return float(by_ticker[instrument.bbg_ticker]), "by_ticker"

    defaults = proxies.get("defaults") or {}
    if instrument.level_3 == "Short Rates" and "short_rate_duration" in defaults:
        return float(defaults["short_rate_duration"]), "defaults.short_rate_duration"

    by_l3 = proxies.get("by_level3") or {}
    if instrument.level_3 in by_l3:
        return float(by_l3[instrument.level_3]), "by_level3"

    by_l2 = proxies.get("by_level2") or {}
    if instrument.level_2 in by_l2:
        return float(by_l2[instrument.level_2]), "by_level2"
    return None


def _cached(db: Session, ticker: str, field: str, as_of: date) -> Optional[InstrumentReferenceCache]:
    """
    Latest cached reference value at or before `as_of`.

    Scoped to the active provider so live and offline duration values never mix
    - except manual OVERRIDES (provider='manual'), which are a deliberate human
    decision and are honoured in both modes.
    """
    from app.services.pricing import active_provider_name

    allowed = (active_provider_name(), "manual")
    return db.scalars(
        select(InstrumentReferenceCache)
        .where(
            InstrumentReferenceCache.bbg_ticker == ticker,
            InstrumentReferenceCache.field == field,
            InstrumentReferenceCache.provider.in_(allowed),
            InstrumentReferenceCache.as_of_date <= as_of,
        )
        .order_by(InstrumentReferenceCache.as_of_date.desc())
        .limit(1)
    ).first()


def set_override(
    db: Session,
    *,
    ticker: str,
    years: Optional[float],
    as_of: date,
    actor: Optional[str] = None,
    reason: Optional[str] = None,
) -> None:
    """Record (or clear) a manual duration override. Always audited."""
    existing = db.scalars(
        select(InstrumentReferenceCache).where(
            InstrumentReferenceCache.bbg_ticker == ticker,
            InstrumentReferenceCache.field == OVERRIDE_FIELD,
            InstrumentReferenceCache.as_of_date == as_of,
            InstrumentReferenceCache.provider == "manual",
        )
    ).first()

    if years is None:
        if existing:
            db.delete(existing)
        action, summary = "clear_override", f"Cleared duration override for {ticker} as of {as_of}"
    elif existing:
        existing.value_num = years
        existing.value_str = reason
        existing.provider = "manual"
        existing.fetched_at = datetime.utcnow()
        action, summary = "update_override", f"Duration override {ticker} = {years}y as of {as_of}"
    else:
        db.add(
            InstrumentReferenceCache(
                bbg_ticker=ticker,
                field=OVERRIDE_FIELD,
                as_of_date=as_of,
                value_num=years,
                value_str=reason,
                provider="manual",
            )
        )
        action, summary = "set_override", f"Duration override {ticker} = {years}y as of {as_of}"

    audit.record(
        db,
        category="duration",
        action=action,
        summary=summary,
        bbg_ticker=ticker,
        actor=actor,
        detail={"years": years, "as_of": as_of, "reason": reason},
    )
    db.flush()


def prefetch(db: Session, instruments: Sequence[InstrumentMaster], as_of: date) -> None:
    """
    Bulk-fetch Bloomberg duration fields for the fixed-income instruments that
    are not already cached. One request instead of N.
    """
    fi = [
        i
        for i in instruments
        if is_fixed_income(i) and not i.is_synthetic and not _is_yield_quoted(i)
    ]
    if not fi:
        return

    fields = settings.analytics.duration.field_priority
    ttl = timedelta(hours=settings.bloomberg.cache_ttl_hours)
    need: List[str] = []
    for inst in fi:
        fresh = False
        for f in fields:
            row = _cached(db, inst.bbg_ticker, f, as_of)
            if row is not None and (datetime.utcnow() - row.fetched_at) < ttl:
                fresh = True
                break
        if not fresh:
            need.append(inst.bbg_ticker)

    if not need:
        return

    provider = get_provider()
    try:
        data = provider.reference(need, fields, as_of=as_of)
    except BloombergUnavailable as exc:
        logger.warning("Duration prefetch failed: %s", exc)
        return

    for ticker, values in data.items():
        for f in fields:
            if f not in values:
                continue
            try:
                num = float(values[f])
            except (TypeError, ValueError):
                continue
            existing = db.scalars(
                select(InstrumentReferenceCache).where(
                    InstrumentReferenceCache.bbg_ticker == ticker,
                    InstrumentReferenceCache.field == f,
                    InstrumentReferenceCache.as_of_date == as_of,
                    InstrumentReferenceCache.provider == provider.name,
                )
            ).first()
            if existing:
                existing.value_num = num
                existing.fetched_at = datetime.utcnow()
            else:
                db.add(
                    InstrumentReferenceCache(
                        bbg_ticker=ticker,
                        field=f,
                        as_of_date=as_of,
                        value_num=num,
                        provider=provider.name,
                    )
                )
    db.flush()


def resolve(
    db: Session, instrument: Optional[InstrumentMaster], as_of: date
) -> DurationResult:
    """Resolve a single instrument's duration following the sourcing hierarchy."""
    if instrument is None or instrument.is_synthetic:
        return DurationResult(None, DurationSource.NOT_APPLICABLE, note="Synthetic funding sleeve")

    if not is_fixed_income(instrument):
        return DurationResult(
            None, DurationSource.NOT_APPLICABLE, note="Not a fixed income instrument"
        )

    if _is_yield_quoted(instrument):
        return DurationResult(
            None,
            DurationSource.NOT_APPLICABLE,
            note=(
                "Yield-quoted contract - the price IS a rate, so a notional-weight "
                "duration is not meaningful. Excluded from the duration target."
            ),
        )

    override = _cached(db, instrument.bbg_ticker, OVERRIDE_FIELD, as_of)
    if override is not None and override.value_num is not None:
        return DurationResult(
            override.value_num,
            DurationSource.OVERRIDE,
            field_used=OVERRIDE_FIELD,
            as_of=override.as_of_date,
            note=override.value_str or "Manual override",
        )

    for field in settings.analytics.duration.field_priority:
        row = _cached(db, instrument.bbg_ticker, field, as_of)
        if row is not None and row.value_num is not None:
            return DurationResult(
                row.value_num,
                DurationSource.DIRECT,
                field_used=field,
                as_of=row.as_of_date,
            )

    if settings.analytics.duration.allow_proxy_fallback:
        proxy = _proxy_lookup(instrument)
        if proxy is not None:
            years, how = proxy
            return DurationResult(
                years,
                DurationSource.PROXY,
                field_used=f"config:{how}",
                as_of=as_of,
                note=(
                    "Bloomberg duration unavailable; using the static proxy table "
                    f"(matched {how}). Estimated, not observed."
                ),
            )

    return DurationResult(
        None,
        DurationSource.UNAVAILABLE,
        as_of=as_of,
        note="No Bloomberg duration field and no proxy match. Excluded from the target.",
    )


def contribution(weight_pct: float, result: DurationResult) -> Optional[float]:
    """Weight (percent) x duration (years) -> duration contribution in years."""
    if not result.is_usable or result.years is None:
        return None
    return (weight_pct / 100.0) * result.years
