"""
Exposure aggregation and the composed position view.

This module is the single place that assembles a "row" for the main grid:
position state + pricing + P&L + duration + volatility + hierarchy. Routers and
templates consume its output and do no arithmetic of their own, which keeps the
UI honest and makes the numbers testable.

Two windows, deliberately separate
----------------------------------
    valuation_date          - the as-of date for weights, marks and duration
    positioning window      - which rows count as "active", and the sample used
                              for standalone volatility
    performance window(s)   - Today / MTD / QTD / YTD / ITD / custom for P&L

A user can be looking at August positioning while the P&L columns show QTD and
YTD. Nothing in this module conflates them.

Funding sleeve
--------------
`USD_CASH_OFFSET` is included in the row set (so the book visibly nets to zero)
but is excluded from every market aggregate: gross, net, long, short, the
Level 1-4 rollups and the asset-class KPIs. It sits under its own
"Cash & Funding" heading. The UI hides it by default.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import settings
from app.models import (
    DurationSource,
    InstrumentMaster,
    LevelSource,
    Portfolio,
    Trade,
)
from app.services import duration as duration_svc
from app.services import pnl as pnl_svc
from app.services import positions, pricing
from app.services import volatility as vol_svc

logger = logging.getLogger(__name__)

EQUITY = "Equity"
FIXED_INCOME = "Fixed Income"
FX = "FX"
CASH = "Cash & Funding"

# Canonical presentation order for the top of the hierarchy. Risk assets first,
# then rates, then currency, with the financing leg last - the order a macro
# book is discussed in, rather than whatever happens to be biggest this week.
# Anything unrecognised sorts alphabetically after these.
ASSET_CLASS_ORDER = [EQUITY, FIXED_INCOME, FX, CASH]


def asset_class_sort_key(label: str) -> tuple:
    try:
        return (0, ASSET_CLASS_ORDER.index(label), "")
    except ValueError:
        return (1, 0, label or "")


@dataclass
class PositionRow:
    ticker: str
    instrument_name: str
    level_1: str
    level_2: str
    level_3: str
    level_4: str
    yellow_key: str = ""
    primary_exchange: Optional[str] = None

    net_weight_pct: float = 0.0
    avg_open_level: Optional[float] = None
    latest_level: Optional[float] = None
    latest_level_date: Optional[date] = None

    first_trade_date: Optional[date] = None
    last_trade_date: Optional[date] = None
    execution_types: List[str] = field(default_factory=list)
    level_sources: List[str] = field(default_factory=list)
    has_manual_level: bool = False
    has_price_fallback: bool = False

    realised_pnl_pct: float = 0.0
    unrealised_pnl_pct: float = 0.0
    pnl: Dict[str, float] = field(default_factory=dict)

    duration_years: Optional[float] = None
    duration_contribution: Optional[float] = None
    duration_source: Optional[str] = None
    duration_note: Optional[str] = None

    standalone_vol_pct: Optional[float] = None
    instrument_vol_pct: Optional[float] = None
    vol_observations: int = 0
    vol_note: Optional[str] = None

    is_funding_offset: bool = False
    is_active: bool = True
    notes: Optional[str] = None

    # Populated only when the grid asks for target history (include_history).
    target_history: List[dict] = field(default_factory=list)
    window_start_target_pct: float = 0.0
    window_end_target_pct: float = 0.0
    window_pnl_pct: float = 0.0

    @property
    def is_long(self) -> bool:
        return self.net_weight_pct > 0

    def as_dict(self) -> dict:
        d = {k: v for k, v in self.__dict__.items()}
        d["is_long"] = self.is_long
        return d


@dataclass
class ExposureBucket:
    key: str
    label: str
    net_pct: float = 0.0
    gross_pct: float = 0.0
    long_pct: float = 0.0
    short_pct: float = 0.0
    row_count: int = 0
    duration_contribution: float = 0.0
    standalone_vol_pct: float = 0.0
    children: Dict[str, "ExposureBucket"] = field(default_factory=dict)

    def add(self, row: PositionRow) -> None:
        w = row.net_weight_pct
        self.net_pct += w
        self.gross_pct += abs(w)
        if w > 0:
            self.long_pct += w
        else:
            self.short_pct += w
        self.row_count += 1
        if row.duration_contribution:
            self.duration_contribution += row.duration_contribution
        if row.standalone_vol_pct:
            self.standalone_vol_pct += row.standalone_vol_pct

    def as_dict(self) -> dict:
        return {
            "key": self.key,
            "label": self.label,
            "net_pct": self.net_pct,
            "gross_pct": self.gross_pct,
            "long_pct": self.long_pct,
            "short_pct": self.short_pct,
            "row_count": self.row_count,
            "duration_contribution": self.duration_contribution,
            "standalone_vol_pct": self.standalone_vol_pct,
            # Children sort by gross exposure - biggest risk first within its
            # parent. The canonical asset-class order applies only at the top.
            "children": [
                c.as_dict()
                for c in sorted(self.children.values(), key=lambda b: -abs(b.gross_pct))
            ],
        }


# ---------------------------------------------------------------------------
# View assembly
# ---------------------------------------------------------------------------
def build_position_view(
    db: Session,
    portfolio: Portfolio,
    *,
    valuation_date: Optional[date] = None,
    window_start: Optional[date] = None,
    window_end: Optional[date] = None,
    include_inactive: bool = False,
    include_offset: bool = True,
    include_history: bool = False,
    vol_lookback_days: Optional[int] = None,
    custom_pnl_window: Optional[Tuple[date, date]] = None,
) -> Dict[str, object]:
    """
    Assemble the full position view.

    Returns a dict with `rows`, `totals`, `kpis`, `rollups`, `windows` and
    `diagnostics`, ready for JSON serialisation or template rendering.
    """
    valuation_date = valuation_date or date.today()
    window_end = window_end or valuation_date
    window_start = window_start or pnl_svc.month_start(valuation_date)

    offset_ticker = settings.funding.offset_ticker

    weights = positions.net_weights_as_of(db, portfolio, valuation_date, include_offset=True)
    all_trades = positions.all_trades(db, portfolio, through=valuation_date)

    # Every ticker ever traded, so exited positions can be shown when asked for.
    traded_tickers = sorted({t.bbg_ticker for t in all_trades})

    # With history on, the row set widens to everything that was ON at any
    # point in the positioning window - including positions since closed. A
    # trade opened in July and closed in August is part of the quarter's
    # positioning; omitting it would misrepresent the period.
    window_active: set = set()
    if include_history:
        window_active = set(
            positions.active_tickers_between(
                db, portfolio, window_start, window_end, include_offset=True
            )
        )

    tickers = [
        t
        for t in traded_tickers
        if include_inactive
        or t in window_active
        or abs(weights.get(t, 0.0)) > positions.WEIGHT_EPSILON
    ]
    if not include_offset:
        tickers = [t for t in tickers if t != offset_ticker]

    instruments = {
        i.bbg_ticker: i
        for i in db.scalars(
            select(InstrumentMaster).where(InstrumentMaster.bbg_ticker.in_(tickers or [""]))
        )
    }

    market_tickers = [t for t in tickers if t != offset_ticker]
    if market_tickers:
        pricing.ensure_prices(db, market_tickers, window_start, valuation_date)
    duration_svc.prefetch(db, list(instruments.values()), valuation_date)

    # P&L: recompute the daily series then read the period aggregates.
    pnl_svc.compute_daily_pnl(db, portfolio, end=valuation_date)
    per_instrument = pnl_svc.per_instrument_summary(
        db, portfolio, valuation_date, custom=custom_pnl_window
    )
    lot_books = positions.run_lot_engine(
        positions.all_trades(db, portfolio, through=valuation_date, include_offset=False)
    )

    vols = vol_svc.compute_many(
        db,
        market_tickers,
        window_start=window_start,
        window_end=window_end,
        lookback_days=vol_lookback_days,
    )

    trades_by_ticker: Dict[str, List[Trade]] = defaultdict(list)
    for t in all_trades:
        trades_by_ticker[t.bbg_ticker].append(t)

    rows: List[PositionRow] = []
    for ticker in tickers:
        inst = instruments.get(ticker)
        weight = weights.get(ticker, 0.0)
        ticker_trades = trades_by_ticker.get(ticker, [])

        row = PositionRow(
            ticker=ticker,
            instrument_name=inst.instrument_name if inst else ticker,
            level_1=inst.level_1 if inst else "Unclassified",
            level_2=inst.level_2 if inst else "Unclassified",
            level_3=inst.level_3 if inst else "Unclassified",
            level_4=inst.level_4 if inst else "Unclassified",
            yellow_key=inst.yellow_key if inst else "",
            primary_exchange=inst.primary_exchange if inst else None,
            net_weight_pct=weight,
            is_funding_offset=(ticker == offset_ticker),
            is_active=abs(weight) > positions.WEIGHT_EPSILON,
        )

        if ticker_trades:
            row.first_trade_date = min(t.trade_date for t in ticker_trades)
            row.last_trade_date = max(t.trade_date for t in ticker_trades)
            row.execution_types = sorted({t.execution_type.value for t in ticker_trades})
            row.level_sources = sorted({t.level_source.value for t in ticker_trades})
            row.has_manual_level = any(
                t.level_source in (LevelSource.MANUAL, LevelSource.IMPORTED)
                for t in ticker_trades
            )
            row.has_price_fallback = any(
                t.level_source == LevelSource.BLOOMBERG_FALLBACK for t in ticker_trades
            )
            row.notes = next((t.notes for t in reversed(ticker_trades) if t.notes), None)

        book = lot_books.get(ticker)
        if book:
            row.avg_open_level = book.average_open_level
            row.realised_pnl_pct = book.realised_pnl_pct

        level, level_date = pricing.latest_level(db, ticker, valuation_date)
        row.latest_level = level
        row.latest_level_date = level_date

        if book and level is not None:
            row.unrealised_pnl_pct = sum(
                lot.remaining_weight * (level / lot.open_level - 1.0) for lot in book.open_lots
            )

        row.pnl = per_instrument.get(ticker, {})

        dur = duration_svc.resolve(db, inst, valuation_date)
        row.duration_years = dur.years
        row.duration_source = dur.source.value if dur.source else None
        row.duration_note = dur.note
        row.duration_contribution = duration_svc.contribution(weight, dur)

        vres = vols.get(ticker)
        if vres:
            row.instrument_vol_pct = vres.instrument_vol_pct
            row.standalone_vol_pct = vres.standalone(weight)
            row.vol_observations = vres.observations
            row.vol_note = vres.note

        rows.append(row)

    # ---- target history ---------------------------------------------------
    if include_history:
        legs_by_ticker = positions.target_history(
            db, portfolio, window_start, window_end, include_offset=True
        )
        daily = pnl_svc.ticker_daily_totals(db, portfolio, window_start, window_end)
        by_ticker_row = {r.ticker: r for r in rows}
        for ticker, legs in legs_by_ticker.items():
            row = by_ticker_row.get(ticker)
            if row is None:
                continue
            ticker_daily = daily.get(ticker, {})
            history = []
            for leg in legs:
                payload = leg.as_dict()
                payload["leg_pnl_pct"] = pnl_svc.leg_total(
                    ticker_daily, leg.effective_from, leg.effective_to
                )
                history.append(payload)
            row.target_history = history
            row.window_start_target_pct = legs[0].target_pct if legs and legs[0].is_opening else 0.0
            row.window_end_target_pct = legs[-1].target_pct if legs else 0.0
            row.window_pnl_pct = sum(h["leg_pnl_pct"] for h in history)

    rows.sort(key=lambda r: (r.is_funding_offset, asset_class_sort_key(r.level_1), r.level_2, r.level_3, r.instrument_name))

    market_rows = [r for r in rows if not r.is_funding_offset]
    totals = _totals(market_rows)
    kpis = _kpis(db, portfolio, market_rows, rows, valuation_date, custom_pnl_window)
    rollups = {
        level: [b.as_dict() for b in build_rollup(market_rows, level).values()]
        for level in ("level_1", "level_2", "level_3", "level_4")
    }

    diagnostics = _diagnostics(db, portfolio, rows, valuation_date)

    return {
        "rows": [r.as_dict() for r in rows],
        "totals": totals,
        "kpis": kpis,
        "rollups": rollups,
        "hierarchy_rollup": build_nested_rollup(market_rows),
        "windows": {
            "valuation_date": valuation_date,
            "positioning_start": window_start,
            "positioning_end": window_end,
            "vol_lookback_days": vol_lookback_days
            or settings.analytics.volatility.default_lookback_days,
            "custom_pnl_window": custom_pnl_window,
        },
        "diagnostics": diagnostics,
    }


# ---------------------------------------------------------------------------
# Aggregates
# ---------------------------------------------------------------------------
def _totals(market_rows: Sequence[PositionRow]) -> Dict[str, float]:
    net = sum(r.net_weight_pct for r in market_rows)
    gross = sum(abs(r.net_weight_pct) for r in market_rows)
    longs = sum(r.net_weight_pct for r in market_rows if r.net_weight_pct > 0)
    shorts = sum(r.net_weight_pct for r in market_rows if r.net_weight_pct < 0)
    dur = sum(r.duration_contribution or 0.0 for r in market_rows)
    vol = sum(r.standalone_vol_pct or 0.0 for r in market_rows)
    return {
        "net_pct": net,
        "gross_pct": gross,
        "long_pct": longs,
        "short_pct": shorts,
        "duration_contribution": dur,
        "sum_of_standalone_vol_pct": vol,
        "row_count": len(market_rows),
    }


def _asset_class_net(rows: Sequence[PositionRow], level_1: str) -> Dict[str, float]:
    subset = [r for r in rows if r.level_1 == level_1]
    return {
        "net_pct": sum(r.net_weight_pct for r in subset),
        "gross_pct": sum(abs(r.net_weight_pct) for r in subset),
        "long_pct": sum(r.net_weight_pct for r in subset if r.net_weight_pct > 0),
        "short_pct": sum(r.net_weight_pct for r in subset if r.net_weight_pct < 0),
        "row_count": len(subset),
        "duration_contribution": sum(r.duration_contribution or 0.0 for r in subset),
    }


def _funding_cost(
    db: Session,
    portfolio: Portfolio,
    offset_weight: float,
    valuation_date: date,
) -> Dict[str, object]:
    """
    What the leverage is costing, as opposed to how much of it there is.

    The sleeve weight is the financing REQUIREMENT - a -9% sleeve means 9% of
    NAV is borrowed. That is a leverage measure, not a cost. The cost is the
    accrual on it:

        annualised run rate = sleeve weight x all-in funding rate
        accrued to date     = the funding component already booked into P&L

    Both are reported. The run rate answers "what is this position costing me
    to hold?"; the accrual answers "what has it cost so far?" and ties exactly
    to the Cash & Funding series in the attribution chart.
    """
    from app.services import funding as funding_svc

    terms = funding_svc.terms_for(
        db, portfolio, valuation_date, weight_pct=offset_weight
    )
    all_in = terms.all_in_rate_pct
    # Signed: a negative (borrowed) sleeve produces a negative annual cost.
    annual = (offset_weight / 100.0) * all_in

    inception = positions.first_trade_date(db, portfolio)
    accrued_itd = pnl_svc.funding_total(db, portfolio, inception, valuation_date)
    accrued_mtd = pnl_svc.funding_total(
        db, portfolio, pnl_svc.month_start(valuation_date), valuation_date
    )
    accrued_ytd = pnl_svc.funding_total(
        db, portfolio, pnl_svc.year_start(valuation_date), valuation_date
    )

    spread_txt = f"{terms.spread_bps:+.0f}bp" if terms.spread_bps else "flat"
    return {
        "financed_pct": offset_weight,
        "benchmark": terms.benchmark,
        "base_rate_pct": terms.base_rate_pct,
        "spread_bps": terms.spread_bps,
        "all_in_rate_pct": all_in,
        "rate_effective_date": terms.effective_date,
        "rate_source": terms.source,
        "annual_run_rate_pct": annual,
        "accrued_mtd_pct": accrued_mtd,
        "accrued_ytd_pct": accrued_ytd,
        "accrued_itd_pct": accrued_itd,
        "day_count": settings.funding.day_count,
        "footnote": (
            f"{abs(offset_weight):.2f}% financed at {terms.benchmark} "
            f"{terms.base_rate_pct:.2f}% {spread_txt} "
            f"= {all_in:.2f}% p.a., {settings.funding.day_count}"
        ),
    }


def _kpis(
    db: Session,
    portfolio: Portfolio,
    market_rows: Sequence[PositionRow],
    all_rows: Sequence[PositionRow],
    valuation_date: date,
    custom_window: Optional[Tuple[date, date]],
) -> Dict[str, object]:
    totals = _totals(market_rows)
    periods = pnl_svc.period_summary(db, portfolio, valuation_date, custom=custom_window)
    offset_weight = next(
        (r.net_weight_pct for r in all_rows if r.is_funding_offset), 0.0
    )
    return {
        "total": totals,
        "equity": _asset_class_net(market_rows, EQUITY),
        "fixed_income": _asset_class_net(market_rows, FIXED_INCOME),
        "fx": _asset_class_net(market_rows, FX),
        "funding_sleeve_pct": offset_weight,
        "leverage": _funding_cost(db, portfolio, offset_weight, valuation_date),
        "book_nets_to": totals["net_pct"] + offset_weight,
        "duration_target_years": totals["duration_contribution"],
        "pnl": periods,
    }


def build_rollup(rows: Sequence[PositionRow], level: str) -> Dict[str, ExposureBucket]:
    """
    Aggregate rows into buckets for one hierarchy level.

    Level 1 uses the canonical asset-class order so the book always reads
    Equity -> Fixed Income -> FX -> Cash & Funding. Deeper levels sort by gross
    exposure, where "biggest first" is the useful ordering.
    """
    buckets: Dict[str, ExposureBucket] = {}
    for row in rows:
        key = getattr(row, level, "Unclassified") or "Unclassified"
        bucket = buckets.setdefault(key, ExposureBucket(key=key, label=key))
        bucket.add(row)
    if level == "level_1":
        return dict(sorted(buckets.items(), key=lambda kv: asset_class_sort_key(kv[0])))
    return dict(sorted(buckets.items(), key=lambda kv: -abs(kv[1].gross_pct)))


def build_nested_rollup(rows: Sequence[PositionRow]) -> List[dict]:
    """Level 1 -> 2 -> 3 -> 4 nested aggregate for the expandable grouping view."""
    root: Dict[str, ExposureBucket] = {}
    for row in rows:
        l1 = root.setdefault(row.level_1, ExposureBucket(row.level_1, row.level_1))
        l1.add(row)
        l2 = l1.children.setdefault(row.level_2, ExposureBucket(row.level_2, row.level_2))
        l2.add(row)
        l3 = l2.children.setdefault(row.level_3, ExposureBucket(row.level_3, row.level_3))
        l3.add(row)
        l4 = l3.children.setdefault(row.level_4, ExposureBucket(row.level_4, row.level_4))
        l4.add(row)
    # Canonical asset-class order at the top; gross-descending beneath it,
    # which is handled inside ExposureBucket.children ordering below.
    return [b.as_dict() for b in sorted(root.values(), key=lambda b: asset_class_sort_key(b.key))]


def _diagnostics(
    db: Session, portfolio: Portfolio, rows: Sequence[PositionRow], valuation_date: date
) -> Dict[str, object]:
    """Everything a reviewer should be told rather than have to discover."""
    stale = [r.ticker for r in rows if r.has_price_fallback]
    manual = [r.ticker for r in rows if r.has_manual_level]
    proxy_duration = [
        r.ticker for r in rows if r.duration_source == DurationSource.PROXY.value
    ]
    unavailable_duration = [
        r.ticker for r in rows if r.duration_source == DurationSource.UNAVAILABLE.value
    ]
    unpriced = [
        r.ticker for r in rows if not r.is_funding_offset and r.latest_level is None
    ]
    thin_vol = [
        r.ticker
        for r in rows
        if r.vol_note and r.vol_observations < settings.analytics.volatility.min_observations
    ]
    recon = pnl_svc.reconcile(db, portfolio, valuation_date)
    return {
        "prices_with_fallback": stale,
        "manual_execution_levels": manual,
        "duration_from_proxy": proxy_duration,
        "duration_unavailable": unavailable_duration,
        "unpriced_instruments": unpriced,
        "thin_volatility_samples": thin_vol,
        "reconciliation": recon,
    }


# ---------------------------------------------------------------------------
# Snapshot exposure (target book, as opposed to reconstructed positions)
# ---------------------------------------------------------------------------
def snapshot_exposure(db: Session, snapshot) -> Dict[str, object]:
    """
    Aggregate a target snapshot directly from its rows.

    Used by the "Selected snapshot exposure" column so a user can compare
    intended positioning against the reconstructed live book without the
    snapshot having to be materialised into trades first.
    """
    rows: List[PositionRow] = []
    for r in snapshot.rows:
        inst = r.instrument
        rows.append(
            PositionRow(
                ticker=r.bbg_ticker,
                instrument_name=inst.instrument_name if inst else r.bbg_ticker,
                level_1=inst.level_1 if inst else "Unclassified",
                level_2=inst.level_2 if inst else "Unclassified",
                level_3=inst.level_3 if inst else "Unclassified",
                level_4=inst.level_4 if inst else "Unclassified",
                net_weight_pct=r.target_weight_pct,
                is_funding_offset=r.is_funding_offset,
            )
        )
    market = [r for r in rows if not r.is_funding_offset]
    return {
        "snapshot_id": snapshot.id,
        "snapshot_date": snapshot.snapshot_date,
        "label": snapshot.label,
        "rows": [r.as_dict() for r in rows],
        "totals": _totals(market),
        "rollups": {
            level: [b.as_dict() for b in build_rollup(market, level).values()]
            for level in ("level_1", "level_2", "level_3", "level_4")
        },
    }
