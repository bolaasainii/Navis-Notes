"""
Instrument master ingestion and search.

The seed file `bloomberg_futures_hierarchy.csv` is the canonical taxonomy. It
is loaded on first run and can be replaced later by uploading a revised
CSV/XLSX through Settings -> Instrument Master.

Ingestion rules
---------------
* The natural key is the FULL Bloomberg ticker, i.e. root code + yellow key.
  This matters: the shipped seed contains `NO1 Index` (Nikkei 225 mini) and
  `NO1 Curncy` (Norwegian krone). Keying on the root code alone would silently
  collapse two unrelated instruments.
* Column names are matched case- and punctuation-insensitively against a set
  of aliases, so a revised file with "Bloomberg Formula" instead of
  "Bloomberg Code" loads without a code change.
* Reload is non-destructive: instruments absent from a new file are marked
  inactive rather than deleted, because trades may reference them.
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.config import settings
from app.models import InstrumentMaster, InstrumentMasterVersion
from app.services import audit

logger = logging.getLogger(__name__)

# --- column aliasing -------------------------------------------------------
# Keys are canonical field names; values are accepted header spellings.
COLUMN_ALIASES: Dict[str, Sequence[str]] = {
    "level_1": ("level 1", "level1", "l1", "asset class"),
    "level_2": ("level 2", "level2", "l2", "exposure bucket"),
    "level_3": ("level 3", "level3", "l3", "subgroup"),
    "level_4": ("level 4", "level4", "l4", "granular"),
    "instrument_name": (
        "exposure / instrument name",
        "exposure/instrument name",
        "instrument name",
        "exposure",
        "name",
    ),
    "bbg_code": (
        "bloomberg code",
        "bloomberg formula",
        "bbg code",
        "bbg formula",
        "ticker",
        "bloomberg ticker",
    ),
    "yellow_key": ("bloomberg yellow key", "yellow key", "yellow_key", "market sector"),
    "primary_exchange": ("primary exchange", "exchange"),
    "notes": ("notes", "note", "comment", "comments"),
}

REQUIRED_FIELDS = ("level_1", "instrument_name", "bbg_code")

_SEPARATOR_RE = re.compile(r"[_\-]+")
_NORMALISE_RE = re.compile(r"[^a-z0-9/ ]+")
_SPACES_RE = re.compile(r"\s+")


def _normalise_header(h: str) -> str:
    """
    Fold a header (or an alias) to a comparable form.

    Underscores and hyphens become spaces FIRST, so `Level 1`, `level_1` and
    `LEVEL-1` all normalise to `level 1`.
    """
    s = _SEPARATOR_RE.sub(" ", (h or "").strip().lower())
    s = _NORMALISE_RE.sub("", s)
    return _SPACES_RE.sub(" ", s).strip()


def map_columns(headers: Sequence[str]) -> Dict[str, str]:
    """Return {canonical_field: actual_header}. Unmatched fields are omitted."""
    normalised = {_normalise_header(h): h for h in headers}
    mapping: Dict[str, str] = {}
    for canonical, aliases in COLUMN_ALIASES.items():
        for alias in aliases:
            key = _normalise_header(alias)
            if key in normalised:
                mapping[canonical] = normalised[key]
                break
    return mapping


_SQUASH_RE = re.compile(r"[^a-z0-9]+")
# "10yr", "10 year", "10-Year" all mean the same tenor as the master's "10Y".
_TENOR_RE = re.compile(r"\b(\d+)\s*-?\s*(?:yr|yrs|year|years)\b")


def _squash(text: str) -> str:
    """
    Lower-case, normalise tenor spellings, and strip every non-alphanumeric
    character.

        "S&P 500 E-mini"    -> "sp500emini"
        "sp500"             -> "sp500"
        "Nasdaq-100"        -> "nasdaq100"
        "10yr Treasury"     -> "10ytreasury"
        "10Y Treasury bond" -> "10ytreasurybond"

    Used for search matching only. Never for storage or for anything that
    reaches Bloomberg - two distinct instruments can squash to the same string.
    """
    lowered = _TENOR_RE.sub(r"\1y", (text or "").lower())
    return _SQUASH_RE.sub("", lowered)


def _tokens(text: str) -> List[str]:
    """Squashed word tokens, for all-terms-must-appear matching."""
    lowered = _TENOR_RE.sub(r"\1y", (text or "").lower())
    return [t for t in (_SQUASH_RE.sub("", w) for w in lowered.split()) if t]


def compose_ticker(code: str, yellow_key: str | None) -> str:
    """
    Build the full Bloomberg ticker.

    If the code already carries the yellow key (as it does in the shipped seed,
    e.g. "ES1 Index") it is returned normalised. Otherwise the yellow key is
    appended.
    """
    code = (code or "").strip()
    yk = (yellow_key or "").strip()
    if not code:
        return ""
    # Collapse internal whitespace but preserve the single separating space -
    # note "Z 1 Index" (FTSE 100) and "G 1 Comdty" (Long Gilt) legitimately
    # contain a space inside the root.
    code = re.sub(r"\s+", " ", code)
    if yk and not code.lower().endswith(yk.lower()):
        return f"{code} {yk}"
    return code


def split_ticker(ticker: str) -> Tuple[str, str]:
    """Split a full ticker into (root_code, yellow_key). Best-effort."""
    parts = (ticker or "").strip().rsplit(" ", 1)
    if len(parts) == 2 and parts[1]:
        return parts[0], parts[1]
    return ticker, ""


# ---------------------------------------------------------------------------
# Ingestion
# ---------------------------------------------------------------------------
@dataclass
class IngestResult:
    version: int
    row_count: int = 0
    added: int = 0
    updated: int = 0
    unchanged: int = 0
    deactivated: int = 0
    skipped: List[str] = field(default_factory=list)
    column_mapping: Dict[str, str] = field(default_factory=dict)

    def as_dict(self) -> dict:
        return {
            "version": self.version,
            "row_count": self.row_count,
            "added": self.added,
            "updated": self.updated,
            "unchanged": self.unchanged,
            "deactivated": self.deactivated,
            "skipped": self.skipped,
            "column_mapping": self.column_mapping,
        }


def _read_rows(content: bytes, filename: str) -> Tuple[List[dict], List[str]]:
    """Parse CSV or XLSX bytes into a list of dicts plus the header list."""
    lower = filename.lower()
    if lower.endswith((".xlsx", ".xlsm", ".xltx")):
        try:
            from openpyxl import load_workbook
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError("openpyxl is required to read XLSX files") from exc
        wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
        ws = wb[wb.sheetnames[0]]
        rows_iter = ws.iter_rows(values_only=True)
        try:
            header_row = next(rows_iter)
        except StopIteration:
            return [], []
        headers = [str(h).strip() if h is not None else "" for h in header_row]
        out = []
        for values in rows_iter:
            if values is None or all(v is None or str(v).strip() == "" for v in values):
                continue
            out.append(
                {
                    headers[i]: ("" if i >= len(values) or values[i] is None else str(values[i]))
                    for i in range(len(headers))
                }
            )
        return out, headers

    text = content.decode("utf-8-sig", errors="replace")
    reader = csv.DictReader(io.StringIO(text))
    headers = list(reader.fieldnames or [])
    rows = [r for r in reader if any((v or "").strip() for v in r.values())]
    return rows, headers


def ingest_instrument_master(
    db: Session,
    *,
    content: bytes,
    filename: str,
    actor: str | None = None,
    deactivate_missing: bool = True,
) -> IngestResult:
    """
    Load or refresh the instrument master from CSV/XLSX bytes.

    Existing instruments are updated in place (preserving their primary key so
    that historical trades keep resolving). Instruments not present in the new
    file are deactivated, never deleted.
    """
    rows, headers = _read_rows(content, filename)
    mapping = map_columns(headers)

    missing_required = [f for f in REQUIRED_FIELDS if f not in mapping]
    if missing_required:
        raise ValueError(
            "Instrument master file is missing required column(s): "
            + ", ".join(missing_required)
            + f". Found headers: {headers}"
        )

    prior_version = db.scalar(select(func.max(InstrumentMasterVersion.version))) or 0
    version = prior_version + 1
    result = IngestResult(version=version, column_mapping=mapping)

    existing: Dict[str, InstrumentMaster] = {
        inst.bbg_ticker: inst
        for inst in db.scalars(select(InstrumentMaster).where(InstrumentMaster.is_synthetic.is_(False)))
    }
    seen: set[str] = set()

    def cell(row: dict, canonical: str) -> str:
        header = mapping.get(canonical)
        if header is None:
            return ""
        return (row.get(header) or "").strip()

    for idx, row in enumerate(rows, start=2):  # row 1 is the header
        result.row_count += 1
        code = cell(row, "bbg_code")
        yellow = cell(row, "yellow_key")
        ticker = compose_ticker(code, yellow)
        name = cell(row, "instrument_name")

        if not ticker or not name:
            result.skipped.append(f"row {idx}: missing ticker or instrument name")
            continue
        if ticker in seen:
            result.skipped.append(f"row {idx}: duplicate ticker {ticker!r} - first occurrence wins")
            continue
        seen.add(ticker)

        if not yellow:
            _, yellow = split_ticker(ticker)

        payload = dict(
            bbg_ticker=ticker,
            bbg_code=code or ticker,
            yellow_key=yellow,
            level_1=cell(row, "level_1") or "Unclassified",
            level_2=cell(row, "level_2") or "Unclassified",
            level_3=cell(row, "level_3") or "Unclassified",
            level_4=cell(row, "level_4") or "Unclassified",
            instrument_name=name,
            primary_exchange=cell(row, "primary_exchange") or None,
            notes=cell(row, "notes") or None,
            source_file=filename,
            source_row_number=idx,
            master_version=version,
            is_active=True,
        )

        inst = existing.get(ticker)
        if inst is None:
            db.add(InstrumentMaster(**payload))
            result.added += 1
        else:
            changed = any(
                getattr(inst, k) != v
                for k, v in payload.items()
                if k not in ("source_file", "source_row_number", "master_version")
            )
            for k, v in payload.items():
                setattr(inst, k, v)
            if changed:
                result.updated += 1
            else:
                result.unchanged += 1

    if deactivate_missing:
        for ticker, inst in existing.items():
            if ticker in seen or not inst.is_active:
                continue
            # Manually-added instruments are NOT in the seed file by definition.
            # Deactivating them on every reload would silently delete the
            # classifications users captured, and break any book holding them.
            # They persist until someone explicitly retires them, and they are
            # exportable so they can be folded into the next master revision.
            if inst.source_file == ADHOC_SOURCE:
                continue
            inst.is_active = False
            result.deactivated += 1

    db.add(
        InstrumentMasterVersion(
            version=version,
            source_filename=filename,
            source_sha256=hashlib.sha256(content).hexdigest(),
            row_count=result.row_count,
            added_count=result.added,
            updated_count=result.updated,
            deactivated_count=result.deactivated,
            column_mapping_json=json.dumps(mapping),
            loaded_by=actor,
        )
    )
    audit.record(
        db,
        category="instrument_master",
        action="ingest",
        summary=(
            f"Instrument master v{version} from {filename}: "
            f"+{result.added} new, {result.updated} updated, "
            f"{result.deactivated} deactivated"
        ),
        actor=actor,
        detail=result.as_dict(),
    )
    db.flush()
    return result


def ensure_synthetic_instruments(db: Session) -> None:
    """
    Create the funding sleeve pseudo-instrument.

    It is deliberately classified outside the market hierarchy so that it never
    pollutes an equity/FI/FX aggregate. It is a financing line, not a risk
    position, and the UI hides it by default.
    """
    ticker = settings.funding.offset_ticker
    if db.scalar(select(InstrumentMaster).where(InstrumentMaster.bbg_ticker == ticker)):
        return
    db.add(
        InstrumentMaster(
            bbg_ticker=ticker,
            bbg_code=ticker,
            yellow_key="Synthetic",
            level_1="Cash & Funding",
            level_2="Funding Sleeve",
            level_3="USD Financing",
            level_4="Residual Cash",
            instrument_name=settings.funding.offset_display_name,
            primary_exchange=None,
            notes=(
                "Synthetic balancing sleeve. Automatically maintained so the book "
                "nets to 0% notional. Accrues the configured funding benchmark; "
                "carries no market price and no duration."
            ),
            is_synthetic=True,
            is_active=True,
            master_version=0,
        )
    )
    db.flush()


def seed_from_disk(db: Session, *, force: bool = False, actor: str | None = None) -> IngestResult | None:
    """
    Load the on-disk seed file if the master is empty (or force=True).

    REPOINT SHARED DRIVE LATER - the seed path comes from
    settings.paths.instrument_seed_file (config/settings.yaml ->
    paths.instrument_master_seed).
    """
    ensure_synthetic_instruments(db)
    have = db.scalar(
        select(func.count(InstrumentMaster.id)).where(InstrumentMaster.is_synthetic.is_(False))
    )
    if have and not force:
        return None

    seed_path: Path = settings.paths.instrument_seed_file
    if not seed_path.exists():
        logger.warning(
            "Instrument master seed not found at %s - starting with an empty master. "
            "REPOINT SHARED DRIVE LATER",
            seed_path,
        )
        return None

    return ingest_instrument_master(
        db,
        content=seed_path.read_bytes(),
        filename=seed_path.name,
        actor=actor or "startup-seed",
    )


# ---------------------------------------------------------------------------
# Lookup / search
# ---------------------------------------------------------------------------
def get_by_ticker(db: Session, ticker: str) -> Optional[InstrumentMaster]:
    if not ticker:
        return None
    exact = db.scalar(
        select(InstrumentMaster).where(InstrumentMaster.bbg_ticker == ticker.strip())
    )
    if exact:
        return exact
    # Case-insensitive and whitespace-tolerant retry.
    cleaned = re.sub(r"\s+", " ", ticker.strip())
    return db.scalar(
        select(InstrumentMaster).where(
            func.lower(InstrumentMaster.bbg_ticker) == cleaned.lower()
        )
    )


def resolve_ticker(db: Session, raw: str) -> Tuple[Optional[InstrumentMaster], List[str]]:
    """
    Resolve a user- or file-supplied ticker to an instrument.

    Returns (instrument, messages). Messages explain any fuzzy resolution so
    that the import preview can show the user exactly what happened.
    """
    messages: List[str] = []
    if not raw or not raw.strip():
        return None, ["empty ticker"]

    raw = re.sub(r"\s+", " ", raw.strip())
    inst = get_by_ticker(db, raw)
    if inst:
        return inst, messages

    # Ticker supplied without a yellow key, e.g. "ES1". Accept only if the
    # root is unambiguous across yellow keys - "NO1" is not.
    candidates = list(
        db.scalars(
            select(InstrumentMaster).where(
                func.lower(InstrumentMaster.bbg_code) == raw.lower()
            )
        )
    )
    if not candidates:
        candidates = list(
            db.scalars(
                select(InstrumentMaster).where(
                    func.lower(InstrumentMaster.bbg_ticker).like(f"{raw.lower()} %")
                )
            )
        )
    if len(candidates) == 1:
        messages.append(
            f"resolved {raw!r} to {candidates[0].bbg_ticker!r} (yellow key inferred)"
        )
        return candidates[0], messages
    if len(candidates) > 1:
        opts = ", ".join(c.bbg_ticker for c in candidates)
        return None, [f"{raw!r} is ambiguous without a yellow key - candidates: {opts}"]

    # Last resort: exact instrument-name match.
    by_name = list(
        db.scalars(
            select(InstrumentMaster).where(
                func.lower(InstrumentMaster.instrument_name) == raw.lower()
            )
        )
    )
    if len(by_name) == 1:
        messages.append(f"resolved {raw!r} by instrument name to {by_name[0].bbg_ticker!r}")
        return by_name[0], messages

    return None, [f"{raw!r} not found in the instrument master"]


# ---------------------------------------------------------------------------
# Ad-hoc instruments
# ---------------------------------------------------------------------------
ADHOC_SOURCE = "manual-entry"


PLACEHOLDER_LEVELS = {"", "unclassified", "n/a", "na", "-", "tbd", "other"}

# Words that carry no classifying signal, so they should not create a match.
_STOPWORDS = {
    "the", "a", "an", "of", "and", "index", "future", "futures", "cont", "generic",
    "1st", "mini", "micro", "e", "cme", "cbot", "ice", "eurex",
}


def suggest_classification(
    db: Session, bbg_ticker: str, description: str = ""
) -> Optional[Dict[str, str]]:
    """
    Propose a hierarchy for an instrument the master does not contain.

    The suggestion is derived from YOUR taxonomy, not Bloomberg's. Bloomberg has
    no field for "is this Developed Non-US" or "is this G10 FX" - those are house
    views, and inventing a mapping and calling it Bloomberg's would be worse than
    offering nothing. So instead we find the closest instrument already in the
    master (same yellow key, most overlapping description words) and offer its
    classification as a starting point, naming the row it came from.

    It is a SUGGESTION. `create_adhoc` still requires all four levels, and the
    user can overwrite every one of them. Returns None when nothing is close
    enough to be worth proposing.
    """
    _, yellow = split_ticker(bbg_ticker)
    text = f"{description} {bbg_ticker}"
    want = {t for t in _tokens(text) if t not in _STOPWORDS and len(t) > 1}
    if not want:
        return None

    candidates = db.scalars(
        select(InstrumentMaster).where(
            InstrumentMaster.is_active.is_(True),
            InstrumentMaster.is_synthetic.is_(False),
        )
    )

    best = None
    best_score = 0.0
    for inst in candidates:
        have = {
            t
            for t in _tokens(f"{inst.instrument_name} {inst.level_3} {inst.level_4}")
            if t not in _STOPWORDS and len(t) > 1
        }
        if not have:
            continue
        overlap = want & have
        if not overlap:
            continue
        # Jaccard, nudged up when the yellow keys agree.
        score = len(overlap) / len(want | have)
        if yellow and inst.yellow_key and yellow.lower() == inst.yellow_key.lower():
            score *= 1.5
        if score > best_score:
            best_score, best = score, inst

    if best is None or best_score < 0.15:
        return None
    return {
        "level_1": best.level_1,
        "level_2": best.level_2,
        "level_3": best.level_3,
        "level_4": best.level_4,
        "basis": f"closest match in your master: {best.bbg_ticker} ({best.instrument_name})",
    }


def _require_classification(level_1: str, level_2: str, level_3: str, level_4: str) -> None:
    """
    Every level must be a real bucket.

    An unclassified instrument is invisible to `build_rollup`, contributes no
    duration, and gets no colour in attribution - it quietly disappears from
    every aggregate while still consuming weight. Refusing it at entry is the
    only place the cost is cheap.
    """
    labels = (("Level 1", level_1), ("Level 2", level_2), ("Level 3", level_3), ("Level 4", level_4))
    missing = [name for name, value in labels if (value or "").strip().lower() in PLACEHOLDER_LEVELS]
    if missing:
        raise ValueError(
            f"{', '.join(missing)} must be classified. An instrument with no hierarchy "
            "drops out of asset-class rollups, duration and attribution."
        )


def create_adhoc(
    db: Session,
    *,
    bbg_ticker: str,
    instrument_name: Optional[str] = None,
    level_1: str,
    level_2: str,
    level_3: str,
    level_4: str,
    primary_exchange: Optional[str] = None,
    notes: Optional[str] = None,
    actor: Optional[str] = None,
    require_validation: bool = True,
) -> Tuple[InstrumentMaster, List[str]]:
    """
    Add an instrument the seeded master does not contain.

    This is the escape hatch for the case that always eventually happens: a
    trader wants an instrument nobody put in the taxonomy file. Rather than
    blocking them, we let them type the Bloomberg ticker, VALIDATE it against
    Bloomberg, and add it to the master so that trades, hierarchy rollups and
    analytics all work normally from then on.

    Validation calls a small ReferenceDataRequest. In live mode an unknown or
    unentitled ticker fails loudly here, at the point of entry, rather than
    silently producing an unpriced row later. In offline mode nothing can be
    validated, so the instrument is added but tagged `unvalidated` and shown
    with a warning - it will be re-validated the first time it is priced live.

    Ad-hoc instruments are flagged (`source_file='manual-entry'`) so they are
    easy to find and fold into the next revision of the master file.
    """
    from app.bloomberg.base import parse_security_string

    _require_classification(level_1, level_2, level_3, level_4)

    messages: List[str] = []
    raw = (bbg_ticker or "").strip()
    # Accept the Terminal's own display notation as well as the canonical form,
    # because "SPX<index>" is what you get when you copy out of a Bloomberg
    # window and it is not an unreasonable thing for a user to paste.
    ticker, _parsed_yk = parse_security_string(raw)
    if ticker != re.sub(r"\s+", " ", raw) and raw:
        messages.append(f"Interpreted {raw!r} as {ticker!r}")
    if not ticker:
        raise ValueError("A Bloomberg ticker is required")

    existing = get_by_ticker(db, ticker)
    if existing is not None:
        if not existing.is_active:
            existing.is_active = True
            messages.append(f"{ticker} already existed but was inactive; it has been reactivated")
        return existing, messages

    if " " not in ticker:
        raise ValueError(
            f"{ticker!r} has no yellow key. Bloomberg tickers need one, e.g. "
            "'TSLA US Equity', 'ES1 Index', 'TY1 Comdty', 'EURUSD Curncy'."
        )

    _, yellow = split_ticker(ticker)
    resolved_name = (instrument_name or "").strip()
    validation_status = "unvalidated"

    from app.bloomberg import get_provider  # local import avoids a cycle

    provider = get_provider()
    if provider.is_live:
        try:
            data = provider.reference([ticker], ["NAME", "CRNCY", "PX_LAST"]).get(ticker, {})
        except Exception as exc:  # network/session problem, not a bad ticker
            if require_validation:
                raise ValueError(f"Could not validate {ticker!r} against Bloomberg: {exc}") from exc
            data = {}
            messages.append(f"Bloomberg validation failed ({exc}); added unvalidated")
        else:
            if data.get("_error") or not data:
                raise ValueError(
                    f"Bloomberg does not recognise {ticker!r}, or you are not entitled to it. "
                    "Check the ticker on the Terminal (try SECF <GO>) and the yellow key."
                )
            validation_status = "validated"
            if not resolved_name:
                resolved_name = str(data.get("NAME") or ticker)
            messages.append(f"Validated against Bloomberg ({data.get('CRNCY') or 'currency unknown'})")
    else:
        messages.append(
            "Offline mode: the ticker could not be validated against Bloomberg. "
            "It will be checked the first time it is priced live."
        )

    instrument = InstrumentMaster(
        bbg_ticker=ticker,
        bbg_code=ticker,
        yellow_key=yellow,
        level_1=level_1.strip(),
        level_2=level_2.strip(),
        level_3=level_3.strip(),
        level_4=level_4.strip(),
        instrument_name=resolved_name or ticker,
        primary_exchange=primary_exchange,
        notes=notes,
        is_active=True,
        source_file=ADHOC_SOURCE,
        master_version=0,
        validated_at=datetime.utcnow() if validation_status == "validated" else None,
        validation_status=validation_status,
    )
    db.add(instrument)
    db.flush()

    audit.record(
        db,
        category="instrument_master",
        action="add_adhoc",
        summary=f"Added ad-hoc instrument {ticker} ({validation_status})",
        entity_type="instrument",
        entity_id=instrument.id,
        bbg_ticker=ticker,
        actor=actor,
        detail={
            "name": instrument.instrument_name,
            "hierarchy": [level_1, level_2, level_3, level_4],
            "validation_status": validation_status,
            "messages": messages,
        },
    )
    return instrument, messages


def adhoc_instruments(db: Session) -> List[InstrumentMaster]:
    """Everything added by hand - the shortlist for the next master file revision."""
    return list(
        db.scalars(
            select(InstrumentMaster)
            .where(InstrumentMaster.source_file == ADHOC_SOURCE)
            .order_by(InstrumentMaster.created_at.desc())
        )
    )


def search(
    db: Session,
    query: str,
    *,
    limit: int = 25,
    include_inactive: bool = False,
    include_synthetic: bool = False,
) -> List[InstrumentMaster]:
    """
    Ranked instrument search over ticker, name and hierarchy.

    Ranking: exact ticker > ticker prefix > name prefix > name contains >
    hierarchy contains. Deliberately simple and dependency-free; the master is
    a few hundred rows, not a few million, so it is matched in Python rather
    than in SQL.

    Matching happens twice: once on the literal lower-cased text, and once on a
    "squashed" form with every non-alphanumeric character removed. The squashed
    pass is what makes `sp500` find `S&P 500 E-mini` and `ty1` find `TY1 Comdty`
    - the punctuation in Bloomberg's exposure names is exactly what a user
    typing quickly leaves out.
    """
    q = (query or "").strip()
    stmt = select(InstrumentMaster)
    if not include_inactive:
        stmt = stmt.where(InstrumentMaster.is_active.is_(True))
    if not include_synthetic:
        stmt = stmt.where(InstrumentMaster.is_synthetic.is_(False))

    if not q:
        rows = list(db.scalars(stmt.order_by(InstrumentMaster.instrument_name).limit(limit)))
        return rows

    ql = q.lower()
    qs = _squash(q)
    q_tokens = _tokens(q) if len(_tokens(q)) > 1 else []
    rows = list(db.scalars(stmt))

    def rank(inst: InstrumentMaster) -> Optional[tuple]:
        ticker = inst.bbg_ticker.lower()
        code = (inst.bbg_code or "").lower()
        name = inst.instrument_name.lower()
        hier = " ".join(
            filter(
                None,
                (
                    inst.level_1,
                    inst.level_2,
                    inst.level_3,
                    inst.level_4,
                    inst.primary_exchange,
                ),
            )
        ).lower()

        s_ticker, s_code, s_name = _squash(ticker), _squash(code), _squash(name)
        # The root of "ES1 Index" is "es1" - a user typing a ticker rarely types
        # the yellow key, so match the root as its own alternative.
        root = split_ticker(inst.bbg_ticker)[0].lower()
        s_root = _squash(root)

        if ql in (ticker, code, root) or (qs and qs in (s_ticker, s_code, s_root)):
            score = 0
        elif ticker.startswith(ql) or code.startswith(ql) or root.startswith(ql):
            score = 1
        elif qs and (s_ticker.startswith(qs) or s_code.startswith(qs) or s_root.startswith(qs)):
            score = 2
        elif name.startswith(ql) or (qs and s_name.startswith(qs)):
            score = 3
        elif ql in name or (qs and qs in s_name):
            score = 4
        elif ql in hier or (qs and qs in _squash(hier)):
            score = 5
        elif q_tokens and all(
            t in _squash(f"{name} {ticker} {hier}") for t in q_tokens
        ):
            # Last resort: every word the user typed appears somewhere, in any
            # order. Lets "treasury 10y" and "10y treasury" both work.
            score = 6
        else:
            return None
        return (score, len(inst.instrument_name), inst.instrument_name)

    scored = [(r, rank(r)) for r in rows]
    matched = [(r, k) for r, k in scored if k is not None]
    matched.sort(key=lambda pair: pair[1])
    return [r for r, _ in matched[:limit]]


def hierarchy_tree(db: Session) -> dict:
    """Nested Level1 -> Level2 -> Level3 -> Level4 counts, for filter UI."""
    tree: dict = {}
    for inst in db.scalars(
        select(InstrumentMaster).where(
            InstrumentMaster.is_active.is_(True), InstrumentMaster.is_synthetic.is_(False)
        )
    ):
        l1 = tree.setdefault(inst.level_1, {})
        l2 = l1.setdefault(inst.level_2, {})
        l3 = l2.setdefault(inst.level_3, {})
        l3[inst.level_4] = l3.get(inst.level_4, 0) + 1
    return tree


def distinct_levels(db: Session) -> Dict[str, List[str]]:
    out: Dict[str, List[str]] = {}
    for field_name, col in (
        ("level_1", InstrumentMaster.level_1),
        ("level_2", InstrumentMaster.level_2),
        ("level_3", InstrumentMaster.level_3),
        ("level_4", InstrumentMaster.level_4),
    ):
        out[field_name] = sorted(
            v
            for (v,) in db.execute(
                select(col).where(InstrumentMaster.is_synthetic.is_(False)).distinct()
            )
            if v
        )
    return out
