"""
Pricing: cache management, execution-level resolution and fallback logic.

Why the cache stores only ACTUAL prints
---------------------------------------
BLPAPI can do the holiday fill for us (`nonTradingDayFillOption=ALL_CALENDAR_DAYS`
plus `nonTradingDayFillMethod=PREVIOUS_VALUE`). We deliberately do NOT use that
for the pricing cache. If the fill happens inside Bloomberg, a carried-forward
value is indistinguishable from a real print by the time it reaches us, and the
audit trail loses the one fact an institutional user will ask about: *was this
an actual print on that date, or the last one before it, and how stale?*

So the cache is populated with ACTIVE_DAYS_ONLY and the carry-forward is
performed here, explicitly, recording `price_observation_date` and
`price_fallback_days` on every trade. The Bloomberg-side fill is still
available (`bloomberg.historical_fill` in settings) and is used for bulk
series work where staleness is tracked separately.

Timezone perspective
--------------------
The application reasons in US dates (config: app.timezone). For an instrument
whose home market is Tokyo or Frankfurt, a US trade date may not correspond to
a new local official print - the market may be shut, or its print may be a day
stale relative to the US session. The rule is uniform and documented: use the
most recent official print at or before the requested US date, and record how
many calendar days stale that print was. No timezone arithmetic is performed on
the prices themselves, because Bloomberg already stamps each print with its
local trade date.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.bloomberg import get_provider
from app.bloomberg.base import BloombergUnavailable
from app.config import settings
from app.models import ExecutionType, LevelSource, PricingHistoryCache
from app.services import audit

logger = logging.getLogger(__name__)

PRICE_FIELDS = ("PX_OPEN", "PX_HIGH", "PX_LOW", "PX_LAST", "PX_SETTLE")

# How far back to extend a fetch so that a fallback lookup has something to
# find when the requested window opens on a holiday or a long closure.
FALLBACK_LOOKBACK_DAYS = 21


def active_provider_name() -> str:
    """
    Name of the provider for the CURRENT data mode.

    Every cache read and write in this module is scoped to it. That is what
    makes the Live / Offline toggle safe: synthetic prints cached during
    offline work can never satisfy a live lookup, and vice versa, so switching
    modes is instant and needs no purge.
    """
    return get_provider().name


@dataclass
class ResolvedLevel:
    """The outcome of asking 'what level did this trade execute at?'"""

    level: Optional[float]
    source: LevelSource
    field_used: Optional[str] = None
    observation_date: Optional[date] = None
    fallback_days: int = 0
    reason: Optional[str] = None
    # True when this level came from a Bloomberg request issued as part of THIS
    # resolution, rather than from the local cache. Surfaced in the UI and
    # recorded on the trade so "was this price live?" is always answerable.
    from_live_request: bool = False
    provider: Optional[str] = None

    @property
    def is_stale(self) -> bool:
        return self.fallback_days > 0

    @property
    def ok(self) -> bool:
        return self.level is not None


# ---------------------------------------------------------------------------
# Cache population
# ---------------------------------------------------------------------------
def _cached_range(db: Session, ticker: str) -> Tuple[Optional[date], Optional[date]]:
    provider = active_provider_name()
    row = db.execute(
        select(PricingHistoryCache.observation_date)
        .where(
            PricingHistoryCache.bbg_ticker == ticker,
            PricingHistoryCache.provider == provider,
        )
        .order_by(PricingHistoryCache.observation_date.asc())
        .limit(1)
    ).first()
    lo = row[0] if row else None
    row = db.execute(
        select(PricingHistoryCache.observation_date)
        .where(
            PricingHistoryCache.bbg_ticker == ticker,
            PricingHistoryCache.provider == provider,
        )
        .order_by(PricingHistoryCache.observation_date.desc())
        .limit(1)
    ).first()
    hi = row[0] if row else None
    return lo, hi


def ensure_prices(
    db: Session,
    tickers: Sequence[str],
    start: date,
    end: date,
    *,
    force: bool = False,
    live: bool = True,
) -> Dict[str, int]:
    """
    Make sure the cache covers [start, end] for every ticker.

    Historical gaps are backfilled once. Separately, if the requested window
    reaches into the live window (the last few days), those dates are
    re-requested from Bloomberg so that recent marks are current rather than
    whatever happened to be cached earlier - see `refresh_live_window`.

    Returns {ticker: rows_added}. Synthetic instruments are skipped: the
    funding sleeve has no market price by construction.
    """
    tickers = [t for t in dict.fromkeys(tickers) if t and t != settings.funding.offset_ticker]
    if not tickers:
        return {}

    if live and end >= _live_window_start():
        refresh_live_window(db, tickers, force=force)

    fetch_start = start - timedelta(days=FALLBACK_LOOKBACK_DAYS)
    to_fetch: List[str] = []
    for t in tickers:
        if force:
            to_fetch.append(t)
            continue
        lo, hi = _cached_range(db, t)
        if lo is None or lo > fetch_start or hi is None or hi < end:
            to_fetch.append(t)

    if not to_fetch:
        return {}

    provider = get_provider()
    try:
        # ACTIVE_DAYS_ONLY - see the module docstring for why.
        series = provider.historical(
            to_fetch, PRICE_FIELDS, fetch_start, end, calendar_fill=False
        )
    except BloombergUnavailable as exc:
        logger.error("Price fetch failed: %s", exc)
        audit.record(
            db,
            category="pricing",
            action="fetch_failed",
            summary=f"Bloomberg price fetch failed for {len(to_fetch)} ticker(s): {exc}",
            detail={"tickers": to_fetch, "start": fetch_start, "end": end},
        )
        return {}

    existing_keys = {
        (r.bbg_ticker, r.observation_date)
        for r in db.scalars(
            select(PricingHistoryCache).where(
                PricingHistoryCache.bbg_ticker.in_(to_fetch),
                PricingHistoryCache.provider == provider.name,
            )
        )
    }

    added: Dict[str, int] = {}
    for ticker, by_date in series.items():
        count = 0
        for obs_date, values in by_date.items():
            if (ticker, obs_date) in existing_keys:
                continue
            db.add(
                PricingHistoryCache(
                    bbg_ticker=ticker,
                    observation_date=obs_date,
                    px_open=_num(values.get("PX_OPEN")),
                    px_high=_num(values.get("PX_HIGH")),
                    px_low=_num(values.get("PX_LOW")),
                    px_last=_num(values.get("PX_LAST")),
                    px_settle=_num(values.get("PX_SETTLE")),
                    is_actual_print=True,
                    provider=provider.name,
                )
            )
            count += 1
        added[ticker] = count
    db.flush()
    return added


def _num(v) -> Optional[float]:
    try:
        return None if v is None else float(v)
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------------------
# Live refresh
# ---------------------------------------------------------------------------
def _live_window_start(as_of: Optional[date] = None) -> date:
    """First date considered 'live' - i.e. still subject to change."""
    as_of = as_of or date.today()
    return as_of - timedelta(days=settings.bloomberg.live_refresh_window_days)


def is_live_date(d: date, as_of: Optional[date] = None) -> bool:
    return d >= _live_window_start(as_of)


def _upsert_price(db: Session, ticker: str, obs_date: date, values: dict, provider: str) -> None:
    """Insert or overwrite a cached print for THIS provider, stamping fetch time."""
    row = get_exact_print(db, ticker, obs_date, provider=provider)
    payload = dict(
        px_open=_num(values.get("PX_OPEN")),
        px_high=_num(values.get("PX_HIGH")),
        px_low=_num(values.get("PX_LOW")),
        px_last=_num(values.get("PX_LAST")),
        px_settle=_num(values.get("PX_SETTLE")),
    )
    if row is None:
        db.add(
            PricingHistoryCache(
                bbg_ticker=ticker,
                observation_date=obs_date,
                is_actual_print=True,
                provider=provider,
                **payload,
            )
        )
        return
    for k, v in payload.items():
        if v is not None:
            setattr(row, k, v)
    row.provider = provider
    row.fetched_at = datetime.utcnow()


def _needs_live_refresh(db: Session, ticker: str, as_of: date) -> bool:
    """
    True when the live window for this ticker has not been requested recently.

    Throttled by `bloomberg.live_refresh_ttl_minutes` so that a screen refresh
    does not hammer the Terminal; set that to 0 to always go live.
    """
    ttl = settings.bloomberg.live_refresh_ttl_minutes
    if ttl <= 0:
        return True
    newest = db.scalars(
        select(PricingHistoryCache)
        .where(
            PricingHistoryCache.bbg_ticker == ticker,
            PricingHistoryCache.provider == active_provider_name(),
            PricingHistoryCache.observation_date >= _live_window_start(as_of),
        )
        .order_by(PricingHistoryCache.fetched_at.desc())
        .limit(1)
    ).first()
    if newest is None:
        return True
    return (datetime.utcnow() - newest.fetched_at) > timedelta(minutes=ttl)


def refresh_live_window(
    db: Session,
    tickers: Sequence[str],
    *,
    as_of: Optional[date] = None,
    force: bool = False,
) -> Dict[str, int]:
    """
    Re-request the last `live_refresh_window_days` of prints from Bloomberg and
    overwrite the cache for those dates.

    This is the mechanism that makes both of the following genuinely live
    rather than cache-warmed:

      * the execution level for a trade dated today or in the last few sessions;
      * the "Latest" mark used for unrealised P&L and for today's carry.

    Prints older than the window are settled history and are deliberately left
    alone - re-requesting years of unchanged data on every screen refresh would
    be pointless load on the Terminal.
    """
    as_of = as_of or date.today()
    tickers = [t for t in dict.fromkeys(tickers) if t and t != settings.funding.offset_ticker]
    if not tickers:
        return {}

    due = tickers if force else [t for t in tickers if _needs_live_refresh(db, t, as_of)]
    if not due:
        return {}

    provider = get_provider()
    start = _live_window_start(as_of)
    try:
        series = provider.historical(due, PRICE_FIELDS, start, as_of, calendar_fill=False)
    except BloombergUnavailable as exc:
        logger.warning("Live price refresh failed: %s", exc)
        audit.record(
            db,
            category="pricing",
            action="live_refresh_failed",
            summary=(
                f"Live Bloomberg refresh failed for {len(due)} ticker(s); "
                f"cached prices will be used instead: {exc}"
            ),
            detail={"tickers": due, "start": start, "as_of": as_of},
        )
        return {}

    counts: Dict[str, int] = {}
    for ticker, by_date in series.items():
        for obs_date, values in by_date.items():
            _upsert_price(db, ticker, obs_date, values, provider.name)
            counts[ticker] = counts.get(ticker, 0) + 1
    db.flush()
    logger.debug("Live refresh: %s ticker(s), %s print(s)", len(counts), sum(counts.values()))
    return counts


# ---------------------------------------------------------------------------
# Lookups
# ---------------------------------------------------------------------------
def get_print(
    db: Session, ticker: str, on_or_before: date, *, provider: Optional[str] = None
) -> Optional[PricingHistoryCache]:
    """Most recent actual print at or before `on_or_before`, for the active provider."""
    return db.scalars(
        select(PricingHistoryCache)
        .where(
            PricingHistoryCache.bbg_ticker == ticker,
            PricingHistoryCache.provider == (provider or active_provider_name()),
            PricingHistoryCache.observation_date <= on_or_before,
        )
        .order_by(PricingHistoryCache.observation_date.desc())
        .limit(1)
    ).first()


def get_exact_print(
    db: Session, ticker: str, on: date, *, provider: Optional[str] = None
) -> Optional[PricingHistoryCache]:
    return db.scalars(
        select(PricingHistoryCache).where(
            PricingHistoryCache.bbg_ticker == ticker,
            PricingHistoryCache.provider == (provider or active_provider_name()),
            PricingHistoryCache.observation_date == on,
        )
    ).first()


def close_series(
    db: Session, ticker: str, start: date, end: date
) -> List[Tuple[date, float]]:
    """Actual closes only, ascending. Used by the volatility engine."""
    rows = db.scalars(
        select(PricingHistoryCache)
        .where(
            PricingHistoryCache.bbg_ticker == ticker,
            PricingHistoryCache.provider == active_provider_name(),
            PricingHistoryCache.observation_date >= start,
            PricingHistoryCache.observation_date <= end,
        )
        .order_by(PricingHistoryCache.observation_date.asc())
    ).all()
    out: List[Tuple[date, float]] = []
    for r in rows:
        px = _preferred_close(r)
        if px is not None:
            out.append((r.observation_date, px))
    return out


def _preferred_close(row: PricingHistoryCache) -> Optional[float]:
    """Official close, using the configured field priority."""
    for field in settings.bloomberg.close_field_priority:
        value = getattr(row, field.lower().replace("px_", "px_"), None)
        if field == "PX_SETTLE":
            value = row.px_settle
        elif field == "PX_LAST":
            value = row.px_last
        if value is not None:
            return float(value)
    return row.px_last if row.px_last is not None else row.px_settle


def close_field_name(row: PricingHistoryCache) -> str:
    for field in settings.bloomberg.close_field_priority:
        if field == "PX_SETTLE" and row.px_settle is not None:
            return "PX_SETTLE"
        if field == "PX_LAST" and row.px_last is not None:
            return "PX_LAST"
    return "PX_LAST"


# ---------------------------------------------------------------------------
# Execution-level resolution
# ---------------------------------------------------------------------------
def resolve_execution_level(
    db: Session,
    *,
    ticker: str,
    trade_date: date,
    execution_type: ExecutionType,
    custom_level: Optional[float] = None,
    imported: bool = False,
    autofetch: bool = True,
) -> ResolvedLevel:
    """
    Determine the level a trade executed at, with a fully documented fallback.

    Mkt Close
        Official close for `trade_date`, using bloomberg.close_field_priority
        (PX_SETTLE then PX_LAST - settle is the official mark for a futures
        contract; PX_LAST covers instruments that do not publish a settle).
        If there is no print on `trade_date` - holiday, market closure, or a
        non-US market that simply did not trade that day - the most recent
        prior official print is used and the staleness is recorded.

    Mkt Open
        Official open (PX_OPEN) for `trade_date`.
        FALLBACK RULE, in order:
          1. PX_OPEN on `trade_date`;
          2. if `trade_date` has a print but no open (some contracts do not
             publish one), the PRIOR trading day's official close - this is the
             most defensible proxy for "the level available at the start of the
             session", and is tagged as a fallback;
          3. if `trade_date` has no print at all, the most recent prior
             official close.
        Every one of these is tagged bloomberg_fallback with a reason string.

    Custom
        The user-supplied level is used verbatim and tagged manual. It is never
        overwritten by a later refresh.
    """
    if execution_type == ExecutionType.CUSTOM:
        if custom_level is None:
            return ResolvedLevel(
                None,
                LevelSource.MANUAL,
                reason="Custom execution requires a level but none was supplied",
            )
        return ResolvedLevel(
            level=float(custom_level),
            source=LevelSource.IMPORTED if imported else LevelSource.MANUAL,
            field_used=None,
            observation_date=trade_date,
            fallback_days=0,
            reason="User-supplied custom level",
        )

    if ticker == settings.funding.offset_ticker:
        return ResolvedLevel(
            level=100.0,
            source=LevelSource.SYNTHETIC,
            observation_date=trade_date,
            reason="Funding sleeve carries a notional par level, not a market price",
        )

    # --- make sure we are pricing off live data where "live" is meaningful ---
    # A trade dated inside the live window (today, or the last few sessions) is
    # re-requested from Bloomberg before the level is resolved. A trade dated
    # months ago is settled history and is served from cache, which is both
    # correct and far kinder to the Terminal.
    live_request = False
    provider_name = get_provider().name
    if autofetch:
        if is_live_date(trade_date):
            refreshed = refresh_live_window(db, [ticker], as_of=max(trade_date, date.today()))
            live_request = bool(refreshed)
        ensure_prices(
            db,
            [ticker],
            trade_date - timedelta(days=FALLBACK_LOOKBACK_DAYS),
            trade_date,
            live=False,
        )

    if settings.bloomberg.require_live_execution_prices and is_live_date(trade_date):
        if not get_provider().is_live:
            return ResolvedLevel(
                None,
                LevelSource.BLOOMBERG,
                reason=(
                    "require_live_execution_prices is enabled and no live Bloomberg "
                    "session is available, so this trade cannot be priced. Start the "
                    "Terminal, or disable the setting to book against cached data."
                ),
                provider=provider_name,
            )
        if not live_request:
            # The throttle suppressed the request - force one, because this
            # setting says correctness beats Terminal load.
            live_request = bool(
                refresh_live_window(db, [ticker], as_of=max(trade_date, date.today()), force=True)
            )
            if not live_request:
                return ResolvedLevel(
                    None,
                    LevelSource.BLOOMBERG,
                    reason=(
                        "require_live_execution_prices is enabled but the live Bloomberg "
                        "request returned nothing for this instrument."
                    ),
                    provider=provider_name,
                )

    def _stamp(result: ResolvedLevel) -> ResolvedLevel:
        """Record whether this level came from a live request or the cache."""
        result.from_live_request = live_request
        result.provider = provider_name
        return result

    exact = get_exact_print(db, ticker, trade_date)

    if execution_type == ExecutionType.MKT_CLOSE:
        row = exact or get_print(db, ticker, trade_date)
        if row is None:
            return _stamp(ResolvedLevel(
                None,
                LevelSource.BLOOMBERG,
                reason=f"No official print found on or before {trade_date.isoformat()}",
            ))
        px = _preferred_close(row)
        if px is None:
            return _stamp(ResolvedLevel(
                None,
                LevelSource.BLOOMBERG,
                reason=f"Print exists for {row.observation_date} but carries no close",
            ))
        stale = (trade_date - row.observation_date).days
        return _stamp(ResolvedLevel(
            level=px,
            source=LevelSource.BLOOMBERG if stale == 0 else LevelSource.BLOOMBERG_FALLBACK,
            field_used=close_field_name(row),
            observation_date=row.observation_date,
            fallback_days=stale,
            reason=(
                None
                if stale == 0
                else (
                    f"No official print on {trade_date.isoformat()} "
                    f"(market closed or no local session); used the close of "
                    f"{row.observation_date.isoformat()}, {stale} calendar day(s) prior"
                ))
            ),
        )

    # --- Mkt Open ---------------------------------------------------------
    if exact is not None and exact.px_open is not None:
        return _stamp(ResolvedLevel(
            level=float(exact.px_open),
            source=LevelSource.BLOOMBERG,
            field_used="PX_OPEN",
            observation_date=trade_date,
            fallback_days=0,
        ))

    prior = db.scalars(
        select(PricingHistoryCache)
        .where(
            PricingHistoryCache.bbg_ticker == ticker,
            PricingHistoryCache.observation_date < trade_date,
        )
        .order_by(PricingHistoryCache.observation_date.desc())
        .limit(1)
    ).first()

    if exact is not None and prior is not None:
        px = _preferred_close(prior)
        if px is not None:
            return _stamp(ResolvedLevel(
                level=px,
                source=LevelSource.BLOOMBERG_FALLBACK,
                field_used=close_field_name(prior),
                observation_date=prior.observation_date,
                fallback_days=(trade_date - prior.observation_date).days,
                reason=(
                    f"No official open published for {trade_date.isoformat()}; "
                    f"used the prior official close of {prior.observation_date.isoformat()} "
                    "as the best available start-of-session level (fallback rule 2)"
                ),
            ))

    row = prior or get_print(db, ticker, trade_date)
    if row is None:
        return _stamp(ResolvedLevel(
            None,
            LevelSource.BLOOMBERG,
            reason=f"No official print found on or before {trade_date.isoformat()}",
        ))
    px = _preferred_close(row)
    if px is None:
        return _stamp(ResolvedLevel(
            None, LevelSource.BLOOMBERG, reason="Nearest print carries no usable level"
        ))
    return _stamp(ResolvedLevel(
        level=px,
        source=LevelSource.BLOOMBERG_FALLBACK,
        field_used=close_field_name(row),
        observation_date=row.observation_date,
        fallback_days=(trade_date - row.observation_date).days,
        reason=(
            f"Market did not trade on {trade_date.isoformat()}; used the official close of "
            f"{row.observation_date.isoformat()} (fallback rule 3)"
        ),
    ))


def log_fallback(
    db: Session,
    resolved: ResolvedLevel,
    *,
    ticker: str,
    trade_date: date,
    portfolio_pk: Optional[int] = None,
    actor: Optional[str] = None,
) -> None:
    """Write a fallback to the audit log if one occurred."""
    if not settings.audit.log_pricing_fallbacks:
        return
    if resolved.source not in (LevelSource.BLOOMBERG_FALLBACK,) and resolved.ok:
        return
    audit.record(
        db,
        category="pricing",
        action="fallback" if resolved.ok else "unresolved",
        summary=resolved.reason or "Price could not be resolved",
        portfolio_pk=portfolio_pk,
        bbg_ticker=ticker,
        actor=actor,
        detail={
            "trade_date": trade_date,
            "level": resolved.level,
            "field_used": resolved.field_used,
            "observation_date": resolved.observation_date,
            "fallback_days": resolved.fallback_days,
            "source": resolved.source.value,
        },
    )


def latest_level(
    db: Session, ticker: str, as_of: Optional[date] = None, *, refresh: bool = True
) -> Tuple[Optional[float], Optional[date]]:
    """
    Most recent official close at or before `as_of` (default: today).

    This is the mark used for unrealised P&L and for the "Latest" column. When
    `as_of` falls inside the live window the price is re-requested from
    Bloomberg first (throttled by `live_refresh_ttl_minutes`), so the mark on
    screen is current rather than whatever was cached earlier in the session.
    Pass `refresh=False` in bulk loops where the caller has already refreshed.
    """
    as_of = as_of or date.today()
    if ticker == settings.funding.offset_ticker:
        return 100.0, as_of
    if refresh and is_live_date(as_of):
        refresh_live_window(db, [ticker], as_of=as_of)
    row = get_print(db, ticker, as_of)
    if row is None:
        return None, None
    return _preferred_close(row), row.observation_date


def purge_foreign_provider_data(db: Session, *, active_provider: str) -> Dict[str, int]:
    """
    Delete cached market data that came from a DIFFERENT provider.

    This exists to prevent a specific and nasty failure: developing against the
    synthetic provider leaves `provider='fake'` rows in `pricing_history_cache`.
    When the application is later pointed at a live Terminal, `ensure_prices`
    sees the date range as already covered and never re-requests it - so a
    "live" book would silently be marked off simulated prices.

    Called at startup whenever the active provider is live. It only removes
    CACHED market data; trades, lots, snapshots and audit history are untouched.

    Note that a trade booked while the synthetic provider was active keeps the
    execution level it was booked at - that is the correct, auditable behaviour
    (`price_provider` on the trade records where it came from). If you want a
    genuinely clean live book, start a new portfolio or a new database rather
    than re-pricing history. See scripts/reset_for_live.py.
    """
    from app.models import InstrumentReferenceCache as _Ref

    price_rows = list(
        db.scalars(select(PricingHistoryCache).where(PricingHistoryCache.provider != active_provider))
    )
    ref_rows = list(
        db.scalars(
            select(_Ref).where(_Ref.provider != active_provider, _Ref.provider != "manual")
        )
    )
    for row in price_rows:
        db.delete(row)
    for row in ref_rows:
        db.delete(row)

    if price_rows or ref_rows:
        logger.warning(
            "Purged %s cached price row(s) and %s reference row(s) that were not "
            "produced by the active provider (%s). They will be re-requested from "
            "Bloomberg on demand.",
            len(price_rows),
            len(ref_rows),
            active_provider,
        )
        audit.record(
            db,
            category="pricing",
            action="purge_foreign_provider",
            summary=(
                f"Purged {len(price_rows)} price and {len(ref_rows)} reference cache "
                f"row(s) not produced by the active provider '{active_provider}'"
            ),
            detail={"active_provider": active_provider},
        )
    db.flush()
    return {"prices_purged": len(price_rows), "reference_purged": len(ref_rows)}


def stale_provider_trade_count(db: Session, *, active_provider: str) -> int:
    """
    How many trades were priced by a different provider than the active one.

    Surfaced as a warning banner rather than silently corrected: the execution
    level a trade was booked at is a historical fact and must not be rewritten.
    """
    from app.models import Trade

    return len(
        list(
            db.scalars(
                select(Trade).where(
                    Trade.is_funding_offset.is_(False),
                    Trade.price_provider.is_not(None),
                    Trade.price_provider != active_provider,
                )
            )
        )
    )


def price_freshness(db: Session, ticker: str) -> dict:
    """Diagnostic used by the UI: how current is this instrument's cache?"""
    newest = db.scalars(
        select(PricingHistoryCache)
        .where(
            PricingHistoryCache.bbg_ticker == ticker,
            PricingHistoryCache.provider == active_provider_name(),
        )
        .order_by(PricingHistoryCache.observation_date.desc())
        .limit(1)
    ).first()
    if newest is None:
        return {"ticker": ticker, "has_price": False}
    age_minutes = (datetime.utcnow() - newest.fetched_at).total_seconds() / 60.0
    return {
        "ticker": ticker,
        "has_price": True,
        "latest_observation_date": newest.observation_date,
        "fetched_at": newest.fetched_at,
        "fetch_age_minutes": round(age_minutes, 1),
        "provider": newest.provider,
        "in_live_window": is_live_date(newest.observation_date),
    }
