"""
Database engine and session management.

============================================================================
REPOINT SHARED DRIVE LATER
============================================================================
The SQLite file location comes from `settings.paths.database_file`, which is
configured in config/settings.yaml under `paths.database_path`. This module
deliberately contains no hard-coded path.

To point the application at a shared drive, set (for example):

    paths:
      database_path: "\\\\corp-fs01\\Investments\\MacroPaperBook\\ppt.sqlite"

Operational notes for shared-drive SQLite (read before doing it):
  * SQLite over SMB works, but WAL journalling does NOT work reliably on all
    network shares. `SHARED_DRIVE_JOURNAL_MODE` below switches the journal
    mode; leave it as "DELETE" for a network path and "WAL" for local disk.
  * Concurrency model is single-writer. That is appropriate for a small team
    doing occasional trade entry and lots of reading. If you outgrow it, the
    ORM layer means moving to PostgreSQL is a connection-string change plus a
    migration - no business logic changes.
  * Take a filesystem snapshot/backup of the .sqlite file before any bulk
    import; imports are non-destructive by design but backups are cheap.
============================================================================
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Iterator

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from app.config import settings

logger = logging.getLogger(__name__)

# REPOINT SHARED DRIVE LATER - journal mode must be DELETE (not WAL) when the
# database file lives on a network share. Set to "WAL" for local disk.
SHARED_DRIVE_JOURNAL_MODE = "WAL"


def _build_url() -> str:
    # REPOINT SHARED DRIVE LATER - resolved from config, never hard-coded.
    db_path = settings.paths.database_file
    db_path.parent.mkdir(parents=True, exist_ok=True)
    return f"sqlite:///{db_path.as_posix()}"


DATABASE_URL = _build_url()

engine: Engine = create_engine(
    DATABASE_URL,
    future=True,
    echo=False,
    connect_args={
        "check_same_thread": False,
        # Wait rather than fail when another user on the shared drive holds the
        # write lock. Trade entry is human-paced; 15s is generous.
        "timeout": 15,
    },
)


@event.listens_for(engine, "connect")
def _configure_sqlite(dbapi_connection, _record) -> None:
    """Enforce referential integrity and set a network-safe journal mode."""
    cur = dbapi_connection.cursor()
    cur.execute("PRAGMA foreign_keys=ON")
    try:
        cur.execute(f"PRAGMA journal_mode={SHARED_DRIVE_JOURNAL_MODE}")
    except Exception:  # pragma: no cover - some network shares refuse WAL
        logger.warning(
            "Could not set journal_mode=%s; falling back to DELETE. "
            "This is expected on a network share. REPOINT SHARED DRIVE LATER",
            SHARED_DRIVE_JOURNAL_MODE,
        )
        cur.execute("PRAGMA journal_mode=DELETE")
    cur.execute("PRAGMA synchronous=NORMAL")
    cur.close()


SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False, future=True)


def get_session() -> Iterator[Session]:
    """FastAPI dependency."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@contextmanager
def session_scope() -> Iterator[Session]:
    """Transactional scope for scripts and services."""
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


# Columns added after the first release. There is no Alembic in this project
# (deliberately - it is a single-file SQLite database on a shared drive), so
# additive schema changes are applied here at startup. Every entry must be
# NULLable or carry a default, because existing rows will not have a value.
#
# REPOINT SHARED DRIVE LATER - this runs against whatever
# config/settings.yaml -> paths.database_path resolves to.
_ADDITIVE_COLUMNS: dict[str, dict[str, str]] = {
    "trades": {
        "edited_at": "DATETIME",
        "edited_by": "VARCHAR(128)",
    },
}


def _apply_additive_migrations() -> None:
    """Add any missing columns to existing databases. Idempotent and safe."""
    from sqlalchemy import text

    with engine.begin() as conn:
        for table, columns in _ADDITIVE_COLUMNS.items():
            existing = {
                row[1] for row in conn.execute(text(f"PRAGMA table_info({table})")).fetchall()
            }
            if not existing:
                continue  # table does not exist yet; create_all will build it correctly
            for name, ddl_type in columns.items():
                if name in existing:
                    continue
                conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {name} {ddl_type}"))
                logger.info("Schema update: added %s.%s", table, name)


def init_db() -> None:
    """Create all tables and apply additive schema updates. Idempotent."""
    from app import models  # noqa: F401  (registers mappers)

    models.Base.metadata.create_all(bind=engine)
    _apply_additive_migrations()
    logger.info("Database ready at %s", settings.paths.database_file)
