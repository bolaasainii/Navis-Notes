"""
JSON API.

Everything the browser needs, and nothing it should not have. In particular:
no Bloomberg field names, session state or raw provider responses cross this
boundary - only values the server has already computed and tagged.
"""

from __future__ import annotations

import io
import logging
from datetime import date, datetime, timedelta
from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import JSONResponse, StreamingResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.bloomberg import provider_status, status as data_mode_status
from app.config import settings
from app.db import get_session
from app.models import (
    ExecutionType,
    ImportedFile,
    ImportMode,
    ImportRow,
    InstrumentMaster,
    Portfolio,
    PortfolioSnapshot,
    Trade,
    TradeLot,
    TradeSource,
)
from app.schemas import (
    AdhocInstrument,
    DataModeSwitch,
    DurationOverride,
    FundingPointUpsert,
    ImportCommit,
    LevelPreviewRequest,
    PortfolioClone,
    PortfolioCreate,
    PortfolioUpdate,
    TradeCreate,
    TradeEditIn,
    TradeVoid,
)
from app.services import (
    audit,
    datamode,
    duration as duration_svc,
    exposure,
    funding,
    imports,
    instruments,
    pnl as pnl_svc,
    portfolios,
    positions,
    pricing,
    trades as trades_svc,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["api"])


def _actor() -> str:
    """
    Placeholder identity.

    There is deliberately no authentication in this scaffold - it is designed to
    run on an internal network behind whatever SSO/reverse proxy the firm
    already operates. Every write path already threads an `actor` through to the
    audit log, so wiring a real identity later is a one-function change here.
    See README -> "Adding authentication later".
    """
    return "internal-user"


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Data mode (Live / Offline)
# ---------------------------------------------------------------------------
@router.get("/data-mode")
def get_data_mode(
    portfolio_id: Optional[str] = Query(None), db: Session = Depends(get_session)
):
    """
    Current mode plus everything the toggle needs to render itself: whether
    live is even possible on this machine, why not if it is not, and whether
    the selected book was priced in a different mode.
    """
    payload = data_mode_status()
    book = portfolios.get(db, portfolio_id) if portfolio_id else None
    payload["book"] = datamode.book_provider_mix(db, book)
    return payload


@router.post("/data-mode")
def switch_data_mode(
    payload: DataModeSwitch, db: Session = Depends(get_session)
):
    """
    Switch between Live (Bloomberg) and Offline (synthetic) data.

    Switching to live is refused - with a readable reason - when no Terminal is
    reachable, rather than failing later at the first price lookup. Nothing is
    deleted either way: the price and reference caches are scoped by provider,
    so each mode keeps its own data and switching back is lossless.
    """
    result = datamode.switch(db, payload.mode, actor=_actor())
    db.commit()
    result["book"] = datamode.book_provider_mix(
        db, portfolios.get(db, payload.portfolio_id) if payload.portfolio_id else None
    )
    return result


@router.get("/status")
def status(db: Session = Depends(get_session)):
    instrument_count = len(
        list(db.scalars(select(InstrumentMaster).where(InstrumentMaster.is_active.is_(True))))
    )
    return {
        "app": settings.app.model_dump(),
        "market_data": provider_status(),
        "instrument_count": instrument_count,
        "database": str(settings.paths.database_file),
        "funding": {
            "offset_ticker": settings.funding.offset_ticker,
            "day_count": settings.funding.day_count,
            "negative_spread_bps": settings.funding.negative_cash_spread_bps,
        },
        "server_date": date.today(),
    }


# ---------------------------------------------------------------------------
# Portfolios
# ---------------------------------------------------------------------------
@router.get("/portfolios")
def list_portfolios(
    include_archived: bool = Query(False), db: Session = Depends(get_session)
):
    return [
        portfolios.summary(db, p)
        for p in portfolios.list_portfolios(db, include_archived=include_archived)
    ]


@router.post("/portfolios", status_code=201)
def create_portfolio(payload: PortfolioCreate, db: Session = Depends(get_session)):
    try:
        p = portfolios.create(db, actor=_actor(), **payload.model_dump())
    except portfolios.PortfolioError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    db.commit()
    return portfolios.summary(db, p)


@router.get("/portfolios/{portfolio_id}")
def get_portfolio(portfolio_id: str, db: Session = Depends(get_session)):
    try:
        return portfolios.summary(db, portfolios.require(db, portfolio_id))
    except portfolios.PortfolioError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.patch("/portfolios/{portfolio_id}")
def update_portfolio(
    portfolio_id: str, payload: PortfolioUpdate, db: Session = Depends(get_session)
):
    p = portfolios.require(db, portfolio_id)
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(p, key, value)
    audit.record(
        db,
        category="portfolio",
        action="update",
        summary=f"Updated {portfolio_id}",
        portfolio_pk=p.id,
        actor=_actor(),
        detail=payload.model_dump(exclude_unset=True),
    )
    db.commit()
    return portfolios.summary(db, p)


@router.post("/portfolios/{portfolio_id}/clone", status_code=201)
def clone_portfolio(
    portfolio_id: str, payload: PortfolioClone, db: Session = Depends(get_session)
):
    source = portfolios.require(db, portfolio_id)
    try:
        target = portfolios.clone(db, source, actor=_actor(), **payload.model_dump())
    except portfolios.PortfolioError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    db.commit()
    return portfolios.summary(db, target)


@router.post("/portfolios/{portfolio_id}/archive")
def archive_portfolio(portfolio_id: str, db: Session = Depends(get_session)):
    p = portfolios.require(db, portfolio_id)
    portfolios.archive(db, p, actor=_actor())
    db.commit()
    return portfolios.summary(db, p)


@router.post("/portfolios/{portfolio_id}/unarchive")
def unarchive_portfolio(portfolio_id: str, db: Session = Depends(get_session)):
    p = portfolios.require(db, portfolio_id)
    portfolios.unarchive(db, p, actor=_actor())
    db.commit()
    return portfolios.summary(db, p)


# ---------------------------------------------------------------------------
# Instruments
# ---------------------------------------------------------------------------
@router.get("/instruments/search")
def search_instruments(
    q: str = Query("", description="ticker, name, or hierarchy fragment"),
    limit: int = Query(25, le=100),
    db: Session = Depends(get_session),
):
    """
    Trade-entry instrument search. INTERNAL UNIVERSE ONLY.

    This deliberately never reaches Bloomberg. Everything it can return is
    already classified against the house hierarchy, so nothing selected from
    this dropdown can land in a book unclassified. Finding something Bloomberg
    knows about but the master does not is the job of `/instruments/lookup`,
    which is only reachable from the explicit "Add instrument" panel.
    """
    hits = instruments.search(db, q, limit=limit)
    return [
        {
            "bbg_ticker": i.bbg_ticker,
            "bbg_code": i.bbg_code,
            "yellow_key": i.yellow_key,
            "instrument_name": i.instrument_name,
            "level_1": i.level_1,
            "level_2": i.level_2,
            "level_3": i.level_3,
            "level_4": i.level_4,
            "primary_exchange": i.primary_exchange,
            "source": "master",
            "in_master": True,
        }
        for i in hits
    ]


@router.get("/instruments/lookup")
def lookup_bloomberg(
    q: str = Query("", description="Bloomberg security search text"),
    limit: int = Query(15, le=50),
    db: Session = Depends(get_session),
):
    """
    Bloomberg security search, for the "Add instrument" panel only.

    Returns candidates the master does not already contain, each annotated with
    whatever Bloomberg can tell us about it. The classification fields are
    deliberately absent: the user supplies those, and `create_adhoc` refuses
    the record without them.
    """
    from app.bloomberg import get_provider, status as bbg_status

    out: List[dict] = []
    state = bbg_status()
    if not q.strip():
        return {"results": [], "live": state["is_live"], "detail": None}
    if not state["is_live"]:
        return {
            "results": [],
            "live": False,
            "detail": (
                "Bloomberg search needs Live mode. Switch the data toggle to Live, "
                "or type the full ticker below and classify it by hand."
            ),
        }

    try:
        hits = get_provider().search(q, limit=limit)
    except Exception as exc:
        logger.warning("Bloomberg lookup failed: %s", exc)
        return {"results": [], "live": True, "detail": f"Bloomberg search failed: {exc}"}

    for hit in hits:
        if not hit.ticker:
            continue
        root, yk = instruments.split_ticker(hit.ticker)
        existing = instruments.get_by_ticker(db, hit.ticker)
        out.append(
            {
                "bbg_ticker": hit.ticker,
                "bbg_code": root,
                "yellow_key": hit.yellow_key or yk,
                "instrument_name": hit.description,
                "already_in_master": existing is not None,
                "suggested": instruments.suggest_classification(db, hit.ticker, hit.description),
            }
        )
    return {"results": out, "live": True, "detail": None}


@router.post("/instruments/adhoc", status_code=201)
def add_adhoc_instrument(payload: AdhocInstrument, db: Session = Depends(get_session)):
    """
    Add an instrument that is not in the seeded master.

    The escape hatch for "the taxonomy file doesn't have what I want to trade".
    In live mode the ticker is validated against Bloomberg first, so a typo or
    an unentitled security fails here rather than producing an unpriced row
    later. In offline mode it is accepted and tagged `unvalidated`.
    """
    try:
        instrument, messages = instruments.create_adhoc(
            db, actor=_actor(), **payload.model_dump()
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    db.commit()
    return {
        "bbg_ticker": instrument.bbg_ticker,
        "instrument_name": instrument.instrument_name,
        "yellow_key": instrument.yellow_key,
        "level_1": instrument.level_1,
        "level_2": instrument.level_2,
        "level_3": instrument.level_3,
        "level_4": instrument.level_4,
        "validation_status": instrument.validation_status,
        "messages": messages,
        "in_master": True,
    }


@router.get("/instruments/adhoc")
def list_adhoc_instruments(db: Session = Depends(get_session)):
    """Manually added instruments - the shortlist for the next master revision."""
    return [
        {
            "bbg_ticker": i.bbg_ticker,
            "instrument_name": i.instrument_name,
            "level_1": i.level_1,
            "level_2": i.level_2,
            "level_3": i.level_3,
            "level_4": i.level_4,
            "validation_status": i.validation_status,
            "created_at": i.created_at,
        }
        for i in instruments.adhoc_instruments(db)
    ]


@router.get("/instruments/hierarchy")
def instrument_hierarchy(db: Session = Depends(get_session)):
    return {
        "tree": instruments.hierarchy_tree(db),
        "levels": instruments.distinct_levels(db),
    }


@router.get("/instruments/{ticker:path}")
def get_instrument(ticker: str, db: Session = Depends(get_session)):
    inst = instruments.get_by_ticker(db, ticker)
    if inst is None:
        raise HTTPException(status_code=404, detail=f"{ticker!r} is not in the instrument master")
    level, level_date = pricing.latest_level(db, inst.bbg_ticker)
    dur = duration_svc.resolve(db, inst, date.today())
    return {
        "bbg_ticker": inst.bbg_ticker,
        "bbg_code": inst.bbg_code,
        "yellow_key": inst.yellow_key,
        "instrument_name": inst.instrument_name,
        "level_1": inst.level_1,
        "level_2": inst.level_2,
        "level_3": inst.level_3,
        "level_4": inst.level_4,
        "primary_exchange": inst.primary_exchange,
        "notes": inst.notes,
        "is_active": inst.is_active,
        "latest_level": level,
        "latest_level_date": level_date,
        "duration_years": dur.years,
        "duration_source": dur.source.value,
        "duration_note": dur.note,
    }


@router.post("/instruments/master/reload")
async def reload_instrument_master(
    file: UploadFile = File(...), db: Session = Depends(get_session)
):
    content = await file.read()
    try:
        result = instruments.ingest_instrument_master(
            db, content=content, filename=file.filename or "upload.csv", actor=_actor()
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    db.commit()
    return result.as_dict()


# ---------------------------------------------------------------------------
# Trades
# ---------------------------------------------------------------------------
@router.post("/portfolios/{portfolio_id}/level-preview")
def level_preview(
    portfolio_id: str, payload: LevelPreviewRequest, db: Session = Depends(get_session)
):
    portfolios.require(db, portfolio_id)
    inst, messages = instruments.resolve_ticker(db, payload.bbg_ticker)
    if inst is None:
        raise HTTPException(status_code=400, detail="; ".join(messages))
    result = trades_svc.preview_level(
        db,
        bbg_ticker=inst.bbg_ticker,
        trade_date=payload.trade_date,
        execution_type=payload.execution_time,
        custom_level=payload.level,
    )
    db.commit()  # persist any prices fetched during the preview
    result["bbg_ticker"] = inst.bbg_ticker
    result["instrument_name"] = inst.instrument_name
    result["hierarchy"] = {
        "level_1": inst.level_1,
        "level_2": inst.level_2,
        "level_3": inst.level_3,
        "level_4": inst.level_4,
    }
    return result


@router.post("/portfolios/{portfolio_id}/trades", status_code=201)
def create_trade(portfolio_id: str, payload: TradeCreate, db: Session = Depends(get_session)):
    try:
        trade = trades_svc.save_trade(
            db,
            trades_svc.TradeRequest(
                portfolio_id=portfolio_id,
                bbg_ticker=payload.bbg_ticker,
                trade_date=payload.trade_date,
                weight_pct=payload.notional_weight_pct,
                execution_type=payload.execution_time,
                custom_level=payload.level,
                notes=payload.notes,
                actor=_actor(),
            ),
        )
    except (trades_svc.TradeError, portfolios.PortfolioError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    db.commit()
    return {
        "id": trade.id,
        "bbg_ticker": trade.bbg_ticker,
        "trade_date": trade.trade_date,
        "weight_delta_pct": trade.weight_delta_pct,
        "execution_type": trade.execution_type.value,
        "execution_level": trade.execution_level,
        "level_source": trade.level_source.value,
        "price_observation_date": trade.price_observation_date,
        "price_fallback_days": trade.price_fallback_days,
        "price_fallback_reason": trade.price_fallback_reason,
        "price_from_live_request": trade.price_from_live_request,
        "price_provider": trade.price_provider,
    }


@router.get("/portfolios/{portfolio_id}/trades")
def list_trades(
    portfolio_id: str,
    include_offset: bool = Query(False),
    limit: int = Query(500, le=5000),
    db: Session = Depends(get_session),
):
    p = portfolios.require(db, portfolio_id)
    rows = trades_svc.history(db, p, include_offset=include_offset, limit=limit)
    return [
        {
            "id": t.id,
            "trade_date": t.trade_date,
            "bbg_ticker": t.bbg_ticker,
            "instrument_name": t.instrument.instrument_name if t.instrument else t.bbg_ticker,
            "level_1": t.instrument.level_1 if t.instrument else "Unclassified",
            "level_2": t.instrument.level_2 if t.instrument else "Unclassified",
            "level_3": t.instrument.level_3 if t.instrument else "Unclassified",
            "level_4": t.instrument.level_4 if t.instrument else "Unclassified",
            "weight_delta_pct": t.weight_delta_pct,
            "execution_type": t.execution_type.value,
            "execution_level": t.execution_level,
            "level_source": t.level_source.value,
            "price_field_used": t.price_field_used,
            "price_observation_date": t.price_observation_date,
            "price_fallback_days": t.price_fallback_days,
            "price_fallback_reason": t.price_fallback_reason,
            "price_from_live_request": t.price_from_live_request,
            "price_provider": t.price_provider,
            "source": t.source.value,
            "is_funding_offset": t.is_funding_offset,
            "is_void": t.is_void,
            "void_reason": t.void_reason,
            "notes": t.notes,
            "entered_by": t.entered_by,
            "created_at": t.created_at,
        }
        for t in rows
    ]


@router.post("/trades/{trade_id}/void")
def void_trade(trade_id: int, payload: TradeVoid, db: Session = Depends(get_session)):
    trade = db.get(Trade, trade_id)
    if trade is None:
        raise HTTPException(status_code=404, detail="Trade not found")
    if trade.is_funding_offset:
        raise HTTPException(
            status_code=400,
            detail="The funding sleeve is maintained automatically and cannot be voided",
        )
    trades_svc.void_trade(db, trade, reason=payload.reason, actor=_actor())
    db.commit()
    return {"id": trade.id, "is_void": True}


@router.post("/trades/{trade_id}/edit")
def edit_trade(trade_id: int, payload: TradeEditIn, db: Session = Depends(get_session)):
    """
    Amend a booked trade.

    The trade keeps its id so the audit trail stays connected, and the change is
    recorded as a before/after diff. Changing the date or the execution type
    re-resolves the execution level rather than carrying the old one across - a
    price is a claim about a specific day and must not survive a date change.
    """
    trade = db.get(Trade, trade_id)
    if trade is None:
        raise HTTPException(status_code=404, detail="Trade not found")
    if trade.is_funding_offset:
        raise HTTPException(
            status_code=400,
            detail=(
                "The funding sleeve is derived from the market book and is maintained "
                "automatically. Edit the market trades and it will rebuild itself."
            ),
        )
    if trade.source in (TradeSource.IMPORT_TRADE_HISTORY, TradeSource.SNAPSHOT_DERIVED):
        # Allowed, but worth recording: the source file no longer reproduces the
        # book, and a re-import would overwrite this amendment.
        logger.info(
            "Editing trade %s (%s) that originated from %s",
            trade.id,
            trade.bbg_ticker,
            trade.source.value,
        )

    try:
        updated, messages = trades_svc.edit_trade(
            db,
            trade,
            trades_svc.TradeEdit(
                trade_date=payload.trade_date,
                weight_pct=payload.notional_weight_pct,
                execution_type=payload.execution_time,
                custom_level=payload.level,
                notes=payload.notes,
                reason=payload.reason,
                actor=_actor(),
            ),
        )
    except trades_svc.TradeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    db.commit()
    return {
        "id": updated.id,
        "bbg_ticker": updated.bbg_ticker,
        "trade_date": updated.trade_date,
        "notional_weight_pct": updated.weight_delta_pct,
        "execution_time": updated.execution_type.value,
        "level": updated.execution_level,
        "level_source": updated.level_source.value if updated.level_source else None,
        "notes": updated.notes,
        "edited_at": updated.edited_at,
        "messages": messages,
    }


@router.post("/trades/{trade_id}/restore")
def restore_trade(trade_id: int, db: Session = Depends(get_session)):
    """Un-void a trade. Kept separate from edit so the audit reads honestly."""
    trade = db.get(Trade, trade_id)
    if trade is None:
        raise HTTPException(status_code=404, detail="Trade not found")
    if not trade.is_void:
        return {"id": trade.id, "is_void": False}
    trades_svc.restore_trade(db, trade, actor=_actor())
    db.commit()
    return {"id": trade.id, "is_void": False}


@router.get("/portfolios/{portfolio_id}/lots")
def list_lots(
    portfolio_id: str,
    ticker: Optional[str] = Query(None),
    open_only: bool = Query(False),
    db: Session = Depends(get_session),
):
    p = portfolios.require(db, portfolio_id)
    stmt = select(TradeLot).where(TradeLot.portfolio_pk == p.id)
    if ticker:
        stmt = stmt.where(TradeLot.bbg_ticker == ticker)
    if open_only:
        stmt = stmt.where(TradeLot.is_open.is_(True))
    rows = list(db.scalars(stmt.order_by(TradeLot.bbg_ticker, TradeLot.open_date)))
    return [
        {
            "id": l.id,
            "bbg_ticker": l.bbg_ticker,
            "open_date": l.open_date,
            "open_level": l.open_level,
            "open_weight_pct": l.open_weight_pct,
            "remaining_weight_pct": l.remaining_weight_pct,
            "close_date": l.close_date,
            "close_level": l.close_level,
            "closed_weight_pct": l.closed_weight_pct,
            "realised_pnl_pct": l.realised_pnl_pct,
            "is_open": l.is_open,
        }
        for l in rows
    ]


# ---------------------------------------------------------------------------
# Positions / analytics
# ---------------------------------------------------------------------------
@router.get("/portfolios/{portfolio_id}/positions")
def position_view(
    portfolio_id: str,
    valuation_date: Optional[date] = Query(None),
    window_start: Optional[date] = Query(None),
    window_end: Optional[date] = Query(None),
    include_inactive: bool = Query(False),
    include_offset: bool = Query(True),
    include_history: bool = Query(
        False, description="attach per-instrument target history for the positioning window"
    ),
    vol_lookback_days: Optional[int] = Query(None),
    custom_pnl_start: Optional[date] = Query(None),
    custom_pnl_end: Optional[date] = Query(None),
    db: Session = Depends(get_session),
):
    p = portfolios.require(db, portfolio_id)
    custom = (
        (custom_pnl_start, custom_pnl_end)
        if custom_pnl_start and custom_pnl_end
        else None
    )
    view = exposure.build_position_view(
        db,
        p,
        valuation_date=valuation_date,
        window_start=window_start,
        window_end=window_end,
        include_inactive=include_inactive,
        include_offset=include_offset,
        include_history=include_history,
        vol_lookback_days=vol_lookback_days,
        custom_pnl_window=custom,
    )
    db.commit()
    return view


@router.get("/portfolios/{portfolio_id}/pnl")
def pnl_detail(
    portfolio_id: str,
    as_of: Optional[date] = Query(None),
    start: Optional[date] = Query(None),
    end: Optional[date] = Query(None),
    db: Session = Depends(get_session),
):
    p = portfolios.require(db, portfolio_id)
    as_of = as_of or date.today()
    pnl_svc.compute_daily_pnl(db, p, end=as_of)
    inception = positions.first_trade_date(db, p)
    window = (start or inception, end or as_of)
    payload = {
        "as_of": as_of,
        "inception": inception,
        "periods": pnl_svc.period_summary(db, p, as_of),
        "attribution": pnl_svc.attribution_by_component(db, p, window[0], window[1]),
        "equity_curve": [
            {"date": d, "cumulative_pct": v}
            for d, v in pnl_svc.equity_curve(db, p, inception, as_of)
        ],
        "reconciliation": pnl_svc.reconcile(db, p, as_of),
        "per_instrument": pnl_svc.per_instrument_summary(db, p, as_of),
    }
    db.commit()
    return payload


@router.get("/portfolios/{portfolio_id}/pnl/attribution")
def pnl_attribution(
    portfolio_id: str,
    period: str = Query("itd", description="mtd | qtd | ytd | itd | custom"),
    as_of: Optional[date] = Query(None),
    start: Optional[date] = Query(None),
    end: Optional[date] = Query(None),
    group_by: str = Query("level_1", description="level_1 | level_2 | level_3 | ticker"),
    top_n: int = Query(8, ge=2, le=12),
    db: Session = Depends(get_session),
):
    """
    Cumulative P&L for a period, decomposed into contributors.

    Drives the attribution chart: stacked contributions that sum exactly to the
    overlaid cumulative line, because both are running sums of the same daily
    rows. Everything is rebased to zero at the start of the selected period.
    """
    if group_by not in ("level_1", "level_2", "level_3", "ticker"):
        raise HTTPException(status_code=400, detail="group_by must be level_1/2/3 or ticker")

    p = portfolios.require(db, portfolio_id)
    as_of = as_of or date.today()
    pnl_svc.compute_daily_pnl(db, p, end=as_of)
    inception = positions.first_trade_date(db, p)

    if period == "custom" and start:
        window = (start, end or as_of)
    else:
        bounds = pnl_svc.period_bounds(as_of, inception)
        window = bounds.get(period) or bounds["itd"]

    payload = pnl_svc.contribution_curves(
        db, p, start=window[0], end=window[1], group_by=group_by, top_n=top_n
    )
    payload["period"] = period
    payload["as_of"] = as_of
    payload["inception"] = inception
    db.commit()
    return payload


@router.get("/portfolios/{portfolio_id}/pnl/positioning")
def pnl_positioning(
    portfolio_id: str,
    period: str = Query("itd"),
    as_of: Optional[date] = Query(None),
    start: Optional[date] = Query(None),
    end: Optional[date] = Query(None),
    group_by: str = Query("level_1"),
    top_n: int = Query(8, ge=2, le=12),
    db: Session = Depends(get_session),
):
    """
    Positioning behind the cumulative P&L chart, for the same period and the
    same grouping - so the table under the chart always matches the bars above
    it, including their colours.
    """
    if group_by not in ("level_1", "level_2", "level_3", "ticker"):
        raise HTTPException(status_code=400, detail="group_by must be level_1/2/3 or ticker")

    p = portfolios.require(db, portfolio_id)
    as_of = as_of or date.today()
    pnl_svc.compute_daily_pnl(db, p, end=as_of)
    inception = positions.first_trade_date(db, p)

    if period == "custom" and start:
        window = (start, end or as_of)
    else:
        bounds = pnl_svc.period_bounds(as_of, inception)
        window = bounds.get(period) or bounds["itd"]

    payload = pnl_svc.positioning_table(
        db, p, start=window[0], end=window[1], group_by=group_by, top_n=top_n
    )
    # The chart form: weight through time, on the SAME buckets and in the SAME
    # series order as the cumulative P&L above it.
    payload["timeline"] = pnl_svc.positioning_series(
        db, p, start=window[0], end=window[1], group_by=group_by, top_n=top_n
    )
    payload["period"] = period
    db.commit()
    return payload


@router.get("/portfolios/{portfolio_id}/snapshots")
def list_snapshots(portfolio_id: str, db: Session = Depends(get_session)):
    p = portfolios.require(db, portfolio_id)
    rows = db.scalars(
        select(PortfolioSnapshot)
        .where(PortfolioSnapshot.portfolio_pk == p.id)
        .order_by(PortfolioSnapshot.snapshot_date.desc(), PortfolioSnapshot.id.desc())
    ).all()
    return [
        {
            "id": s.id,
            "snapshot_date": s.snapshot_date,
            "label": s.label,
            "is_current": s.is_current,
            "superseded_by_id": s.superseded_by_id,
            "row_count": len(s.rows),
            "imported_file_id": s.imported_file_id,
            "created_by": s.created_by,
            "created_at": s.created_at,
        }
        for s in rows
    ]


@router.get("/snapshots/{snapshot_id}")
def get_snapshot(snapshot_id: int, db: Session = Depends(get_session)):
    snap = db.get(PortfolioSnapshot, snapshot_id)
    if snap is None:
        raise HTTPException(status_code=404, detail="Snapshot not found")
    return exposure.snapshot_exposure(db, snap)


@router.get("/portfolios/{portfolio_id}/audit")
def portfolio_audit(
    portfolio_id: str, limit: int = Query(200, le=1000), db: Session = Depends(get_session)
):
    p = portfolios.require(db, portfolio_id)
    return [
        {
            "event_time": a.event_time,
            "category": a.category,
            "action": a.action,
            "summary": a.summary,
            "bbg_ticker": a.bbg_ticker,
            "actor": a.actor,
            "detail_json": a.detail_json,
        }
        for a in audit.recent(db, portfolio_pk=p.id, limit=limit)
    ]


# ---------------------------------------------------------------------------
# Imports
# ---------------------------------------------------------------------------
@router.get("/imports/template")
def download_template(
    mode: ImportMode = Query(ImportMode.TRADE_HISTORY),
    with_sample: bool = Query(False),
):
    csv_text = imports.template_csv(mode, with_sample=with_sample)
    name = f"{mode.value}{'_sample' if with_sample else '_template'}.csv"
    return StreamingResponse(
        io.BytesIO(csv_text.encode()),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{name}"'},
    )


@router.post("/imports/stage")
async def stage_import(
    file: UploadFile = File(...),
    mode: ImportMode = Form(ImportMode.TRADE_HISTORY),
    portfolio_id: Optional[str] = Form(None),
    db: Session = Depends(get_session),
):
    content = await file.read()
    portfolio = portfolios.get(db, portfolio_id) if portfolio_id else None
    record, parsed = imports.stage_upload(
        db,
        content=content,
        filename=file.filename or "upload.csv",
        mode=mode,
        portfolio=portfolio,
        actor=_actor(),
    )
    db.commit()
    return {
        "import_id": record.id,
        "mode": record.mode.value,
        "status": record.status.value,
        "filename": record.original_filename,
        "row_count": record.row_count,
        "valid_count": record.valid_count,
        "warning_count": record.warning_count,
        "error_count": record.error_count,
        "message": record.message,
        "replace_behaviour": record.replace_behaviour,
        "rows": [r.as_preview() for r in parsed],
    }


@router.post("/imports/{import_id}/commit")
def commit_import(
    import_id: int, payload: ImportCommit, db: Session = Depends(get_session)
):
    record = db.get(ImportedFile, import_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Import not found")
    try:
        result = imports.commit(
            db,
            record,
            skip_error_rows=payload.skip_error_rows,
            snapshot_label=payload.snapshot_label,
            make_current=payload.make_current,
            actor=_actor(),
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    db.commit()
    return result


@router.get("/imports")
def list_imports(
    portfolio_id: Optional[str] = Query(None),
    limit: int = Query(100, le=500),
    db: Session = Depends(get_session),
):
    portfolio = portfolios.get(db, portfolio_id) if portfolio_id else None
    rows = imports.import_history(db, portfolio=portfolio, limit=limit)
    return [
        {
            "id": r.id,
            "mode": r.mode.value,
            "status": r.status.value,
            "filename": r.original_filename,
            "sha256": r.sha256,
            "row_count": r.row_count,
            "valid_count": r.valid_count,
            "warning_count": r.warning_count,
            "error_count": r.error_count,
            "committed_count": r.committed_count,
            "replace_behaviour": r.replace_behaviour,
            "superseded_snapshot_id": r.superseded_snapshot_id,
            "uploaded_by": r.uploaded_by,
            "uploaded_at": r.uploaded_at,
            "committed_at": r.committed_at,
            "message": r.message,
        }
        for r in rows
    ]


@router.get("/imports/{import_id}/rows")
def import_rows(import_id: int, db: Session = Depends(get_session)):
    rows = db.scalars(
        select(ImportRow)
        .where(ImportRow.imported_file_id == import_id)
        .order_by(ImportRow.row_number)
    ).all()
    return [
        {
            "row_number": r.row_number,
            "status": r.status.value,
            "messages": r.messages_json,
            "portfolio_id": r.parsed_portfolio_id,
            "bbg_ticker": r.resolved_ticker or r.parsed_ticker,
            "notional_weight_pct": r.parsed_weight_pct,
            "trade_date": r.parsed_trade_date,
            "execution_time": r.parsed_execution_type,
            "level": r.parsed_level,
            "notes": r.parsed_notes,
            "created_trade_id": r.created_trade_id,
            "raw": r.raw_json,
        }
        for r in rows
    ]


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------
@router.get("/settings/funding")
def get_funding(db: Session = Depends(get_session)):
    return {
        "config": settings.funding.model_dump(),
        "curve": [
            {
                "benchmark": p.benchmark,
                "effective_date": p.effective_date,
                "rate_pct": p.rate_pct,
                "source": p.source,
                "note": p.note,
            }
            for p in funding.curve(db)
        ],
    }


@router.post("/settings/funding")
def upsert_funding(payload: FundingPointUpsert, db: Session = Depends(get_session)):
    point = funding.upsert_point(
        db,
        benchmark=payload.benchmark,
        effective_date=payload.effective_date,
        rate_pct=payload.rate_pct,
        note=payload.note,
        actor=_actor(),
    )
    db.commit()
    return {
        "benchmark": point.benchmark,
        "effective_date": point.effective_date,
        "rate_pct": point.rate_pct,
    }


@router.post("/settings/duration-override")
def set_duration_override(payload: DurationOverride, db: Session = Depends(get_session)):
    duration_svc.set_override(
        db,
        ticker=payload.bbg_ticker,
        years=payload.years,
        as_of=payload.as_of or date.today(),
        actor=_actor(),
        reason=payload.reason,
    )
    db.commit()
    return {"bbg_ticker": payload.bbg_ticker, "years": payload.years}


@router.get("/settings/analytics")
def get_analytics_settings():
    return {
        "volatility": settings.analytics.volatility.model_dump(),
        "duration": settings.analytics.duration.model_dump(),
        "pnl": settings.analytics.pnl.model_dump(),
        "ui": settings.ui.model_dump(),
        # REPOINT SHARED DRIVE LATER - surfaced read-only so an operator can
        # confirm at a glance where the app is actually reading and writing.
        "paths": {
            "data_root": str(settings.paths.data_root_path),
            "database": str(settings.paths.database_file),
            "instrument_seed": str(settings.paths.instrument_seed_file),
            "import_archive": str(settings.paths.import_archive),
        },
    }
