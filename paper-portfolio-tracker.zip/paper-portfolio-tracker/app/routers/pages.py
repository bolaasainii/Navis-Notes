"""
Server-rendered page shells.

Each route renders a small Jinja shell; the dense grids and analytics panels
are populated by fetch() calls against /api. That split keeps the initial paint
fast and the templates readable, with no build toolchain anywhere in the stack.
"""

from __future__ import annotations

from datetime import date
from typing import Optional

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.bloomberg import provider_status
from app.config import REPO_ROOT, settings
from app.db import get_session
from app.services import portfolios

router = APIRouter(tags=["pages"])
templates = Jinja2Templates(directory=str(REPO_ROOT / "app" / "templates"))

TABS = [
    ("positions", "Positions", "/"),
    ("history", "Trade History", "/history"),
    ("imports", "Imports", "/imports"),
    ("pnl", "P&L", "/pnl"),
    ("analytics", "Analytics", "/analytics"),
    ("settings", "Settings", "/settings"),
]


def _context(request: Request, db: Session, active: str, portfolio_id: Optional[str]) -> dict:
    books = portfolios.list_portfolios(db, include_archived=True)
    active_books = [b for b in books if b.status.value == "active"]
    selected = portfolio_id or (active_books[0].portfolio_id if active_books else None)
    return {
        "request": request,
        "app_name": settings.app.name,
        "short_name": settings.app.short_name,
        "environment": settings.app.environment,
        "tabs": TABS,
        "active_tab": active,
        "portfolios": [
            {
                "portfolio_id": b.portfolio_id,
                "name": b.name,
                "status": b.status.value,
            }
            for b in books
        ],
        "selected_portfolio": selected,
        "today": date.today(),
        "market_data": provider_status(),
        "default_theme": settings.ui.default_theme,
        "default_density": settings.ui.default_density,
        "show_offset_default": settings.ui.show_offset_sleeve_by_default,
        "offset_ticker": settings.funding.offset_ticker,
        "vol_lookback_default": settings.analytics.volatility.default_lookback_days,
    }


@router.get("/", response_class=HTMLResponse)
def positions_page(
    request: Request, portfolio: Optional[str] = None, db: Session = Depends(get_session)
):
    return templates.TemplateResponse(
        request, "positions.html", _context(request, db, "positions", portfolio)
    )


@router.get("/history", response_class=HTMLResponse)
def history_page(
    request: Request, portfolio: Optional[str] = None, db: Session = Depends(get_session)
):
    return templates.TemplateResponse(
        request, "history.html", _context(request, db, "history", portfolio)
    )


@router.get("/imports", response_class=HTMLResponse)
def imports_page(
    request: Request, portfolio: Optional[str] = None, db: Session = Depends(get_session)
):
    return templates.TemplateResponse(
        request, "imports.html", _context(request, db, "imports", portfolio)
    )


@router.get("/pnl", response_class=HTMLResponse)
def pnl_page(
    request: Request, portfolio: Optional[str] = None, db: Session = Depends(get_session)
):
    return templates.TemplateResponse(
        request, "pnl.html", _context(request, db, "pnl", portfolio)
    )


@router.get("/analytics", response_class=HTMLResponse)
def analytics_page(
    request: Request, portfolio: Optional[str] = None, db: Session = Depends(get_session)
):
    return templates.TemplateResponse(
        request, "analytics.html", _context(request, db, "analytics", portfolio)
    )


@router.get("/settings", response_class=HTMLResponse)
def settings_page(
    request: Request, portfolio: Optional[str] = None, db: Session = Depends(get_session)
):
    ctx = _context(request, db, "settings", portfolio)
    # REPOINT SHARED DRIVE LATER - shown on the Settings screen so an operator
    # can verify where the application is actually reading and writing.
    ctx["paths"] = {
        "Data root": str(settings.paths.data_root_path),
        "Database": str(settings.paths.database_file),
        "Instrument master seed": str(settings.paths.instrument_seed_file),
        "Import archive": str(settings.paths.import_archive),
        "Templates": str(settings.paths.templates_path),
    }
    return templates.TemplateResponse(request, "settings.html", ctx)
