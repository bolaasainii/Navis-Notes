"""Pydantic request/response models for the JSON API."""

from __future__ import annotations

from datetime import date
from typing import Dict, List, Optional

from pydantic import BaseModel, Field, field_validator

from app.models import ExecutionType, ImportMode


# ---------------------------------------------------------------------------
# Portfolios
# ---------------------------------------------------------------------------
class PortfolioCreate(BaseModel):
    portfolio_id: str = Field(..., description="Short unique key, e.g. 'Navi-S1'")
    name: str
    description: Optional[str] = None
    owner: Optional[str] = None
    inception_date: Optional[date] = None
    base_currency: str = "USD"
    funding_benchmark: Optional[str] = None
    funding_spread_bps: Optional[float] = None
    notes: Optional[str] = None


class PortfolioClone(BaseModel):
    new_portfolio_id: str
    new_name: Optional[str] = None
    copy_trades: bool = True
    copy_snapshots: bool = True


class PortfolioUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    owner: Optional[str] = None
    notes: Optional[str] = None
    funding_benchmark: Optional[str] = None
    funding_spread_bps: Optional[float] = None


# ---------------------------------------------------------------------------
# Trades
# ---------------------------------------------------------------------------
class LevelPreviewRequest(BaseModel):
    bbg_ticker: str
    trade_date: date
    execution_time: ExecutionType
    level: Optional[float] = None


class TradeCreate(BaseModel):
    bbg_ticker: str
    trade_date: date
    notional_weight_pct: float
    execution_time: ExecutionType
    level: Optional[float] = None
    notes: Optional[str] = None

    @field_validator("notional_weight_pct", mode="before")
    @classmethod
    def _coerce_weight(cls, v):
        """`4`, `'4'`, `'4%'` and `'+4.0'` all mean +4.00%."""
        if isinstance(v, str):
            return float(v.strip().replace(",", "").replace("%", "").lstrip("+"))
        return v


class TradeVoid(BaseModel):
    reason: str


class TradeEditIn(BaseModel):
    """
    Amend an existing trade. Every field is optional; omitted fields are left
    untouched. Changing the date or execution type forces the execution level
    to be re-resolved through Bloomberg rather than carried across.
    """

    trade_date: Optional[date] = None
    notional_weight_pct: Optional[float] = None
    execution_time: Optional[ExecutionType] = None
    level: Optional[float] = None
    notes: Optional[str] = None
    reason: Optional[str] = Field(None, description="why the trade was amended")

    @field_validator("notional_weight_pct", mode="before")
    @classmethod
    def _coerce_weight(cls, v):
        if v is None or (isinstance(v, str) and not v.strip()):
            return None
        if isinstance(v, str):
            return float(v.strip().replace(",", "").replace("%", "").lstrip("+"))
        return v


# ---------------------------------------------------------------------------
# Imports
# ---------------------------------------------------------------------------
class ImportCommit(BaseModel):
    skip_error_rows: bool = True
    snapshot_label: Optional[str] = None
    make_current: bool = True


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------
class FundingPointUpsert(BaseModel):
    benchmark: str = "SOFR1M"
    effective_date: date
    rate_pct: float
    note: Optional[str] = None


class DurationOverride(BaseModel):
    bbg_ticker: str
    years: Optional[float] = None
    as_of: Optional[date] = None
    reason: Optional[str] = None


class DataModeSwitch(BaseModel):
    """Request body for POST /api/data-mode."""

    mode: str = Field(..., description="'live' or 'offline'")
    portfolio_id: Optional[str] = None

    @field_validator("mode")
    @classmethod
    def _valid_mode(cls, v: str) -> str:
        v = (v or "").strip().lower()
        if v not in ("live", "offline"):
            raise ValueError("mode must be 'live' or 'offline'")
        return v


class AdhocInstrument(BaseModel):
    """
    Add an instrument the seeded master does not contain.

    Every hierarchy level is REQUIRED. An instrument with no classification
    falls out of asset-class rollups, duration targeting and the attribution
    colour scheme - it is worse than not having the instrument at all, because
    it silently under-reports exposure. The classification is captured once,
    here, and applies to that instrument for every user from then on.
    """

    bbg_ticker: str = Field(..., description="Full ticker with yellow key, e.g. 'TSLA US Equity'")
    instrument_name: Optional[str] = None
    level_1: str = Field(..., min_length=1)
    level_2: str = Field(..., min_length=1)
    level_3: str = Field(..., min_length=1)
    level_4: str = Field(..., min_length=1)
    primary_exchange: Optional[str] = None
    notes: Optional[str] = None

    @field_validator("level_1", "level_2", "level_3", "level_4")
    @classmethod
    def _no_placeholder(cls, v: str) -> str:
        v = (v or "").strip()
        if not v or v.lower() in ("unclassified", "n/a", "na", "-", "tbd", "other"):
            raise ValueError(
                "Every hierarchy level must be a real classification. "
                "Placeholders like 'Unclassified' are not accepted."
            )
        return v
