"""
Market-data provider factory and the Live / Offline data mode.

Two modes, switchable at runtime from the UI:

    LIVE    - real Bloomberg Desktop API (BLPAPI). Requires the Terminal
              application running and logged in on this machine.
    OFFLINE - deterministic synthetic data. Always available. This is the
              default for anyone without a Terminal, and it makes the whole
              application usable, demonstrable and testable without one.

`config/settings.yaml -> bloomberg.provider` sets the STARTUP PREFERENCE:

    auto    - use live if a Terminal is reachable, otherwise offline (default)
    blpapi  - start live; refuse to start if no Terminal is reachable
    fake    - always start offline, and disable the Live toggle entirely
              (use this to hard-disable Bloomberg on a machine that must not
              talk to it at all)

Whatever the startup preference, the operator's last explicit choice is
persisted in the `app_state` table and wins on the next start, provided the
mode is still available.

Callers always go through `get_provider()`; nothing else in the codebase
imports a concrete provider class.
"""

from __future__ import annotations

import logging
import threading
from enum import Enum
from typing import Optional

from app.bloomberg.base import (  # noqa: F401 - re-exported for convenience
    BloombergUnavailable,
    HistoricalSeries,
    MarketDataProvider,
    ReferenceData,
    SecurityHit,
)
from app.config import settings

logger = logging.getLogger(__name__)


class DataMode(str, Enum):
    LIVE = "live"
    OFFLINE = "offline"


_lock = threading.RLock()
_mode: DataMode = DataMode.OFFLINE
_live_provider: Optional[MarketDataProvider] = None
_offline_provider: Optional[MarketDataProvider] = None
_live_error: Optional[str] = None
_mode_initialised = False


# ---------------------------------------------------------------------------
# Availability
# ---------------------------------------------------------------------------
def live_supported() -> bool:
    """False when the deployment has hard-disabled Bloomberg (provider: fake)."""
    return (settings.bloomberg.provider or "auto").lower() != "fake"


def live_available(*, probe: bool = True) -> tuple[bool, Optional[str]]:
    """
    Can we use live Bloomberg data right now?

    Returns (available, reason_if_not). Cheap: it checks that the `blpapi`
    package imports and that something is listening on the Desktop API port,
    without paying the multi-second cost of a full session start.
    """
    if not live_supported():
        return False, (
            "Live data is disabled for this deployment "
            "(bloomberg.provider is set to 'fake' in config/settings.yaml)."
        )
    try:
        import blpapi  # noqa: F401
    except ImportError:
        return False, (
            "The blpapi package is not installed. Install it from Bloomberg's index:\n"
            "pip install --index-url="
            "https://blpapi.bloomberg.com/repository/releases/python/simple/ blpapi"
        )
    if probe:
        from app.bloomberg.blpapi_provider import bbcomm_is_listening

        if not bbcomm_is_listening(settings.bloomberg.host, settings.bloomberg.port):
            return False, (
                f"Nothing is listening on {settings.bloomberg.host}:"
                f"{settings.bloomberg.port}. Start the Bloomberg Terminal application "
                "and log in - the bbcomm process starts with it. A browser-based "
                "Bloomberg Anywhere session does not expose the Desktop API."
            )
    return True, None


# ---------------------------------------------------------------------------
# Providers
# ---------------------------------------------------------------------------
def _get_offline() -> MarketDataProvider:
    global _offline_provider
    if _offline_provider is None:
        from app.bloomberg.fake_provider import FakeProvider

        _offline_provider = FakeProvider()
    return _offline_provider


def _get_live() -> MarketDataProvider:
    """Start (or reuse) a live BLPAPI session. Raises if unavailable."""
    global _live_provider, _live_error
    if _live_provider is not None:
        return _live_provider
    from app.bloomberg.blpapi_provider import BlpapiProvider

    candidate = BlpapiProvider()
    candidate.start()  # raises BloombergUnavailable
    _live_provider = candidate
    _live_error = None
    return _live_provider


def get_provider() -> MarketDataProvider:
    """The provider for the CURRENT data mode."""
    with _lock:
        if not _mode_initialised:
            _initialise_mode_from_settings()
        if _mode is DataMode.LIVE:
            try:
                return _get_live()
            except BloombergUnavailable as exc:
                # The Terminal went away mid-session. Degrade rather than break
                # the screen, but say so loudly and flip the mode so the UI
                # reflects reality.
                logger.error("Live Bloomberg session lost, falling back to offline: %s", exc)
                _set_mode_unlocked(DataMode.OFFLINE, reason=str(exc))
        return _get_offline()


def current_mode() -> DataMode:
    with _lock:
        if not _mode_initialised:
            _initialise_mode_from_settings()
        return _mode


# ---------------------------------------------------------------------------
# Mode switching
# ---------------------------------------------------------------------------
def _set_mode_unlocked(mode: DataMode, *, reason: Optional[str] = None) -> None:
    global _mode, _live_error, _mode_initialised
    _mode = mode
    _mode_initialised = True
    if reason:
        _live_error = reason
    if mode is DataMode.OFFLINE:
        # Drop the live session so a later switch back re-establishes cleanly.
        global _live_provider
        if _live_provider is not None:
            try:
                _live_provider.stop()
            except Exception:  # pragma: no cover
                pass
            _live_provider = None


def set_mode(mode: DataMode | str) -> dict:
    """
    Switch data mode.

    Switching to LIVE verifies a session can actually be established and
    refuses (staying offline) if it cannot, returning the reason. Switching to
    OFFLINE always succeeds.

    Nothing is deleted on a switch: the pricing and reference caches are scoped
    by provider, so each mode reads only its own data and flipping back and
    forth is instant and lossless.
    """
    mode = DataMode(mode)
    with _lock:
        if mode is DataMode.OFFLINE:
            _set_mode_unlocked(DataMode.OFFLINE)
            logger.info("Data mode -> OFFLINE (synthetic market data)")
            return {"mode": _mode.value, "ok": True, "reason": None}

        available, reason = live_available()
        if not available:
            _set_mode_unlocked(DataMode.OFFLINE, reason=reason)
            logger.warning("Refused switch to LIVE: %s", reason)
            return {"mode": _mode.value, "ok": False, "reason": reason}

        try:
            _set_mode_unlocked(DataMode.LIVE)
            _get_live()
            logger.info("Data mode -> LIVE (Bloomberg Desktop API)")
            return {"mode": _mode.value, "ok": True, "reason": None}
        except BloombergUnavailable as exc:
            _set_mode_unlocked(DataMode.OFFLINE, reason=str(exc))
            logger.warning("Refused switch to LIVE: %s", exc)
            return {"mode": _mode.value, "ok": False, "reason": str(exc)}


def _initialise_mode_from_settings() -> None:
    """Resolve the startup mode from `bloomberg.provider`. Called once, lazily."""
    global _mode_initialised, _live_error
    preference = (settings.bloomberg.provider or "auto").lower()
    _mode_initialised = True

    if preference == "fake":
        _mode = DataMode.OFFLINE
        _set_mode_unlocked(DataMode.OFFLINE)
        return

    available, reason = live_available()
    if available:
        try:
            _set_mode_unlocked(DataMode.LIVE)
            _get_live()
            logger.info("Startup data mode: LIVE")
            return
        except BloombergUnavailable as exc:
            reason = str(exc)

    if preference == "blpapi":
        # Explicitly configured for live - do not silently degrade.
        raise BloombergUnavailable(
            reason or "Live Bloomberg data was requested but is not available"
        )

    _set_mode_unlocked(DataMode.OFFLINE, reason=reason)
    logger.warning("Startup data mode: OFFLINE. %s", reason)


def initialise(preferred: Optional[str] = None) -> dict:
    """
    Called once at startup, after the persisted mode has been read from the
    database. `preferred` is the operator's last explicit choice, if any.
    """
    with _lock:
        if preferred:
            result = set_mode(preferred)
            if result["ok"]:
                return status()
            # Persisted preference is no longer achievable - fall through and
            # resolve from settings, which will land on offline with a reason.
        _initialise_mode_from_settings()
    return status()


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------
def status() -> dict:
    """Everything the UI needs to render the Live / Offline control."""
    mode = current_mode()
    provider = get_provider()
    available, reason = live_available()
    health = provider.health()
    return {
        "mode": mode.value,
        "is_live": mode is DataMode.LIVE,
        "live_supported": live_supported(),
        "live_available": available,
        "live_unavailable_reason": None if available else reason,
        "provider": provider.name,
        "endpoint": f"{settings.bloomberg.host}:{settings.bloomberg.port}",
        "detail": health.get("detail"),
        "startup_preference": settings.bloomberg.provider,
        "last_live_error": _live_error,
    }


# Backwards-compatible alias used by the page templates and /api/status.
def provider_status() -> dict:
    s = status()
    return {
        "provider": s["provider"],
        "live": s["is_live"],
        "status": "connected" if s["is_live"] else "synthetic",
        "endpoint": s["endpoint"],
        "detail": s["detail"],
        "fallback_reason": s["live_unavailable_reason"] or s["last_live_error"],
        "mode": s["mode"],
        "live_available": s["live_available"],
        "live_supported": s["live_supported"],
    }


def reset_provider() -> None:
    """Drop cached providers - used by tests and after a settings change."""
    global _live_provider, _offline_provider, _live_error, _mode_initialised
    with _lock:
        for p in (_live_provider, _offline_provider):
            if p is not None:
                try:
                    p.stop()
                except Exception:  # pragma: no cover
                    pass
        _live_provider = None
        _offline_provider = None
        _live_error = None
        _mode_initialised = False
