"""
Market-data provider interface.

Everything above this layer is written against `MarketDataProvider` and knows
nothing about BLPAPI. That is what lets the whole application - lot engine,
P&L, duration, volatility, the UI - be developed and unit-tested with no
Bloomberg Terminal present, and it is also what keeps BLPAPI strictly
server-side.

Two implementations ship:
  * `BlpapiProvider`  - the real Desktop API (app/bloomberg/blpapi_provider.py)
  * `FakeProvider`    - deterministic synthetic data (app/bloomberg/fake_provider.py)
"""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import date
from typing import Dict, List, Optional, Sequence, Tuple

# ticker -> observation date -> field -> value
HistoricalSeries = Dict[str, Dict[date, Dict[str, float]]]
# ticker -> field -> value
ReferenceData = Dict[str, Dict[str, object]]


# ---------------------------------------------------------------------------
# Security-string normalisation
# ---------------------------------------------------------------------------
# //blp/instruments returns securities in the Terminal's own display notation,
# with the yellow key in angle brackets and lower-cased:
#
#     SPX<index>        AAPL US<equity>        TY1<comdty>       EURUSD<curncy>
#
# //blp/refdata does NOT accept that form. It wants the canonical space-
# separated ticker:
#
#     SPX Index         AAPL US Equity         TY1 Comdty        EURUSD Curncy
#
# Converting here, at the boundary, means no other layer ever sees the bracket
# notation - not the master, not a trade, not a pricing request.
_YELLOW_KEYS = {
    "govt": "Govt",
    "corp": "Corp",
    "mtge": "Mtge",
    "m-mkt": "M-Mkt",
    "mmkt": "M-Mkt",
    "muni": "Muni",
    "pfd": "Pfd",
    "equity": "Equity",
    "comdty": "Comdty",
    "curncy": "Curncy",
    "index": "Index",
}

_SECURITY_RE = re.compile(r"^\s*(?P<root>.*?)\s*<\s*(?P<yk>[^<>]+?)\s*>\s*$")


def parse_security_string(raw: str) -> Tuple[str, str]:
    """
    Turn a Terminal-notation security into (canonical_ticker, yellow_key).

        "SPX<index>"      -> ("SPX Index", "Index")
        "AAPL US<equity>" -> ("AAPL US Equity", "Equity")
        "SPX Index"       -> ("SPX Index", "Index")     # already canonical
        "SPX"             -> ("SPX", "")                # no key to infer

    An unrecognised key inside the brackets is title-cased and kept rather than
    discarded: a ticker we do not recognise is better than a ticker we mangle,
    and the reference-data validation on the way into the master will reject it
    if it is genuinely wrong.
    """
    text = (raw or "").strip()
    if not text:
        return "", ""

    m = _SECURITY_RE.match(text)
    if m:
        root = re.sub(r"\s+", " ", m.group("root")).strip()
        key_raw = m.group("yk").strip()
        yk = _YELLOW_KEYS.get(key_raw.lower(), key_raw.title())
        if not root:
            return "", ""
        return f"{root} {yk}", yk

    # Already canonical, or has no yellow key at all. Strip any stray brackets
    # so a malformed response can never leak "<" into a stored ticker.
    text = re.sub(r"\s+", " ", text.replace("<", " ").replace(">", " ")).strip()
    if not text:
        return "", ""
    tail = text.rsplit(" ", 1)[-1]
    if tail.lower() in _YELLOW_KEYS:
        canonical_key = _YELLOW_KEYS[tail.lower()]
        return f"{text[: -len(tail)].strip()} {canonical_key}", canonical_key
    return text, ""


class BloombergUnavailable(RuntimeError):
    """Raised when the provider cannot reach a Bloomberg session."""


@dataclass(frozen=True)
class SecurityHit:
    ticker: str
    description: str
    yellow_key: str = ""
    source: str = "bloomberg"


class MarketDataProvider(ABC):
    """Abstract market-data source."""

    name: str = "abstract"
    is_live: bool = False

    # -- lifecycle ---------------------------------------------------------
    def start(self) -> None:  # pragma: no cover - trivial default
        return None

    def stop(self) -> None:  # pragma: no cover - trivial default
        return None

    @abstractmethod
    def health(self) -> dict:
        """Return a small status dict for the UI status pill."""

    # -- data --------------------------------------------------------------
    @abstractmethod
    def historical(
        self,
        tickers: Sequence[str],
        fields: Sequence[str],
        start: date,
        end: date,
        *,
        calendar_fill: bool = True,
    ) -> HistoricalSeries:
        """
        Daily history for `tickers`.

        `calendar_fill=True` requests every calendar day, carrying the previous
        value across non-trading days. This is what makes "use the last
        available prior print when the market was shut" a single request rather
        than a retry loop. Callers detect the fallback by comparing the
        returned value's true observation date - see `historical` implementations,
        which report the last real print date via the pseudo-field
        `_actual_date_ordinal`.

        `calendar_fill=False` returns only active trading days, which is what
        volatility must use to avoid manufacturing zero-return days.
        """

    @abstractmethod
    def reference(
        self, tickers: Sequence[str], fields: Sequence[str], *, as_of: Optional[date] = None
    ) -> ReferenceData:
        """Point-in-time reference data (duration, currency, multiplier, ...)."""

    @abstractmethod
    def search(self, query: str, *, limit: int = 20, yellow_key: str = "") -> List[SecurityHit]:
        """Free-text security search."""
