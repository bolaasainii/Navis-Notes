"""
Deterministic synthetic market data.

Purpose: let the entire application - lot engine, P&L, duration, volatility,
imports, UI - be built, unit-tested and demonstrated on a machine with no
Bloomberg Terminal. Every series is a pure function of the ticker, so two
processes always agree and test assertions are stable.

It is deliberately *realistic where realism matters* for exercising the code
paths that are easy to get wrong:

  * Per-region trading calendars, so Japanese and European instruments really
    do go stale on US trading days and the price-fallback logic gets used.
  * Asset-class-appropriate volatility, so realised-vol output is sane.
  * Duration reference fields returned for US Treasury futures but NOT for
    international bond futures, so both the "direct" and the "proxy fallback"
    duration paths are exercised in a demo.

This provider is never used when `bloomberg.provider: blpapi`. When
`provider: auto` selects it, a warning banner is shown in the UI and every
price it produces is tagged provider="fake" in the cache.
"""

from __future__ import annotations

import hashlib
import math
from datetime import date, timedelta
from typing import Dict, List, Optional, Sequence

from app.bloomberg.base import HistoricalSeries, MarketDataProvider, ReferenceData, SecurityHit

# Two-and-a-bit years of history: enough for any realistic lookback window and
# short enough that drift does not carry the anchors far from plausible levels.
ORIGIN = date(2024, 1, 1)

# --- regional calendars ----------------------------------------------------
_JP_TICKERS = {"NK1 Index", "NO1 Index", "TP1 Index", "TMI1 Index", "JB1 Comdty", "JOA1 Comdty"}
_EU_TICKERS = {
    "VG1 Index", "GX1 Index", "DFW1 Index", "SXO1 Index", "CF1 Index", "ST1 Index",
    "EO1 Index", "IB1 Index", "SM1 Index", "QR1 Index", "KG1 Index", "CA1 Index",
    "BJ1 Index", "JS1 Index", "SRD1 Index", "FVS1 Index",
    "RX1 Comdty", "OE1 Comdty", "DU1 Comdty", "UB1 Comdty", "OAT1 Comdty",
    "IK1 Comdty", "BTS1 Comdty", "ER1 Comdty", "TKY1 Comdty", "SSY1 Comdty", "FB1 Comdty",
}
_UK_TICKERS = {"Z 1 Index", "G 1 Comdty", "SFI1 Comdty"}

# (month, day) closures. Not exhaustive - enough to make staleness real.
_HOLIDAYS: Dict[str, set] = {
    "US": {(1, 1), (7, 4), (12, 25), (11, 27), (11, 28), (5, 26), (9, 1), (1, 20), (2, 17)},
    "JP": {(1, 1), (1, 2), (1, 3), (5, 3), (5, 4), (5, 5), (8, 11), (11, 3), (11, 23), (12, 31)},
    "EU": {(1, 1), (4, 18), (4, 21), (5, 1), (12, 24), (12, 25), (12, 26), (12, 31)},
    "UK": {(1, 1), (4, 18), (4, 21), (5, 5), (5, 26), (8, 25), (12, 25), (12, 26)},
}


def _region_for(ticker: str) -> str:
    if ticker in _JP_TICKERS:
        return "JP"
    if ticker in _EU_TICKERS:
        return "EU"
    if ticker in _UK_TICKERS:
        return "UK"
    return "US"


def _is_trading_day(d: date, region: str) -> bool:
    if d.weekday() >= 5:
        return False
    return (d.month, d.day) not in _HOLIDAYS.get(region, set())


# --- asset-class parameters ------------------------------------------------
# Realistic starting levels for the instruments most likely to appear in a demo
# or a sample import file. Without these, every equity index would start from
# one generic anchor and a sample row carrying a real-world custom level (say
# 38250 for the Nikkei) would look absurd against the simulated series.
_ANCHORS: Dict[str, float] = {
    # Equity index futures
    "ES1 Index": 5850.0, "HWA1 Index": 5850.0, "NQ1 Index": 20800.0,
    "HWB1 Index": 20800.0, "RTY1 Index": 2330.0, "HWR1 Index": 2330.0,
    "DM1 Index": 43500.0, "HWI1 Index": 43500.0, "RSY1 Index": 3210.0,
    "FA1 Index": 3120.0, "FNS1 Index": 12400.0, "UX1 Index": 16.5,
    "IXR1 Index": 82.0, "IXP1 Index": 94.0, "IXA1 Index": 51.0,
    "IXT1 Index": 262.0, "IXS1 Index": 79.0,
    "NK1 Index": 38250.0, "NO1 Index": 38250.0, "NH1 Index": 38250.0,
    "NX1 Index": 38250.0, "TP1 Index": 2720.0, "TMI1 Index": 2720.0,
    "VG1 Index": 5180.0, "GX1 Index": 19400.0, "DFW1 Index": 19400.0,
    "SXO1 Index": 512.0, "CF1 Index": 7580.0, "ST1 Index": 34200.0,
    "EO1 Index": 895.0, "IB1 Index": 11600.0, "SM1 Index": 11950.0,
    "Z 1 Index": 8240.0, "PT1 Index": 1420.0, "MFS1 Index": 2380.0,
    "MES1 Index": 1120.0, "XP1 Index": 8180.0, "FVS1 Index": 18.5,
    "HI1 Index": 19800.0, "HC1 Index": 7050.0, "HCT1 Index": 4180.0,
    "XU1 Index": 13600.0, "NZ1 Index": 24200.0, "KM1 Index": 345.0,
    "TWT1 Index": 1180.0, "BZ1 Index": 132000.0,
    # Rates and credit
    "TU1 Comdty": 103.20, "3Y1 Comdty": 104.10, "FV1 Comdty": 108.75,
    "TY1 Comdty": 111.40, "UXY1 Comdty": 114.80, "TWE1 Comdty": 116.20,
    "US1 Comdty": 120.50, "WN1 Comdty": 127.90,
    "RX1 Comdty": 130.40, "OE1 Comdty": 118.60, "DU1 Comdty": 106.80,
    "UB1 Comdty": 133.20, "OAT1 Comdty": 124.30, "IK1 Comdty": 119.80,
    "G 1 Comdty": 93.40, "JB1 Comdty": 142.60, "CN1 Comdty": 121.30,
    "XM1 Comdty": 95.85, "YM1 Comdty": 96.30,
    "IQBA Index": 99.20, "IQSA Index": 99.60, "IQYA Index": 99.10,
    "IQLA Index": 98.40, "HYBA Index": 99.80, "DLBA Index": 99.30,
    # FX
    "EC1 Curncy": 1.0850, "BP1 Curncy": 1.2680, "JY1 Curncy": 0.00655,
    "AD1 Curncy": 0.6620, "CD1 Curncy": 0.7310, "SF1 Curncy": 1.1240,
    "NV1 Curncy": 0.6010, "SE1 Curncy": 0.0942, "NO1 Curncy": 0.0925,
    "DX1 Curncy": 104.20, "PE1 Curncy": 0.0512, "BR1 Curncy": 0.1780,
    "RF1 Curncy": 0.9420, "RP1 Curncy": 0.8380, "RY1 Curncy": 165.40,
}


def _params(ticker: str) -> tuple[float, float, float]:
    """Return (anchor_price, daily_vol, annual_drift) for a ticker."""
    yk = ticker.rsplit(" ", 1)[-1].lower()
    t = ticker.upper()
    anchor = _ANCHORS.get(ticker)
    if anchor is not None:
        if yk == "curncy":
            return anchor, 0.0045, 0.005
        if yk == "comdty":
            return anchor, 0.0035, 0.005
        if t.startswith(("UX", "FVS")):
            return anchor, 0.0700, -0.05
        return anchor, 0.0098, 0.07
    if yk == "curncy":
        return 1.0850, 0.0045, 0.005
    if yk == "comdty":
        if any(t.startswith(p) for p in ("SFR", "SER", "TZR", "FF", "ER", "IR", "COR", "TKY", "JOA", "SSY", "SFI")):
            return 96.25, 0.0006, 0.001          # short-rate futures
        if t.startswith(("YQ",)):
            return 4.15, 0.0130, 0.0             # yield-quoted futures
        if t.startswith(("JY", "OMY", "IQ", "HYB", "DHY", "DHB", "DLB")):
            return 99.50, 0.0022, 0.01           # MBS / credit futures
        return 112.75, 0.0035, 0.005             # government bond futures
    if t.startswith("UX"):
        return 17.5, 0.0700, -0.05               # VIX futures
    if t.startswith("FVS"):
        return 19.0, 0.0650, -0.05               # VSTOXX
    return 4850.0, 0.0098, 0.07                  # equity index futures


def _seed(ticker: str) -> int:
    return int.from_bytes(hashlib.sha256(ticker.encode()).digest()[:4], "big")


class _Lcg:
    """Small deterministic PRNG - avoids a numpy dependency in this layer."""

    __slots__ = ("state",)

    def __init__(self, seed: int) -> None:
        self.state = (seed ^ 0x5DEECE66D) & ((1 << 48) - 1)

    def next_uniform(self) -> float:
        self.state = (self.state * 0x5DEECE66D + 0xB) & ((1 << 48) - 1)
        return self.state / float(1 << 48)

    def next_normal(self) -> float:
        # Box-Muller, one draw per call (the discarded pair costs nothing here).
        u1 = max(self.next_uniform(), 1e-12)
        u2 = self.next_uniform()
        return math.sqrt(-2.0 * math.log(u1)) * math.cos(2.0 * math.pi * u2)


class FakeProvider(MarketDataProvider):
    name = "fake"
    is_live = False

    def __init__(self) -> None:
        self._cache: Dict[str, Dict[date, Dict[str, float]]] = {}

    def health(self) -> dict:
        return {
            "provider": self.name,
            "live": False,
            "status": "synthetic",
            "endpoint": "in-process",
            "detail": (
                "Synthetic market data. Deterministic and reproducible, but NOT "
                "real prices. Set bloomberg.provider: blpapi on a machine with a "
                "logged-in Terminal for live data."
            ),
        }

    # -- series generation -------------------------------------------------
    def _series(self, ticker: str, through: date) -> Dict[date, Dict[str, float]]:
        """Build (and memoise) the full daily series for a ticker."""
        cached = self._cache.get(ticker)
        if cached and max(cached) >= through:
            return cached

        anchor, dvol, drift = _params(ticker)
        region = _region_for(ticker)
        rng = _Lcg(_seed(ticker))
        series: Dict[date, Dict[str, float]] = {}

        px = anchor
        d = ORIGIN
        horizon = max(through, date.today()) + timedelta(days=5)
        daily_drift = drift / 252.0
        while d <= horizon:
            if _is_trading_day(d, region):
                shock = rng.next_normal() * dvol
                gap = rng.next_normal() * dvol * 0.35
                prev_close = px
                open_px = prev_close * (1.0 + gap)
                close_px = prev_close * (1.0 + daily_drift + shock)
                hi = max(open_px, close_px) * (1.0 + abs(rng.next_normal()) * dvol * 0.30)
                lo = min(open_px, close_px) * (1.0 - abs(rng.next_normal()) * dvol * 0.30)
                series[d] = {
                    "PX_OPEN": round(open_px, 6),
                    "PX_HIGH": round(hi, 6),
                    "PX_LOW": round(lo, 6),
                    "PX_LAST": round(close_px, 6),
                    # Settle differs marginally from last, as it does in reality.
                    "PX_SETTLE": round(close_px * (1.0 + rng.next_normal() * dvol * 0.02), 6),
                }
                px = close_px
            d += timedelta(days=1)

        self._cache[ticker] = series
        return series

    # -- provider API ------------------------------------------------------
    def historical(
        self,
        tickers: Sequence[str],
        fields: Sequence[str],
        start: date,
        end: date,
        *,
        calendar_fill: bool = True,
    ) -> HistoricalSeries:
        out: HistoricalSeries = {}
        for ticker in tickers:
            series = self._series(ticker, end)
            bucket: Dict[date, Dict[str, float]] = {}
            if calendar_fill:
                # Mirror BLPAPI ALL_CALENDAR_DAYS + PREVIOUS_VALUE semantics.
                last: Optional[Dict[str, float]] = None
                # Seed `last` with the most recent print strictly before `start`
                # so a range that opens on a holiday still resolves.
                priors = [d for d in series if d < start]
                if priors:
                    last = series[max(priors)]
                d = start
                while d <= end:
                    if d in series:
                        last = series[d]
                    if last is not None:
                        bucket[d] = {f: last[f] for f in fields if f in last}
                    d += timedelta(days=1)
            else:
                for d, values in series.items():
                    if start <= d <= end:
                        bucket[d] = {f: values[f] for f in fields if f in values}
            out[ticker] = bucket
        return out

    def reference(
        self, tickers: Sequence[str], fields: Sequence[str], *, as_of: Optional[date] = None
    ) -> ReferenceData:
        """
        Synthetic reference data.

        Duration is returned only for US Treasury and Eris swap futures. That
        is intentional: it means a demo book containing Bunds, Gilts or JGBs
        exercises the static-proxy fallback path and shows "proxy" tags in the
        UI, which is exactly what a reviewer needs to see.
        """
        direct_duration = {
            "TU1 Comdty": 1.94, "3Y1 Comdty": 2.83, "FV1 Comdty": 4.38,
            "TY1 Comdty": 6.47, "UXY1 Comdty": 9.17, "TWE1 Comdty": 13.42,
            "US1 Comdty": 15.55, "WN1 Comdty": 19.31,
            "YITA Comdty": 1.96, "YIWA Comdty": 4.62,
            "YIYA Comdty": 8.28, "YIEA Comdty": 18.44,
        }
        out: ReferenceData = {}
        for t in tickers:
            bucket: Dict[str, object] = {}
            for f in fields:
                if f in ("FUT_EQV_DUR_NOTL", "DUR_ADJ_MID", "DUR_MID"):
                    if t in direct_duration:
                        bucket[f] = direct_duration[t]
                elif f == "CRNCY":
                    bucket[f] = "USD"
                elif f == "NAME":
                    bucket[f] = t
                elif f == "FUT_CONT_SIZE":
                    bucket[f] = 1000.0
                elif f == "PX_LAST":
                    series = self._series(t, date.today())
                    if series:
                        bucket[f] = series[max(series)]["PX_LAST"]
            out[t] = bucket
        return out

    def search(self, query: str, *, limit: int = 20, yellow_key: str = "") -> List[SecurityHit]:
        """
        The fake provider has no security universe of its own. Returning an
        empty list is correct: the instrument-master search in
        app/services/instruments.py is the primary search path and Bloomberg
        search only ever augments it.
        """
        return []
