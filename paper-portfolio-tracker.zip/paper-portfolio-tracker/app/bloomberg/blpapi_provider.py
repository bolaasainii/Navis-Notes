"""
Bloomberg Desktop API (BLPAPI) provider.

Runs SERVER-SIDE ONLY. No Bloomberg data, session handle or field name is ever
exposed to the browser except as an already-computed number.

Requirements on the machine running this process
------------------------------------------------
  * A Bloomberg Terminal logged in as the user running this service.
  * `bbcomm` listening on 127.0.0.1:8194 (it starts with the Terminal).
  * The `blpapi` Python package plus the BLPAPI C++ SDK:

        pip install --index-url=https://blpapi.bloomberg.com/repository/releases/python/simple/ blpapi

Important environment note
--------------------------
The Terminal is Windows-only and bbcomm binds to 127.0.0.1. A process running
inside WSL sits in a different network namespace and will NOT see that socket
unless WSL mirrored networking is enabled. Run this service natively on Windows,
in the same Python environment where `blpapi` is installed.

Entitlement note
----------------
Desktop API entitlement belongs to the interactive Terminal user. It is not an
application credential, it cannot be shared, and redistributing the data it
returns to other consumers is a licensing violation. If this application needs
to run unattended or serve a team from a server, that requires B-PIPE or Server
API (SAPI) and a conversation with your Bloomberg representative. See README
-> "Bloomberg integration approach".
"""

from __future__ import annotations

import logging
import re
import socket
import threading
from datetime import date, datetime
from typing import Dict, List, Optional, Sequence

from app.bloomberg.base import (
    BloombergUnavailable,
    HistoricalSeries,
    MarketDataProvider,
    ReferenceData,
    SecurityHit,
    parse_security_string,
)
from app.config import settings

logger = logging.getLogger(__name__)

REFDATA_SERVICE = "//blp/refdata"
INSTRUMENTS_SERVICE = "//blp/instruments"

# How long to wait when probing for bbcomm before giving up. This is a loopback
# connect - if it is going to succeed it succeeds immediately.
PROBE_TIMEOUT_SECONDS = 0.75

def bbcomm_is_listening(host: str, port: int, timeout: float = PROBE_TIMEOUT_SECONDS) -> bool:
    """
    Cheap pre-flight check: is anything accepting connections on the Desktop
    API port?

    Worth doing before touching BLPAPI at all. Without it, a machine with no
    Terminal spends ~10 seconds inside `Session.start()` retrying, and BLPAPI's
    native C++ layer writes its own diagnostics straight to stderr - which
    looks like a crash to anyone who has not seen it before. Probing first
    turns that into an instant, readable error.
    """
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _quiet_blpapi_logging(blpapi) -> None:
    """
    Route BLPAPI's native logging through Python's logging instead of stderr.

    Best-effort: the callback signature has varied across SDK versions, so any
    failure here is non-fatal and simply leaves the default behaviour in place.
    """
    try:
        def _callback(threadId, severity, ts, category, message):  # noqa: ANN001
            logger.debug("blpapi[%s] %s: %s", severity, category, message)

        blpapi.Logger.registerCallback(_callback, blpapi.Logger.SEVERITY_WARN)
    except Exception:  # pragma: no cover - SDK version differences
        logger.debug("Could not install a BLPAPI log callback; native logging stays on")


class BlpapiProvider(MarketDataProvider):
    name = "blpapi"
    is_live = True

    def __init__(self) -> None:
        self._session = None
        self._lock = threading.RLock()
        self._blpapi = None
        self._last_error: str | None = None

    # -- lifecycle ---------------------------------------------------------
    def start(self) -> None:
        with self._lock:
            if self._session is not None:
                return
            try:
                import blpapi  # type: ignore
            except ImportError as exc:
                self._last_error = (
                    "blpapi package not installed. Install it from Bloomberg's index: "
                    "pip install --index-url="
                    "https://blpapi.bloomberg.com/repository/releases/python/simple/ blpapi"
                )
                raise BloombergUnavailable(self._last_error) from exc

            self._blpapi = blpapi
            _quiet_blpapi_logging(blpapi)

            host, port = settings.bloomberg.host, settings.bloomberg.port
            if not bbcomm_is_listening(host, port):
                self._last_error = (
                    f"Nothing is listening on {host}:{port}, so there is no Bloomberg "
                    "Desktop API to connect to.\n"
                    "  * The Bloomberg Terminal application must be RUNNING and logged "
                    "in on this machine - the bbcomm process starts with it.\n"
                    "  * Being logged into Bloomberg Anywhere in a web browser is NOT "
                    "sufficient; the Desktop API needs the installed Terminal software.\n"
                    "  * If BLPAPI also reports 'failed to read Path from BBComm "
                    "registry', the Terminal software is not installed on this machine "
                    "at all - that is an install, not a login, problem."
                )
                raise BloombergUnavailable(self._last_error)

            opts = blpapi.SessionOptions()
            opts.setServerHost(settings.bloomberg.host)
            opts.setServerPort(settings.bloomberg.port)
            opts.setAutoRestartOnDisconnection(True)

            session = blpapi.Session(opts)
            if not session.start():
                self._last_error = (
                    f"Could not start a Bloomberg session on "
                    f"{settings.bloomberg.host}:{settings.bloomberg.port}. "
                    "Is the Terminal running and logged in on this machine?"
                )
                raise BloombergUnavailable(self._last_error)
            for svc in (REFDATA_SERVICE, INSTRUMENTS_SERVICE):
                if not session.openService(svc):
                    self._last_error = f"Could not open Bloomberg service {svc}"
                    raise BloombergUnavailable(self._last_error)

            self._session = session
            self._last_error = None
            logger.info("BLPAPI session established on %s:%s", settings.bloomberg.host, settings.bloomberg.port)

    def stop(self) -> None:
        with self._lock:
            if self._session is not None:
                try:
                    self._session.stop()
                finally:
                    self._session = None

    def _require_session(self):
        if self._session is None:
            self.start()
        return self._session

    def health(self) -> dict:
        endpoint = f"{settings.bloomberg.host}:{settings.bloomberg.port}"
        try:
            self._require_session()
            return {
                "provider": self.name,
                "live": True,
                "status": "connected",
                "endpoint": endpoint,
                "detail": "Desktop API session active",
                "bbcomm_listening": True,
            }
        except BloombergUnavailable as exc:
            return {
                "provider": self.name,
                "live": False,
                "status": "unavailable",
                "endpoint": endpoint,
                "detail": str(exc),
                "bbcomm_listening": bbcomm_is_listening(
                    settings.bloomberg.host, settings.bloomberg.port
                ),
            }

    # -- request plumbing --------------------------------------------------
    def _send(self, service_name: str, request):
        blpapi = self._blpapi
        session = self._require_session()
        cid = session.sendRequest(request)  # noqa: F841 - correlation handled below
        messages = []
        deadline_ms = settings.bloomberg.timeout_ms
        while True:
            ev = session.nextEvent(deadline_ms)
            ev_type = ev.eventType()
            if ev_type in (blpapi.Event.PARTIAL_RESPONSE, blpapi.Event.RESPONSE):
                for msg in ev:
                    messages.append(msg)
                if ev_type == blpapi.Event.RESPONSE:
                    break
            elif ev_type == blpapi.Event.TIMEOUT:
                raise BloombergUnavailable(
                    f"Bloomberg request to {service_name} timed out after "
                    f"{settings.bloomberg.timeout_ms}ms"
                )
        return messages

    # -- historical --------------------------------------------------------
    def historical(
        self,
        tickers: Sequence[str],
        fields: Sequence[str],
        start: date,
        end: date,
        *,
        calendar_fill: bool = True,
    ) -> HistoricalSeries:
        if not tickers or not fields:
            return {}
        blpapi = self._blpapi or self._import_blpapi()
        session = self._require_session()
        svc = session.getService(REFDATA_SERVICE)

        out: HistoricalSeries = {t: {} for t in tickers}

        # BLPAPI caps securities per request; chunk conservatively.
        for chunk in _chunks(list(tickers), 50):
            request = svc.createRequest("HistoricalDataRequest")
            for t in chunk:
                request.getElement("securities").appendValue(t)
            for f in fields:
                request.getElement("fields").appendValue(f)
            request.set("startDate", start.strftime("%Y%m%d"))
            request.set("endDate", end.strftime("%Y%m%d"))
            request.set("periodicitySelection", "DAILY")
            request.set("periodicityAdjustment", "ACTUAL")
            if calendar_fill:
                # This pairing is what implements "carry the last available
                # prior official print across holidays and market closures".
                request.set("nonTradingDayFillOption", "ALL_CALENDAR_DAYS")
                request.set("nonTradingDayFillMethod", settings.bloomberg.historical_fill)
            else:
                request.set("nonTradingDayFillOption", "ACTIVE_DAYS_ONLY")

            for msg in self._send(REFDATA_SERVICE, request):
                if msg.hasElement("responseError"):
                    raise BloombergUnavailable(str(msg.getElement("responseError")))
                sec_data = msg.getElement("securityData")
                ticker = sec_data.getElementAsString("security")
                if sec_data.hasElement("securityError"):
                    logger.warning(
                        "Bloomberg securityError for %s: %s",
                        ticker,
                        sec_data.getElement("securityError"),
                    )
                    continue
                field_data = sec_data.getElement("fieldData")
                for i in range(field_data.numValues()):
                    row = field_data.getValueAsElement(i)
                    obs = row.getElementAsDatetime("date")
                    obs_date = date(obs.year, obs.month, obs.day)
                    values: Dict[str, float] = {}
                    for f in fields:
                        if row.hasElement(f):
                            try:
                                values[f] = float(row.getElementAsFloat(f))
                            except Exception:  # non-numeric field
                                values[f] = row.getElementAsString(f)  # type: ignore[assignment]
                    if values:
                        out.setdefault(ticker, {})[obs_date] = values
        return out

    # -- reference ---------------------------------------------------------
    def reference(
        self, tickers: Sequence[str], fields: Sequence[str], *, as_of: Optional[date] = None
    ) -> ReferenceData:
        if not tickers or not fields:
            return {}
        session = self._require_session()
        svc = session.getService(REFDATA_SERVICE)
        out: ReferenceData = {t: {} for t in tickers}

        for chunk in _chunks(list(tickers), 100):
            request = svc.createRequest("ReferenceDataRequest")
            for t in chunk:
                request.getElement("securities").appendValue(t)
            for f in fields:
                request.getElement("fields").appendValue(f)
            if as_of is not None:
                # Historical reference data via overrides where the field
                # supports it. Fields that ignore the override simply return
                # the current value; the as-of date is recorded alongside the
                # cached value so the audit trail stays honest.
                overrides = request.getElement("overrides")
                ov = overrides.appendElement()
                ov.setElement("fieldId", "REFERENCE_DATE")
                ov.setElement("value", as_of.strftime("%Y%m%d"))

            for msg in self._send(REFDATA_SERVICE, request):
                if msg.hasElement("responseError"):
                    raise BloombergUnavailable(str(msg.getElement("responseError")))
                sec_array = msg.getElement("securityData")
                for i in range(sec_array.numValues()):
                    sec = sec_array.getValueAsElement(i)
                    ticker = sec.getElementAsString("security")
                    if sec.hasElement("securityError"):
                        out.setdefault(ticker, {})["_error"] = str(
                            sec.getElement("securityError").getElementAsString("message")
                        )
                        continue
                    fd = sec.getElement("fieldData")
                    bucket = out.setdefault(ticker, {})
                    for f in fields:
                        if not fd.hasElement(f):
                            continue
                        el = fd.getElement(f)
                        try:
                            bucket[f] = float(el.getValueAsFloat())
                        except Exception:
                            bucket[f] = el.getValueAsString()
        return out

    # -- search ------------------------------------------------------------
    def search(self, query: str, *, limit: int = 20, yellow_key: str = "") -> List[SecurityHit]:
        if not query.strip():
            return []
        session = self._require_session()
        svc = session.getService(INSTRUMENTS_SERVICE)
        request = svc.createRequest("instrumentListRequest")
        request.set("query", query)
        request.set("maxResults", int(limit))
        if yellow_key:
            filt = request.getElement("filterRequest") if request.hasElement("filterRequest") else None
            if filt is not None:
                filt.setElement("yellowKeyFilter", f"YK_FILTER_{yellow_key.upper()}")

        hits: List[SecurityHit] = []
        for msg in self._send(INSTRUMENTS_SERVICE, request):
            if not msg.hasElement("results"):
                continue
            results = msg.getElement("results")
            for i in range(results.numValues()):
                item = results.getValueAsElement(i)
                sec = item.getElementAsString("security") if item.hasElement("security") else ""
                desc = (
                    item.getElementAsString("description")
                    if item.hasElement("description")
                    else ""
                )
                ticker, yk = parse_security_string(sec)
                if not ticker:
                    continue
                hits.append(
                    SecurityHit(
                        ticker=ticker,
                        description=desc.strip(),
                        yellow_key=yk,
                    )
                )
        return hits

    # -- helpers -----------------------------------------------------------
    def _import_blpapi(self):
        import blpapi  # type: ignore

        self._blpapi = blpapi
        return blpapi


def _chunks(items: List[str], size: int):
    for i in range(0, len(items), size):
        yield items[i : i + size]
