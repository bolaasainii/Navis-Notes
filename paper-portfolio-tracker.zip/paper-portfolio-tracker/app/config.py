"""
Application configuration.

Single source of truth for every tunable value and - critically - for every
file-system path the application touches.

============================================================================
REPOINT SHARED DRIVE LATER
============================================================================
No module outside this file may construct a data path. Everything resolves
through `settings.paths`, which in turn resolves through `config/settings.yaml`
(overridable by PPT_* environment variables).

To move the application's data onto an internal shared drive:
  1. edit `paths.data_root` and `paths.database_path` in config/settings.yaml,
     OR set PPT_PATHS__DATA_ROOT / PPT_PATHS__DATABASE_PATH in the environment;
  2. copy the existing .sqlite file to the new location;
  3. restart the service.
No code change is required. See README -> "Repointing the shared drive".
============================================================================
"""

from __future__ import annotations

import os
from datetime import date
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
from pydantic import BaseModel, Field

# Repository root = parent of the `app` package.
REPO_ROOT = Path(__file__).resolve().parent.parent
CONFIG_DIR = REPO_ROOT / "config"

_ENV_PREFIX = "PPT_"
_ENV_NESTED_SEP = "__"


# ---------------------------------------------------------------------------
# Section models
# ---------------------------------------------------------------------------
class AppSection(BaseModel):
    name: str = "TAA-Notepad"
    short_name: str = "TAA-Notepad"
    environment: str = "development"
    timezone: str = "America/New_York"


class PathsSection(BaseModel):
    """
    REPOINT SHARED DRIVE LATER - every path the application uses lives here.
    """

    data_root: str = "data"
    database_path: str = "data/db/paper_portfolio.sqlite"
    instrument_master_seed: str = "data/seed/bloomberg_futures_hierarchy.csv"
    import_archive_dir: str = "data/imports"
    templates_dir: str = "data/templates"
    samples_dir: str = "data/samples"

    def _resolve(self, raw: str) -> Path:
        """
        Resolve a configured path.

        REPOINT SHARED DRIVE LATER - absolute paths (including Windows UNC
        paths such as \\\\corp-fs01\\share\\book) are used verbatim, so the
        shared-drive move is a pure configuration change. Relative paths are
        resolved against the repository root for developer convenience.
        """
        p = Path(os.path.expandvars(os.path.expanduser(raw)))
        if p.is_absolute() or raw.startswith("\\\\"):
            return p
        return REPO_ROOT / p

    @property
    def data_root_path(self) -> Path:
        return self._resolve(self.data_root)

    @property
    def database_file(self) -> Path:
        return self._resolve(self.database_path)

    @property
    def instrument_seed_file(self) -> Path:
        return self._resolve(self.instrument_master_seed)

    @property
    def import_archive(self) -> Path:
        return self._resolve(self.import_archive_dir)

    @property
    def templates_path(self) -> Path:
        return self._resolve(self.templates_dir)

    @property
    def samples_path(self) -> Path:
        return self._resolve(self.samples_dir)

    def ensure_directories(self) -> None:
        """Create every directory the app writes to. Safe to call repeatedly."""
        for p in (
            self.database_file.parent,
            self.import_archive,
            self.templates_path,
            self.samples_path,
        ):
            p.mkdir(parents=True, exist_ok=True)


class BloombergSection(BaseModel):
    provider: str = "auto"
    host: str = "127.0.0.1"
    port: int = 8194
    timeout_ms: int = 30000
    max_retries: int = 2
    close_field_priority: List[str] = Field(default_factory=lambda: ["PX_SETTLE", "PX_LAST"])
    open_field_priority: List[str] = Field(default_factory=lambda: ["PX_OPEN"])
    historical_fill: str = "PREVIOUS_VALUE"
    volatility_fill: str = "ACTIVE_DAYS_ONLY"
    cache_ttl_hours: int = 12
    price_cache_final_after_days: int = 3
    live_refresh_window_days: int = 5
    live_refresh_ttl_minutes: int = 15
    require_live_execution_prices: bool = False


class FundingSection(BaseModel):
    offset_ticker: str = "USD_CASH_OFFSET"
    offset_display_name: str = "USD Funding / Cash Sleeve"
    day_count: str = "ACT/360"
    positive_cash_benchmark: str = "SOFR1M"
    negative_cash_benchmark: str = "SOFR1M"
    negative_cash_spread_bps: float = 25.0
    positive_cash_spread_bps: float = 0.0
    benchmark_tickers: Dict[str, str] = Field(default_factory=dict)

    @property
    def day_count_basis(self) -> float:
        return 365.0 if self.day_count.upper().endswith("365") else 360.0


class VolatilitySettings(BaseModel):
    default_lookback_days: int = 63
    annualisation_factor: int = 252
    min_observations: int = 20
    default_mode: str = "annualised"


class DurationSettings(BaseModel):
    field_priority: List[str] = Field(
        default_factory=lambda: ["FUT_EQV_DUR_NOTL", "DUR_ADJ_MID", "DUR_MID"]
    )
    allow_proxy_fallback: bool = True


class PnlSettings(BaseModel):
    base_currency: str = "USD"
    inception_mode: str = "first_trade"


class AnalyticsSection(BaseModel):
    volatility: VolatilitySettings = Field(default_factory=VolatilitySettings)
    duration: DurationSettings = Field(default_factory=DurationSettings)
    pnl: PnlSettings = Field(default_factory=PnlSettings)


class UiSection(BaseModel):
    default_theme: str = "dark"
    default_density: str = "compact"
    show_offset_sleeve_by_default: bool = False
    rows_per_page: int = 200


class AuditSection(BaseModel):
    log_pricing_fallbacks: bool = True
    log_duration_sources: bool = True
    log_import_lineage: bool = True
    retain_days: int = 0


class Settings(BaseModel):
    app: AppSection = Field(default_factory=AppSection)
    paths: PathsSection = Field(default_factory=PathsSection)
    bloomberg: BloombergSection = Field(default_factory=BloombergSection)
    funding: FundingSection = Field(default_factory=FundingSection)
    analytics: AnalyticsSection = Field(default_factory=AnalyticsSection)
    ui: UiSection = Field(default_factory=UiSection)
    audit: AuditSection = Field(default_factory=AuditSection)


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------
def _apply_env_overrides(raw: Dict[str, Any]) -> Dict[str, Any]:
    """
    Fold PPT_SECTION__KEY environment variables into the parsed YAML.

    Values are passed through YAML's scalar parser so that `true`, `12` and
    `["a","b"]` arrive as the right Python type.
    """
    for env_key, env_val in os.environ.items():
        if not env_key.startswith(_ENV_PREFIX):
            continue
        path = env_key[len(_ENV_PREFIX) :].lower().split(_ENV_NESTED_SEP)
        if not path:
            continue
        cursor: Dict[str, Any] = raw
        for part in path[:-1]:
            cursor = cursor.setdefault(part, {})
            if not isinstance(cursor, dict):  # pragma: no cover - misconfig
                break
        else:
            try:
                cursor[path[-1]] = yaml.safe_load(env_val)
            except yaml.YAMLError:
                cursor[path[-1]] = env_val
    return raw


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Parse config/settings.yaml once per process."""
    settings_file = CONFIG_DIR / "settings.yaml"
    raw: Dict[str, Any] = {}
    if settings_file.exists():
        raw = yaml.safe_load(settings_file.read_text(encoding="utf-8")) or {}
    raw = _apply_env_overrides(raw)
    settings = Settings.model_validate(raw)
    settings.paths.ensure_directories()
    return settings


@lru_cache(maxsize=1)
def get_duration_proxies() -> Dict[str, Any]:
    f = CONFIG_DIR / "duration_proxies.yaml"
    if not f.exists():
        return {"defaults": {}, "by_ticker": {}, "by_level3": {}, "by_level2": {}}
    return yaml.safe_load(f.read_text(encoding="utf-8")) or {}


@lru_cache(maxsize=1)
def get_funding_curve_seed() -> Dict[str, Any]:
    f = CONFIG_DIR / "funding_benchmarks.yaml"
    if not f.exists():
        return {"benchmark": "SOFR1M", "curve": []}
    return yaml.safe_load(f.read_text(encoding="utf-8")) or {}


def parse_iso_date(value: str | date) -> date:
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value).strip()[:10])


def reload_settings() -> Settings:
    """Drop cached configuration - used by tests and the Settings screen."""
    get_settings.cache_clear()
    get_duration_proxies.cache_clear()
    get_funding_curve_seed.cache_clear()
    return get_settings()


settings: Settings = get_settings()
