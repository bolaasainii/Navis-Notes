"""
Load a demonstration book so the application has something to show on first run.

Creates:
  * portfolio `Navi-S1` - a macro cross-asset paper book
  * a trade-history import covering roughly three months of activity
  * a handful of manually entered trades exercising all three execution types
  * an August target snapshot
  * a second, archived portfolio so the browse/archive UI has content

Everything here goes through the same service layer the UI uses, so if the
demo loads cleanly the application's core paths are working.

    python scripts/load_demo_data.py [--reset]
"""

from __future__ import annotations

import argparse
import sys
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.db import init_db, session_scope  # noqa: E402
from app.models import ExecutionType, ImportMode, Portfolio  # noqa: E402
from app.services import (  # noqa: E402
    exposure,
    funding,
    imports,
    instruments,
    pnl,
    portfolios,
    positions,
    trades,
)

DEMO_ID = "Navi-S1"
SECOND_ID = "Navi-S2"


TRADE_HISTORY_CSV = """portfolio_id,bbg_ticker,notional_weight_pct,trade_date,execution_time,level,notes
Navi-S1,ES1 Index,6,2026-05-04,Mkt Close,,Core US large cap long
Navi-S1,RTY1 Index,-2.5,2026-05-04,Mkt Close,,Short US small cap
Navi-S1,TY1 Comdty,4,2026-05-04,Mkt Close,,Long US 10y duration
Navi-S1,RX1 Comdty,-3,2026-05-04,Mkt Close,,Short Bunds vs USTs
Navi-S1,EC1 Curncy,2,2026-05-05,Mkt Open,,Long EUR at the open
Navi-S1,NK1 Index,3,2026-05-05,Mkt Close,,Long Japan
Navi-S1,IQBA Index,2,2026-05-11,Mkt Close,,Long US IG credit
Navi-S1,ES1 Index,2,2026-06-01,Mkt Close,,Add to the US long
Navi-S1,JY1 Curncy,-1.5,2026-06-01,Mkt Close,,Short JPY
Navi-S1,TY1 Comdty,-1.5,2026-06-15,Mkt Close,,Trim duration into the rally
Navi-S1,SXO1 Index,2.5,2026-06-15,Mkt Close,,Long European equity
Navi-S1,NK1 Index,-3,2026-07-06,Mkt Close,,Exit Japan
Navi-S1,US1 Comdty,-2,2026-07-06,Mkt Close,,Curve steepener - short the long bond
Navi-S1,HYBA Index,1.5,2026-07-20,Mkt Close,,Long US high yield
Navi-S1,ES1 Index,-3,2026-08-03,Mkt Close,,Reduce US beta
"""

TARGET_SNAPSHOT_CSV = """portfolio_id,bbg_ticker,notional_weight_pct,trade_date,execution_time,level,notes
Navi-S1,ES1 Index,5,2026-08-03,Mkt Close,,Target US large cap
Navi-S1,RTY1 Index,-2.5,2026-08-03,Mkt Close,,Target US small cap short
Navi-S1,SXO1 Index,2.5,2026-08-03,Mkt Close,,Target Europe
Navi-S1,TY1 Comdty,2.5,2026-08-03,Mkt Close,,Target US duration
Navi-S1,US1 Comdty,-2,2026-08-03,Mkt Close,,Target steepener
Navi-S1,RX1 Comdty,-3,2026-08-03,Mkt Close,,Target Bund short
Navi-S1,IQBA Index,2,2026-08-03,Mkt Close,,Target IG credit
Navi-S1,HYBA Index,1.5,2026-08-03,Mkt Close,,Target HY credit
Navi-S1,EC1 Curncy,2,2026-08-03,Mkt Close,,Target long EUR
Navi-S1,JY1 Curncy,-1.5,2026-08-03,Mkt Close,,Target short JPY
"""


def _reset(db) -> None:
    for pid in (DEMO_ID, SECOND_ID):
        existing = portfolios.get(db, pid)
        if existing is not None:
            db.delete(existing)
    db.flush()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reset", action="store_true", help="delete and rebuild the demo books")
    args = parser.parse_args()

    init_db()

    with session_scope() as db:
        instruments.seed_from_disk(db)
        funding.seed_curve(db)

        if args.reset:
            _reset(db)

        if portfolios.get(db, DEMO_ID) is None:
            book = portfolios.create(
                db,
                portfolio_id=DEMO_ID,
                name="Macro Cross-Asset Paper Book",
                description=(
                    "Demonstration book: global macro expressed through equity index, "
                    "government bond, credit and FX futures."
                ),
                owner="demo",
                inception_date=date(2026, 5, 4),
                notes="Loaded by scripts/load_demo_data.py",
                actor="demo-loader",
            )
            print(f"Created portfolio {book.portfolio_id}")

            record, parsed = imports.stage_upload(
                db,
                content=TRADE_HISTORY_CSV.encode(),
                filename="demo_trade_history.csv",
                mode=ImportMode.TRADE_HISTORY,
                portfolio=book,
                actor="demo-loader",
            )
            errors = [r for r in parsed if r.status.value == "error"]
            if errors:
                for r in errors[:10]:
                    print(f"  ! row {r.row_number}: {'; '.join(r.messages)}")
            result = imports.commit(db, record, actor="demo-loader")
            print(f"Imported {result['committed']} historical trades")

            # Manual entries exercising each execution type.
            for ticker, weight, when, exec_type, level in (
                ("XP1 Index", 1.5, date(2026, 8, 10), ExecutionType.MKT_CLOSE, None),
                ("DX1 Curncy", -1.0, date(2026, 8, 11), ExecutionType.MKT_OPEN, None),
                ("FV1 Comdty", 2.0, date(2026, 8, 12), ExecutionType.CUSTOM, 108.75),
            ):
                trades.save_trade(
                    db,
                    trades.TradeRequest(
                        portfolio_id=DEMO_ID,
                        bbg_ticker=ticker,
                        trade_date=when,
                        weight_pct=weight,
                        execution_type=exec_type,
                        custom_level=level,
                        notes=f"Manual entry - {exec_type.value}",
                        actor="demo-loader",
                    ),
                )
            print("Added 3 manual trades")

            snap_record, _ = imports.stage_upload(
                db,
                content=TARGET_SNAPSHOT_CSV.encode(),
                filename="demo_target_book_august.csv",
                mode=ImportMode.TARGET_SNAPSHOT,
                portfolio=book,
                actor="demo-loader",
            )
            snap_result = imports.commit(
                db, snap_record, snapshot_label="August target book", actor="demo-loader"
            )
            print(f"Loaded target snapshot with {snap_result['committed']} rows")

        if portfolios.get(db, SECOND_ID) is None:
            source = portfolios.require(db, DEMO_ID)
            clone = portfolios.clone(
                db,
                source,
                new_portfolio_id=SECOND_ID,
                new_name="Macro Cross-Asset - Archived Variant",
                actor="demo-loader",
            )
            portfolios.archive(db, clone, actor="demo-loader")
            print(f"Created and archived {clone.portfolio_id}")

    # Report
    with session_scope() as db:
        book = portfolios.require(db, DEMO_ID)
        as_of = date.today()
        view = exposure.build_position_view(db, book, valuation_date=as_of)
        kpis = view["kpis"]
        print("\n--- Demo book summary ---")
        print(f"  valuation date        {as_of}")
        print(f"  rows                  {len(view['rows'])}")
        print(f"  net exposure          {kpis['total']['net_pct']:+.2f}%")
        print(f"  gross exposure        {kpis['total']['gross_pct']:.2f}%")
        print(f"  funding sleeve        {kpis['funding_sleeve_pct']:+.2f}%")
        print(f"  book nets to          {kpis['book_nets_to']:+.6f}%")
        print(f"  equity net            {kpis['equity']['net_pct']:+.2f}%")
        print(f"  fixed income net      {kpis['fixed_income']['net_pct']:+.2f}%")
        print(f"  FX net                {kpis['fx']['net_pct']:+.2f}%")
        print(f"  duration target       {kpis['duration_target_years']:+.3f} years")
        p = kpis["pnl"]
        print(f"  P&L today/MTD/QTD/YTD {p['today']:+.3f}% / {p['mtd']:+.3f}% / "
              f"{p['qtd']:+.3f}% / {p['ytd']:+.3f}%")
        print(f"  P&L since inception   {p['itd']:+.3f}%")
        recon = view["diagnostics"]["reconciliation"]
        print(f"  reconciliation        daily={recon['daily_series_total']:+.4f}%  "
              f"lots={recon['lot_total']:+.4f}%  "
              f"compounding residual={recon['compounding_residual']:+.4f}%")


if __name__ == "__main__":
    main()
