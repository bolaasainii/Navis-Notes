"""
Start a clean database for live Bloomberg use.

Why you want this
-----------------
The shipped database contains a demonstration book whose trades were priced by
the SYNTHETIC provider. Those execution levels are historical facts on those
trades and are deliberately never rewritten - so a book that mixes synthetic
history with live marks would produce meaningless P&L.

This script archives the existing database and creates a fresh one containing
only the instrument master and the funding curve: no portfolios, no trades, no
cached prices.

    python scripts/reset_for_live.py                 # archive and start clean
    python scripts/reset_for_live.py --keep-cache    # keep price cache (rarely wanted)
    python scripts/reset_for_live.py --yes           # skip the confirmation prompt

REPOINT SHARED DRIVE LATER - the database location comes from
config/settings.yaml -> paths.database_path. This script archives whatever that
resolves to, wherever it lives.
"""

from __future__ import annotations

import argparse
import shutil
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import settings  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description="Start a clean database for live use")
    parser.add_argument("--yes", action="store_true", help="skip the confirmation prompt")
    parser.add_argument(
        "--keep-cache",
        action="store_true",
        help="keep the existing database and only purge non-live cached prices",
    )
    args = parser.parse_args()

    db_path: Path = settings.paths.database_file
    print(f"Database: {db_path}")
    print(f"Provider: {settings.bloomberg.provider}")

    if settings.bloomberg.provider == "fake":
        print(
            "\nWARNING: bloomberg.provider is 'fake'. Set it to 'blpapi' in "
            "config/settings.yaml before using this for a live book."
        )

    if args.keep_cache:
        from app.bloomberg import get_provider
        from app.db import init_db, session_scope
        from app.services import pricing

        init_db()
        with session_scope() as db:
            result = pricing.purge_foreign_provider_data(
                db, active_provider=get_provider().name
            )
        print(
            f"Purged {result['prices_purged']} price and "
            f"{result['reference_purged']} reference cache row(s)."
        )
        return

    if db_path.exists():
        if not args.yes:
            answer = input(
                "\nThis archives the current database (including the demo book) and "
                "starts empty.\nType 'yes' to continue: "
            ).strip().lower()
            if answer != "yes":
                print("Aborted. Nothing was changed.")
                return

        stamp = time.strftime("%Y%m%d-%H%M%S")
        archive = db_path.with_name(f"{db_path.stem}.archived-{stamp}{db_path.suffix}")
        shutil.move(str(db_path), str(archive))
        # WAL/SHM siblings, if any.
        for suffix in ("-wal", "-shm"):
            sibling = Path(str(db_path) + suffix)
            if sibling.exists():
                sibling.unlink()
        print(f"Archived previous database to: {archive}")

    from app.db import init_db, session_scope
    from app.services import funding, imports, instruments

    init_db()
    with session_scope() as db:
        result = instruments.seed_from_disk(db, force=True, actor="reset_for_live")
        if result:
            print(f"Instrument master v{result.version}: {result.row_count} instruments")
        added = funding.seed_curve(db)
        print(f"Funding curve: {added} benchmark point(s)")
    imports.write_template_files()

    print(
        "\nClean database ready. Next:\n"
        "  1. start the service:  python -m uvicorn app.main:app --port 8000\n"
        "  2. create a portfolio from the header ('New')\n"
        "  3. book a trade dated today - the level box should tag it 'live'\n"
    )


if __name__ == "__main__":
    main()
