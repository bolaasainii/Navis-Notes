"""
Initialise the application database.

REPOINT SHARED DRIVE LATER - the target file comes from
config/settings.yaml -> paths.database_path. Run this once after changing it.

    python scripts/init_db.py [--force-seed]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import settings          # noqa: E402
from app.db import init_db, session_scope  # noqa: E402
from app.services import funding, imports, instruments  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description="Initialise the paper portfolio database")
    parser.add_argument("--force-seed", action="store_true", help="reload the instrument master")
    args = parser.parse_args()

    print(f"Database: {settings.paths.database_file}")
    init_db()

    with session_scope() as db:
        result = instruments.seed_from_disk(db, force=args.force_seed)
        if result:
            print(f"Instrument master v{result.version}: +{result.added} new, "
                  f"{result.updated} updated, {result.deactivated} deactivated")
        else:
            print("Instrument master already loaded (use --force-seed to reload)")
        added = funding.seed_curve(db)
        print(f"Funding curve: {added} new benchmark point(s)")

    written = imports.write_template_files()
    for p in written:
        print(f"Template written: {p}")
    print("Done.")


if __name__ == "__main__":
    main()
